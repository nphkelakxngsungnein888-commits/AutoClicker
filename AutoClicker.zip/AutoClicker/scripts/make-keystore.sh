#!/usr/bin/env bash
# สร้างคีย์เซ็นแอปใหม่ (ทำครั้งเดียว) แล้วตั้งค่า GitHub Secrets ให้ CI
# ใช้: scripts/make-keystore.sh [owner/repo]
#   - ถ้าใส่ owner/repo และติดตั้ง gh ไว้ จะตั้ง secrets ให้อัตโนมัติ
#   - ไม่เช่นนั้นจะพิมพ์ชื่อและค่า secrets ให้คัดลอกไปใส่เอง
# เก็บไฟล์ release.keystore ไว้ในที่ปลอดภัย (ห้ามอัปโหลดเข้า repo) — ถ้าทำหาย จะออกอัปเดตทับแอปเดิมไม่ได้อีก
set -euo pipefail

REPO="${1:-}"
OUT="${KEYSTORE_OUT:-release.keystore}"
ALIAS="${KEY_ALIAS:-autoclicker}"

if [ -e "$OUT" ]; then
  echo "มีไฟล์ $OUT อยู่แล้ว ไม่เขียนทับ (ลบหรือตั้ง KEYSTORE_OUT เป็นชื่ออื่น)" >&2
  exit 1
fi

PASS="$(openssl rand -base64 24 | tr -d '/+=' | cut -c1-24)"

keytool -genkeypair -v \
  -keystore "$OUT" -storetype PKCS12 \
  -alias "$ALIAS" -keyalg RSA -keysize 4096 -validity 36500 \
  -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=AutoClicker, O=AutoClicker, C=TH"

B64="$(base64 -w0 "$OUT" 2>/dev/null || base64 "$OUT" | tr -d '\n')"

if [ -n "$REPO" ] && command -v gh >/dev/null 2>&1; then
  printf '%s' "$B64"   | gh secret set KEYSTORE_BASE64   --repo "$REPO"
  printf '%s' "$PASS"  | gh secret set KEYSTORE_PASSWORD --repo "$REPO"
  printf '%s' "$ALIAS" | gh secret set KEY_ALIAS         --repo "$REPO"
  printf '%s' "$PASS"  | gh secret set KEY_PASSWORD      --repo "$REPO"
  echo "ตั้งค่า GitHub Secrets ของ $REPO เรียบร้อย"
else
  echo
  echo "ตั้งค่า 4 secrets นี้ที่ GitHub → Settings → Secrets and variables → Actions:"
  echo "  KEYSTORE_PASSWORD = $PASS"
  echo "  KEY_PASSWORD      = $PASS"
  echo "  KEY_ALIAS         = $ALIAS"
  echo "  KEYSTORE_BASE64   = (ค่าด้านล่าง)"
  echo "$B64"
fi

echo
echo "สำรองไฟล์ $OUT และรหัสผ่านไว้ในที่ปลอดภัยด้วย (เช่น password manager)"
