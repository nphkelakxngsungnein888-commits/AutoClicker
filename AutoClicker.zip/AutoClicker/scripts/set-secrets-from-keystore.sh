#!/usr/bin/env bash
# ใช้คีย์เซ็นที่มีอยู่แล้ว (เช่น fixed.keystore เดิม) กับ CI เพื่อให้แอปที่ติดตั้งอยู่รับอัปเดตทับได้
# ใช้: scripts/set-secrets-from-keystore.sh <ไฟล์ keystore> <storepass> <alias> <keypass> [owner/repo]
#   คีย์เดิม: scripts/set-secrets-from-keystore.sh fixed.keystore android key0 android owner/repo
set -euo pipefail
KS="${1:?ระบุไฟล์ keystore}"; SP="${2:?ระบุ storepass}"; AL="${3:?ระบุ alias}"; KP="${4:?ระบุ keypass}"; REPO="${5:-}"
B64="$(base64 -w0 "$KS" 2>/dev/null || base64 "$KS" | tr -d '\n')"
if [ -n "$REPO" ] && command -v gh >/dev/null 2>&1; then
  printf '%s' "$B64" | gh secret set KEYSTORE_BASE64   --repo "$REPO"
  printf '%s' "$SP"  | gh secret set KEYSTORE_PASSWORD --repo "$REPO"
  printf '%s' "$AL"  | gh secret set KEY_ALIAS         --repo "$REPO"
  printf '%s' "$KP"  | gh secret set KEY_PASSWORD      --repo "$REPO"
  echo "ตั้งค่า GitHub Secrets ของ $REPO เรียบร้อย"
else
  echo "KEYSTORE_PASSWORD=$SP"; echo "KEY_ALIAS=$AL"; echo "KEY_PASSWORD=$KP"; echo "KEYSTORE_BASE64="; echo "$B64"
fi
