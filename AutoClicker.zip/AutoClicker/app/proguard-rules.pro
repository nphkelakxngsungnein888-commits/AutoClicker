# แอปนี้ไม่ใช้ reflection จึงไม่ต้องมีกฎ keep พิเศษ
# ถ้าเพิ่มไลบรารีที่ใช้ reflection/serialization ให้เพิ่มกฎ -keep ที่นี่
