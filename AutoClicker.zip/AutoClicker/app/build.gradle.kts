plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// CI passes -PbuildNumber=<run number>; used as versionCode so newer builds can update older ones
val buildNumber = project.findProperty("buildNumber")?.toString()?.toIntOrNull() ?: 1
// CI passes -PupdateRepo=<owner/repo>; the app checks this repo's Releases for new versions
val updateRepo = project.findProperty("updateRepo")?.toString() ?: ""

android {
    namespace = "com.example.autoclicker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.autoclicker"
        minSdk = 24
        targetSdk = 34
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
        buildConfigField("int", "BUILD_NUMBER", "$buildNumber")
    }

    buildFeatures {
        buildConfig = true
    }

    // Fixed signing key: every build is signed the same way, so new versions can update the installed app
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed.keystore")
            storePassword = "android"
            keyAlias = "key0"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.core:core:1.13.1")
}
