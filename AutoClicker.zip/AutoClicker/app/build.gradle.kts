plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// CI passes -PbuildNumber=<เลขนาที>; ใช้เป็น versionCode เพื่อให้ build ใหม่ทับของเก่าได้
val buildNumber = project.findProperty("buildNumber")?.toString()?.toIntOrNull()
    ?: (System.currentTimeMillis() / 60_000L).toInt()   // ไม่มีเลขจาก CI (build ในเครื่อง) = นาทีนับจาก 1970 เพิ่มขึ้นเสมอ ลงทับได้
// CI passes -PupdateRepo=<owner/repo>; the app checks this repo's Releases for new versions
val updateRepo = project.findProperty("updateRepo")?.toString() ?: ""

// คีย์สำรอง (ใช้เมื่อไม่มี app/debug.keystore): ข้อมูลคีย์มาจาก environment/Gradle property เท่านั้น
//   KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD   (หรือ -PkeystorePath=... ฯลฯ)
fun secret(env: String, prop: String): String? =
    System.getenv(env)?.takeIf { it.isNotBlank() } ?: project.findProperty(prop)?.toString()?.takeIf { it.isNotBlank() }

// คีย์เซ็นคงที่ที่อยู่ใน repo (app/debug.keystore) เหมือนแอป CartoonAnimatorStudio: ทุก build เซ็นด้วยคีย์เดียวกัน
// จึงลงทับได้โดยไม่ต้องตั้ง Secrets (เหมาะกับแอปส่วนตัว — ถ้า repo เป็นสาธารณะ ใครก็เซ็นด้วยคีย์นี้ได้)
// ถ้าไม่มีไฟล์นี้ จะใช้คีย์จาก environment/Gradle property แบบเดิม
val repoKeystore = file("debug.keystore")
val useRepoKey = repoKeystore.exists()
val keystorePath = if (useRepoKey) repoKeystore.path else secret("KEYSTORE_PATH", "keystorePath")
val hasReleaseKey = keystorePath != null && file(keystorePath).exists()

android {
    namespace = "com.example.autoclicker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.autoclicker"
        minSdk = 24
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
        buildConfigField("int", "BUILD_NUMBER", "$buildNumber")
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = if (useRepoKey) "android" else secret("KEYSTORE_PASSWORD", "keystorePassword")
                keyAlias = if (useRepoKey) "androiddebugkey" else secret("KEY_ALIAS", "keyAlias")
                keyPassword = if (useRepoKey) "android" else secret("KEY_PASSWORD", "keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // ไม่มีคีย์ = ได้ APK ที่ยังไม่เซ็น (ใช้ทดสอบ build ในเครื่อง ติดตั้งไม่ได้)
            signingConfig = if (hasReleaseKey) signingConfigs.getByName("release") else null
        }
        // debug ใช้คีย์ debug มาตรฐานของ Android SDK (ไม่ใช่คีย์สำหรับแจกจ่าย)
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.core:core:1.13.1")
    // OCR ในเครื่อง (โมเดลมากับแอป ไม่ต้องใช้เน็ตตอนใช้งาน) ใช้กับโหมด "ข้อความ" ของตา — รองรับอักษรละติน/ตัวเลข (ไม่รองรับภาษาไทย)
    implementation("com.google.mlkit:text-recognition:16.0.1")

    testImplementation("junit:junit:4.13.2")
    // unit test บน JVM ไม่มี org.json ของ Android จึงต้องใช้ตัวจริงจาก Maven
    testImplementation("org.json:json:20240303")
}
