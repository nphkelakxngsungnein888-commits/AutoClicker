package com.example.autoclicker

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// ทดสอบปุ่มลาก: ความแรง (ความเร็ว) → เวลาลาก, ค่ามาตรฐาน/รายจุด, และการเก็บ/โหลดข้อมูล
class DragTest {

    @Test
    fun dragDuration_isDistanceOverStrength() {
        // ระยะ 1000 พิกเซล ที่ 2000 พิกเซล/วินาที = 500 มิลลิวินาที
        assertEquals(500L, Timing.dragDurationMs(0f, 0f, 1000f, 0f, 2000L))
        // ระยะเฉียง 3-4-5: 500 พิกเซล ที่ 1000 พิกเซล/วินาที = 500 มิลลิวินาที
        assertEquals(500L, Timing.dragDurationMs(0f, 0f, 300f, 400f, 1000L))
    }

    @Test
    fun dragDuration_strongerIsFaster() {
        val slow = Timing.dragDurationMs(0f, 0f, 800f, 0f, 500L)
        val fast = Timing.dragDurationMs(0f, 0f, 800f, 0f, 5000L)
        assertTrue(fast < slow)
    }

    @Test
    fun dragDuration_isClamped() {
        assertEquals(Limits.MIN_HOLD_MS, Timing.dragDurationMs(0f, 0f, 1f, 0f, Limits.MAX_DRAG_STRENGTH))
        assertEquals(Limits.MAX_HOLD_MS, Timing.dragDurationMs(0f, 0f, 100_000f, 0f, Limits.MIN_DRAG_STRENGTH))
        // ค่าความแรงนอกช่วงถูกบีบเข้าช่วง ไม่หารศูนย์
        assertEquals(Timing.dragDurationMs(0f, 0f, 500f, 0f, Limits.MIN_DRAG_STRENGTH),
            Timing.dragDurationMs(0f, 0f, 500f, 0f, 0L))
    }

    @Test
    fun strengthOf_usesPerPointThenDefault() {
        val def = 1800L
        assertEquals(def, Timing.strengthOf(emptyList(), 0, def))
        assertEquals(def, Timing.strengthOf(listOf(-1L), 0, def))
        assertEquals(3000L, Timing.strengthOf(listOf(-1L, 3000L), 1, def))
        assertEquals(Limits.MAX_DRAG_STRENGTH, Timing.strengthOf(listOf(999_999L), 0, def))
    }

    @Test
    fun stepType_dragCode() {
        assertEquals(StepType.DRAG, StepType.fromCode("drag"))
        assertEquals("drag", StepType.DRAG.code)
    }

    @Test
    fun profile_dragRoundTrip() {
        val p = Profile(
            "ลาก",
            RunSettings(),
            listOf(ClickPoint(StepType.TAP, 10, 20), ClickPoint(StepType.DRAG, 100, 800, 100, 300)),
            listOf(-1L, 400L),
            emptyList(),
            listOf(-1L, 2500L)
        )
        val back = ConfigStore.profileFromJson(JSONObject(ConfigStore.profileToJson(p).toString()))
        assertEquals(p, back)
        assertEquals(StepType.DRAG, back.points[1].type)
        assertEquals(300, back.points[1].y2)
    }

    @Test
    fun profile_oldDataWithoutStrengthsStillLoads() {
        val o = ConfigStore.profileToJson(Profile("เก่า", RunSettings(), listOf(ClickPoint(StepType.TAP, 1, 2)), emptyList()))
        o.remove("g")
        assertTrue(ConfigStore.profileFromJson(o).strengths.isEmpty())
    }
}
