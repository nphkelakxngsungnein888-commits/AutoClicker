package com.example.autoclicker

import org.junit.Assert.assertEquals
import org.junit.Test

class DefaultHoldTest {

    @Test
    fun holdMs_globalDefaultAppliesToUnsetTapOnly() {
        assertEquals(120L, Timing.holdMs(StepType.TAP, emptyList(), 0, 120L))
        assertEquals(120L, Timing.holdMs(StepType.TAP, listOf(-1L), 0, 120L))
        // ตั้งรายปุ่มไว้ → ชนะค่ามาตรฐานรวม
        assertEquals(80L, Timing.holdMs(StepType.TAP, listOf(80L), 0, 120L))
        // ไม่ส่งค่ามาตรฐาน = พฤติกรรมเดิม
        assertEquals(Timing.gestureDurationMs(StepType.TAP), Timing.holdMs(StepType.TAP, emptyList(), 0))
        // ตาใช้การแตะสั้นคงที่ ไม่รับค่ามาตรฐานรวม
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(StepType.EYE, emptyList(), 0, 120L))
    }
}
