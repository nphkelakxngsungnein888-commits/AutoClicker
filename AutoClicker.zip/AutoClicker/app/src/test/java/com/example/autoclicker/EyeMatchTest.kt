package com.example.autoclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EyeMatchTest {
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF000000.toInt()
    private val red = 0xFFFF0000.toInt()

    // ภาพ 40×40 พื้นขาวมีแถบดำแนวตั้งตามที่กำหนด
    private fun bars(vararg cols: Int): IntArray {
        val px = IntArray(40 * 40) { white }
        for (y in 0 until 40) for (c in cols) for (x in c until c + 4) px[y * 40 + x] = black
        return px
    }

    @Test
    fun similarity_sameImageIsOne_differentIsLow() {
        val a = bars(4, 20)
        assertEquals(1f, EyeMatch.similarity(a, 40, 40, a.copyOf(), 40, 40), 0.001f)
        val b = bars(12, 30)
        assertTrue(EyeMatch.similarity(a, 40, 40, b, 40, 40) < 0.8f)
    }

    @Test
    fun similarity_toleratesSmallPositionShift() {
        val a = IntArray(40 * 40) { white }
        val shifted = IntArray(40 * 40) { white }
        for (y in 0 until 40) {
            for (x in 10 until 15) a[y * 40 + x] = black
            for (x in 11 until 16) shifted[y * 40 + x] = black
        }
        assertTrue(EyeMatch.similarity(a, 40, 40, shifted, 40, 40) >= 0.95f)
    }

    @Test
    fun similarity_flatImages() {
        val w = IntArray(100) { white }
        val k = IntArray(100) { black }
        assertEquals(1f, EyeMatch.similarity(w, 10, 10, w, 10, 10), 0.001f)
        assertEquals(0f, EyeMatch.similarity(w, 10, 10, k, 10, 10), 0.001f)
    }

    @Test
    fun uniformAndTargetColor() {
        val px = IntArray(100) { red }
        assertTrue(EyeMatch.isUniform(px))
        // พื้นขาว 80% + แดง 20% → สีที่จับคือแดง
        val mix = IntArray(100) { if (it < 20) red else white }
        assertFalse(EyeMatch.isUniform(mix))
        val (c, frac) = EyeMatch.pickTargetColor(mix)
        assertTrue(EyeMatch.colorFraction(mix, c) > 0.15f)
        assertTrue(frac > 0.15f)
        assertTrue(EyeMatch.colorMatches(mix, c, frac))
        assertFalse(EyeMatch.colorMatches(IntArray(100) { white }, c, frac))
    }

    @Test
    fun pickTargetColor_findsSmallContrastingObject() {
        // พื้นหลัง 99% + วัตถุสีแดง 1%: ต้องเลือกวัตถุ ไม่ใช่พื้นหลัง
        val px = IntArray(100) { white }
        px[0] = red
        val (target, fraction) = EyeMatch.pickTargetColor(px)
        assertTrue(EyeMatch.colorFraction(px, target) >= 0.01f)
        assertEquals(0.01f, fraction, 0.0001f)
        assertFalse(EyeMatch.colorMatches(IntArray(100) { white }, target, fraction))
    }

    @Test
    fun textMatching_ignoresCaseSpacesAndPunctuation() {
        assertTrue(EyeMatch.textMatches("Start  Game!", "start game"))
        assertTrue(EyeMatch.textMatches("OK 123", "ok123"))
        assertFalse(EyeMatch.textMatches("Cancel", "start"))
        assertFalse(EyeMatch.textMatches("anything", ""))
    }

    @Test
    fun textMatching_toleratesSmallOcrErrors() {
        assertTrue(EyeMatch.textMatches("START GANE", "start game"))
        assertTrue(EyeMatch.textSimilarity("START GANE", "start game") >= 0.86f)
        assertFalse(EyeMatch.textMatches("STOP GAME", "start game"))
        assertFalse(EyeMatch.textMatches("OK", "NO"))
    }

    @Test
    fun colorThreshold_isAdaptiveAndNeverZero() {
        assertTrue(EyeMatch.colorThreshold(0f) >= 0.01f)
        assertEquals(0.225f, EyeMatch.colorThreshold(0.5f), 0.0001f)
        assertEquals(0.45f, EyeMatch.colorThreshold(1f), 0.0001f)
    }

    @Test
    fun similarity_rejectsInvalidDimensions() {
        assertEquals(0f, EyeMatch.similarity(intArrayOf(white), 0, 1, intArrayOf(white), 1, 1), 0f)
        assertEquals(0f, EyeMatch.similarity(intArrayOf(white), 2, 2, intArrayOf(white), 1, 1), 0f)
    }
    @Test
    fun shapeSimilarity_recognizesSameOutlineAfterBrightnessChange() {
        val original = IntArray(40 * 40) { white }
        val changedLight = IntArray(40 * 40) { 0xFFBEBEBE.toInt() }
        for (y in 8 until 32) for (x in 17 until 23) {
            original[y * 40 + x] = black
            changedLight[y * 40 + x] = 0xFF303030.toInt()
        }
        assertTrue(EyeMatch.shapeSimilarity(original, 40, 40, changedLight, 40, 40) >= 0.85f)
        assertTrue(EyeMatch.similarity(original, 40, 40, changedLight, 40, 40) >= 0.85f)
    }

    @Test
    fun shapeSimilarity_toleratesLightDarkInversion() {
        val original = IntArray(40 * 40) { white }
        val inverted = IntArray(40 * 40) { black }
        for (y in 7 until 33) for (x in 16 until 24) {
            original[y * 40 + x] = black
            inverted[y * 40 + x] = white
        }
        assertTrue(EyeMatch.shapeSimilarity(original, 40, 40, inverted, 40, 40) >= 0.85f)
        assertTrue(EyeMatch.similarity(original, 40, 40, inverted, 40, 40) >= 0.90f)
    }

    @Test
    fun shapeSimilarity_rejectsDifferentOutline() {
        val vertical = IntArray(40 * 40) { white }
        val horizontal = IntArray(40 * 40) { white }
        for (y in 5 until 35) for (x in 18 until 22) vertical[y * 40 + x] = black
        for (y in 18 until 22) for (x in 5 until 35) horizontal[y * 40 + x] = black
        assertTrue(EyeMatch.shapeSimilarity(vertical, 40, 40, horizontal, 40, 40) < 0.7f)
    }

}
