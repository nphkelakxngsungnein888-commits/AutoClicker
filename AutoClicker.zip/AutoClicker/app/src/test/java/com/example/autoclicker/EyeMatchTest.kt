package com.example.autoclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EyeMatchTest {
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF000000.toInt()
    private val red = 0xFFFF0000.toInt()

    // ภาพ 40×40 พื้นขาวมีแถบดำแนวตั้งตามที่กำหนด
    private fun bars(vararg cols: Int): IntArray {
        val px = IntArray(40 * 40) { white }
        for (y in 0 until 40) for (c in cols) for (x in c until c + 4) px[y * 40 + x] = black
        return px
    }

    @Test
    fun similarity_sameImageIsOne_differentIsLow() {
        val a = bars(4, 20)
        assertEquals(1f, EyeMatch.similarity(a, 40, 40, a.copyOf(), 40, 40), 0.001f)
        val b = bars(12, 30)
        assertTrue(EyeMatch.similarity(a, 40, 40, b, 40, 40) < 0.8f)
    }

    @Test
    fun similarity_flatImages() {
        val w = IntArray(100) { white }
        val k = IntArray(100) { black }
        assertEquals(1f, EyeMatch.similarity(w, 10, 10, w, 10, 10), 0.001f)
        assertEquals(0f, EyeMatch.similarity(w, 10, 10, k, 10, 10), 0.001f)
    }

    @Test
    fun uniformAndTargetColor() {
        val px = IntArray(100) { red }
        assertTrue(EyeMatch.isUniform(px))
        // พื้นขาว 80% + แดง 20% → สีที่จับคือแดง
        val mix = IntArray(100) { if (it < 20) red else white }
        assertFalse(EyeMatch.isUniform(mix))
        val (c, frac) = EyeMatch.pickTargetColor(mix)
        assertTrue(EyeMatch.colorFraction(mix, c) > 0.15f)
        assertTrue(frac > 0.15f)
        assertTrue(EyeMatch.colorMatches(mix, c, frac))
        assertFalse(EyeMatch.colorMatches(IntArray(100) { white }, c, frac))
    }

    @Test
    fun textMatching_ignoresCaseSpacesAndPunctuation() {
        assertTrue(EyeMatch.textMatches("Start  Game!", "start game"))
        assertTrue(EyeMatch.textMatches("OK 123", "ok123"))
        assertFalse(EyeMatch.textMatches("Cancel", "start"))
        assertFalse(EyeMatch.textMatches("anything", ""))
    }
}
