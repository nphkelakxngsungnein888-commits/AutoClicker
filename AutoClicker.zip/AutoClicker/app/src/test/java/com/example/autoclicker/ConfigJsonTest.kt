package com.example.autoclicker

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigJsonTest {

    private val sample = Profile(
        "ทดสอบ \"quote\"",
        RunSettings(
            intervalMs = 250L, eyeScanIntervalMs = 900L, jitterPercent = 15, posJitterPx = 4, startDelayMs = 2000L,
            maxCount = 50, maxSeconds = 60,
            stopOnScreenOff = false, stopOnAppChange = true, volumeHotkey = true,
            sequential = true
        ),
        listOf(
            ClickPoint(StepType.TAP, 10, 20),
            ClickPoint(StepType.TAP, 30, 40),
            ClickPoint(StepType.TAP, 5, 6),
            ClickPoint(StepType.EYE, 100, 200, 80, 60, EyeCfg(EyeMode.AUTO, EyeMode.TEXT, "start", 0, 0f, 85, "eye_1.png"))
        ),
        listOf(-1L, 700L),
        listOf(80L, -1L, 900L)
    )

    @Test
    fun profile_roundTrip() {
        val json = ConfigStore.profileToJson(sample).toString()
        assertEquals(sample, ConfigStore.profileFromJson(JSONObject(json)))
    }

    @Test
    fun profile_outOfRangeValuesAreSanitized() {
        val o = ConfigStore.profileToJson(sample)
        o.getJSONObject("s").put("interval", 1).put("eyeScanInterval", 1).put("jitter", 999)
        val back = ConfigStore.profileFromJson(o)
        assertEquals(Limits.MIN_INTERVAL_MS, back.settings.intervalMs)
        assertEquals(Limits.MIN_EYE_SCAN_MS, back.settings.eyeScanIntervalMs)
        assertEquals(Limits.MAX_JITTER_PERCENT, back.settings.jitterPercent)
    }

    @Test
    fun legacySwipePointLoadsAsTap() {
        val points = ConfigStore.pointsFromJson("[ {\"t\":\"swipe\",\"x\":30,\"y\":40,\"x2\":300,\"y2\":400} ]")
        assertEquals(1, points.size)
        assertEquals(StepType.TAP, points.single().type)
    }

    @Test
    fun legacySwipeProfileResetsSwipeDurationToDefaultTap() {
        val json = ConfigStore.profileToJson(sample)
        json.put("p", org.json.JSONArray("[{\"t\":\"swipe\",\"x\":30,\"y\":40,\"x2\":300,\"y2\":400}]"))
        json.put("h", org.json.JSONArray("[850]"))
        val migrated = ConfigStore.profileFromJson(json)
        assertEquals(StepType.TAP, migrated.points.single().type)
        assertEquals(-1L, migrated.holds.single())
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(migrated.points.single().type, migrated.holds, 0))
    }

    @Test
    fun legacyLongProfileKeepsOldHoldTimeAsExplicitValue() {
        val json = ConfigStore.profileToJson(sample)
        // จุดที่ 1 = L ไม่เคยตั้งเวลา (-1) → ต้องได้ 600 ตรง ๆ; จุดที่ 2 = L ที่ตั้งไว้ 1500 → คงเดิม; จุดที่ 3 = แตะ → คงเดิม
        json.put("p", org.json.JSONArray(
            "[{\"t\":\"long\",\"x\":1,\"y\":2},{\"t\":\"long\",\"x\":3,\"y\":4},{\"t\":\"tap\",\"x\":5,\"y\":6}]"
        ))
        json.put("h", org.json.JSONArray("[-1, 1500]"))
        val migrated = ConfigStore.profileFromJson(json)
        assertEquals(listOf(StepType.TAP, StepType.TAP, StepType.TAP), migrated.points.map { it.type })
        assertEquals(listOf(Limits.LONG_PRESS_MS, 1500L), migrated.holds)
        assertEquals(Limits.LONG_PRESS_MS, Timing.holdMs(StepType.TAP, migrated.holds, 0))
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(StepType.TAP, migrated.holds, 2))
    }

    @Test
    fun legacyProfileWithoutSequentialFlagLoadsAsIndependentMode() {
        val json = ConfigStore.profileToJson(sample)
        json.getJSONObject("s").remove("sequential")
        assertEquals(false, ConfigStore.profileFromJson(json).settings.sequential)
    }

    @Test
    fun points_corruptOrEmptyInputGivesEmptyList() {
        assertTrue(ConfigStore.pointsFromJson(null).isEmpty())
        assertTrue(ConfigStore.pointsFromJson("").isEmpty())
        assertTrue(ConfigStore.pointsFromJson("not json").isEmpty())
        assertTrue(ConfigStore.pointsFromJson("[{\"x\":1}]").isEmpty())   // ไม่มี y → ทั้งรายการใช้ไม่ได้
    }

    @Test
    fun delays_roundTripAndCorrupt() {
        val d = listOf(-1L, 0L, 1500L)
        assertEquals(d, ConfigStore.delaysFromJson(ConfigStore.delaysToJson(d).toString()))
        assertTrue(ConfigStore.delaysFromJson("[").isEmpty())
    }
}
