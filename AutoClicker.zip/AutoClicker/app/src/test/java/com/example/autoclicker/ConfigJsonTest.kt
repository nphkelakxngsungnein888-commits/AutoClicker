package com.example.autoclicker

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigJsonTest {

    private val sample = Profile(
        "ทดสอบ \"quote\"",
        RunSettings(
            intervalMs = 250L, jitterPercent = 15, posJitterPx = 4, startDelayMs = 2000L,
            maxCount = 50, maxSeconds = 60,
            stopOnScreenOff = false, stopOnAppChange = true, volumeHotkey = true
        ),
        listOf(
            ClickPoint(StepType.TAP, 10, 20),
            ClickPoint(StepType.SWIPE, 30, 40, 300, 400),
            ClickPoint(StepType.LONG, 5, 6)
        ),
        listOf(-1L, 700L),
        listOf(80L, -1L, 900L)
    )

    @Test
    fun profile_roundTrip() {
        val json = ConfigStore.profileToJson(sample).toString()
        assertEquals(sample, ConfigStore.profileFromJson(JSONObject(json)))
    }

    @Test
    fun profile_outOfRangeValuesAreSanitized() {
        val o = ConfigStore.profileToJson(sample)
        o.getJSONObject("s").put("interval", 1).put("jitter", 999)
        val back = ConfigStore.profileFromJson(o)
        assertEquals(Limits.MIN_INTERVAL_MS, back.settings.intervalMs)
        assertEquals(Limits.MAX_JITTER_PERCENT, back.settings.jitterPercent)
    }

    @Test
    fun points_corruptOrEmptyInputGivesEmptyList() {
        assertTrue(ConfigStore.pointsFromJson(null).isEmpty())
        assertTrue(ConfigStore.pointsFromJson("").isEmpty())
        assertTrue(ConfigStore.pointsFromJson("not json").isEmpty())
        assertTrue(ConfigStore.pointsFromJson("[{\"x\":1}]").isEmpty())   // ไม่มี y → ทั้งรายการใช้ไม่ได้
    }

    @Test
    fun delays_roundTripAndCorrupt() {
        val d = listOf(-1L, 0L, 1500L)
        assertEquals(d, ConfigStore.delaysFromJson(ConfigStore.delaysToJson(d).toString()))
        assertTrue(ConfigStore.delaysFromJson("[").isEmpty())
    }
}
