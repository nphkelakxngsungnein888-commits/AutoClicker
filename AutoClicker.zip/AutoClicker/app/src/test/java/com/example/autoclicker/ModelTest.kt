package com.example.autoclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class TimingTest {

    private val s = RunSettings(intervalMs = 500L)

    @Test
    fun stepDelay_usesGlobalWhenNoPerStepValue() {
        assertEquals(500L, Timing.stepDelay(s, emptyList(), 0))
        assertEquals(500L, Timing.stepDelay(s, listOf(-1L), 0))
        assertEquals(500L, Timing.stepDelay(s, listOf(100L), 3)) // ดัชนีเกินรายการ
    }

    @Test
    fun stepDelay_perStepOverrideAndMinimum() {
        assertEquals(1200L, Timing.stepDelay(s, listOf(1200L), 0))
        assertEquals(Limits.MIN_INTERVAL_MS, Timing.stepDelay(s, listOf(0L), 0))
    }

    @Test
    fun jitterDelay_zeroPercentIsIdentity() {
        assertEquals(500L, Timing.jitterDelay(500L, 0, Random(1)))
    }

    @Test
    fun jitterDelay_staysWithinBoundsAndVaries() {
        val rnd = Random(42)
        val seen = HashSet<Long>()
        repeat(2000) {
            val d = Timing.jitterDelay(1000L, 20, rnd)
            assertTrue("out of range: $d", d in 800L..1200L)
            seen.add(d)
        }
        assertTrue(seen.size > 50)
    }

    @Test
    fun jitterDelay_neverBelowMinimum() {
        val rnd = Random(7)
        repeat(1000) {
            assertTrue(Timing.jitterDelay(Limits.MIN_INTERVAL_MS, 90, rnd) >= Limits.MIN_INTERVAL_MS)
        }
    }

    @Test
    fun jitterCoord_radius() {
        val rnd = Random(3)
        assertEquals(100f, Timing.jitterCoord(100f, 0, rnd), 0f)
        repeat(500) {
            val v = Timing.jitterCoord(100f, 5, rnd)
            assertTrue(v in 95f..105f)
        }
    }

    @Test
    fun stopPolicy_countAndTime() {
        assertFalse(StopPolicy(0, 0).reached(1_000_000, Long.MAX_VALUE / 2))
        val byCount = StopPolicy(3, 0)
        assertFalse(byCount.reached(2, 0))
        assertTrue(byCount.reached(3, 0))
        val byTime = StopPolicy(0, 10)
        assertFalse(byTime.reached(5, 9_999))
        assertTrue(byTime.reached(5, 10_000))
    }

    @Test
    fun averagePeriod() {
        assertEquals(0.0, averagePeriodMs(0, 0), 0.0)
        assertEquals(0.0, averagePeriodMs(1, 100), 0.0)
        assertEquals(100.0, averagePeriodMs(11, 1000), 0.0001)
    }

    @Test
    fun settingsSanitized_clampsEverything() {
        val bad = RunSettings(
            intervalMs = 1, jitterPercent = 500, posJitterPx = -5, startDelayMs = -1,
            maxCount = -3, maxSeconds = Int.MAX_VALUE
        ).sanitized()
        assertEquals(Limits.MIN_INTERVAL_MS, bad.intervalMs)
        assertEquals(Limits.MAX_JITTER_PERCENT, bad.jitterPercent)
        assertEquals(0, bad.posJitterPx)
        assertEquals(0L, bad.startDelayMs)
        assertEquals(0, bad.maxCount)
        assertEquals(Limits.MAX_SECONDS, bad.maxSeconds)
    }

    @Test
    fun stepType_cycleAndCode() {
        assertEquals(StepType.LONG, StepType.TAP.next())
        assertEquals(StepType.SWIPE, StepType.LONG.next())
        assertEquals(StepType.TAP, StepType.SWIPE.next())
        assertEquals(StepType.SWIPE, StepType.fromCode("swipe"))
        assertEquals(StepType.TAP, StepType.fromCode("???"))
        assertEquals(StepType.TAP, StepType.fromCode(null))
    }
}

class UpdateParseTest {

    @Test
    fun buildNumber_prefersBodyThenAssetThenTag() {
        assertEquals(42, UpdateParse.buildNumber("Build #42", "AutoClicker-7.apk", "v9"))
        assertEquals(7, UpdateParse.buildNumber("no number", "AutoClicker-7.apk", "v9"))
        assertEquals(9, UpdateParse.buildNumber(null, "app.apk", "v9"))
        assertNull(UpdateParse.buildNumber("", "app.apk", "latest"))
    }

    @Test
    fun sha256_parsing() {
        val h = "a".repeat(64)
        assertEquals(h, UpdateParse.sha256("sha256:$h"))
        assertEquals(h, UpdateParse.sha256("${h.uppercase()}  AutoClicker-7.apk\n"))
        assertNull(UpdateParse.sha256("sha256:abc"))
        assertNull(UpdateParse.sha256(""))
        assertNull(UpdateParse.sha256(null))
    }
}
