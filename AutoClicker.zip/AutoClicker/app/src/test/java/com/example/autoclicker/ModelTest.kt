package com.example.autoclicker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class TimingTest {

    private val s = RunSettings(intervalMs = 500L)

    @Test
    fun stepDelay_usesGlobalWhenNoPerStepValue() {
        assertEquals(500L, Timing.stepDelay(s, emptyList(), 0))
        assertEquals(500L, Timing.stepDelay(s, listOf(-1L), 0))
        assertEquals(500L, Timing.stepDelay(s, listOf(100L), 3)) // ดัชนีเกินรายการ
    }

    @Test
    fun stepDelay_perStepOverrideAndMinimum() {
        assertEquals(1200L, Timing.stepDelay(s, listOf(1200L), 0))
        assertEquals(Limits.MIN_INTERVAL_MS, Timing.stepDelay(s, listOf(0L), 0))
    }

    @Test
    fun holdMs_defaultsByTypeAndPerPointOverride() {
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(StepType.TAP, emptyList(), 0))
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(StepType.TAP, listOf(-1L), 0))
        assertEquals(1500L, Timing.holdMs(StepType.TAP, listOf(1500L), 0))
        assertEquals(Limits.MAX_HOLD_MS, Timing.holdMs(StepType.TAP, listOf(999_999L), 0))
        assertEquals(Limits.MIN_HOLD_MS, Timing.holdMs(StepType.TAP, listOf(0L), 0))
    }

    @Test
    fun tapDuration_isLongEnoughForReliableTouchDelivery() {
        assertEquals(50L, Limits.TAP_DURATION_MS)
        assertEquals(30L, Timing.holdMs(StepType.TAP, listOf(1L), 0))
        assertEquals(Limits.TAP_DURATION_MS, Timing.holdMs(StepType.EYE, listOf(0L), 0))
    }

    @Test
    fun eyeConfirmation_toleratesOneNearFrame() {
        var score = EyeConfirmation.nextScore(0, hit = true, strong = false, near = false)
        assertFalse(EyeConfirmation.confirmed(score, hit = true, strong = false))
        score = EyeConfirmation.nextScore(score, hit = false, strong = false, near = true)
        assertEquals(1, score)
        assertFalse(EyeConfirmation.confirmed(score, hit = false, strong = false))
        score = EyeConfirmation.nextScore(score, hit = true, strong = false, near = false)
        assertTrue(EyeConfirmation.confirmed(score, hit = true, strong = false))
    }

    @Test
    fun eyeConfirmation_strongMatchIsImmediate() {
        val score = EyeConfirmation.nextScore(0, hit = true, strong = true, near = true)
        assertTrue(EyeConfirmation.confirmed(score, hit = true, strong = true))
    }

    @Test
    fun jitterDelay_zeroPercentIsIdentity() {
        assertEquals(500L, Timing.jitterDelay(500L, 0, Random(1)))
    }

    @Test
    fun jitterDelay_staysWithinBoundsAndVaries() {
        val rnd = Random(42)
        val seen = HashSet<Long>()
        repeat(2000) {
            val d = Timing.jitterDelay(1000L, 20, rnd)
            assertTrue("out of range: $d", d in 800L..1200L)
            seen.add(d)
        }
        assertTrue(seen.size > 50)
    }

    @Test
    fun jitterDelay_neverBelowMinimum() {
        val rnd = Random(7)
        repeat(1000) {
            assertTrue(Timing.jitterDelay(Limits.MIN_INTERVAL_MS, 90, rnd) >= Limits.MIN_INTERVAL_MS)
        }
    }

    @Test
    fun jitterCoord_radius() {
        val rnd = Random(3)
        assertEquals(100f, Timing.jitterCoord(100f, 0, rnd), 0f)
        repeat(500) {
            val v = Timing.jitterCoord(100f, 5, rnd)
            assertTrue(v in 95f..105f)
        }
    }

    @Test
    fun stopPolicy_countAndTime() {
        assertFalse(StopPolicy(0, 0).reached(1_000_000, Long.MAX_VALUE / 2))
        val byCount = StopPolicy(3, 0)
        assertFalse(byCount.reached(2, 0))
        assertTrue(byCount.reached(3, 0))
        val byTime = StopPolicy(0, 10)
        assertFalse(byTime.reached(5, 9_999))
        assertTrue(byTime.reached(5, 10_000))
    }

    @Test
    fun averagePeriod() {
        assertEquals(0.0, averagePeriodMs(0, 0), 0.0)
        assertEquals(0.0, averagePeriodMs(1, 100), 0.0)
        assertEquals(100.0, averagePeriodMs(11, 1000), 0.0001)
    }

    @Test
    fun settingsSanitized_clampsEverything() {
        val bad = RunSettings(
            intervalMs = 1, eyeScanIntervalMs = 1, jitterPercent = 500, posJitterPx = -5, startDelayMs = -1,
            maxCount = -3, maxSeconds = Int.MAX_VALUE
        ).sanitized()
        assertEquals(Limits.MIN_INTERVAL_MS, bad.intervalMs)
        assertEquals(Limits.MIN_EYE_SCAN_MS, bad.eyeScanIntervalMs)
        assertEquals(Limits.MAX_JITTER_PERCENT, bad.jitterPercent)
        assertEquals(0, bad.posJitterPx)
        assertEquals(0L, bad.startDelayMs)
        assertEquals(0, bad.maxCount)
        assertEquals(Limits.MAX_SECONDS, bad.maxSeconds)
    }

    @Test
    fun stepType_cycleAndCode() {
        assertEquals(StepType.EYE, StepType.fromCode("eye"))
        assertEquals(StepType.TAP, StepType.fromCode("long"))   // ชนิด L ถูกตัดออก: ข้อมูลเก่าโหลดเป็นแตะ
        assertEquals(StepType.TAP, StepType.fromCode("swipe"))
        assertEquals(StepType.TAP, StepType.fromCode("???"))
        assertEquals(StepType.TAP, StepType.fromCode(null))
    }
}

class TimeFmtTest {

    @Test
    fun format_perUnit() {
        assertEquals("500", TimeFmt.format(500, TimeUnitOpt.MS))
        assertEquals("0.5", TimeFmt.format(500, TimeUnitOpt.SEC))
        assertEquals("1.5", TimeFmt.format(1500, TimeUnitOpt.SEC))
        assertEquals("2", TimeFmt.format(2000, TimeUnitOpt.SEC))
        assertEquals("1.5", TimeFmt.format(90_000, TimeUnitOpt.MIN))
        assertEquals("60", TimeFmt.format(3_600_000, TimeUnitOpt.MIN))
        assertEquals("0", TimeFmt.format(0, TimeUnitOpt.SEC))
        assertEquals("0", TimeFmt.format(-5, TimeUnitOpt.MIN))
    }

    @Test
    fun parse_perUnit() {
        assertEquals(500L, TimeFmt.parse("500", TimeUnitOpt.MS))
        assertEquals(1500L, TimeFmt.parse("1.5", TimeUnitOpt.SEC))
        assertEquals(500L, TimeFmt.parse("0,5", TimeUnitOpt.SEC))
        assertEquals(500L, TimeFmt.parse(".5", TimeUnitOpt.SEC))
        assertEquals(5000L, TimeFmt.parse("5.", TimeUnitOpt.SEC))
        assertEquals(120_000L, TimeFmt.parse("2", TimeUnitOpt.MIN))
        assertEquals(90_000L, TimeFmt.parse(" 1.5 ", TimeUnitOpt.MIN))
        assertEquals(1235L, TimeFmt.parse("1.2345", TimeUnitOpt.SEC))   // ปัดครึ่งขึ้น
    }

    @Test
    fun parse_rejectsInvalid() {
        assertNull(TimeFmt.parse(null, TimeUnitOpt.MS))
        assertNull(TimeFmt.parse("", TimeUnitOpt.MS))
        assertNull(TimeFmt.parse(".", TimeUnitOpt.SEC))
        assertNull(TimeFmt.parse("abc", TimeUnitOpt.SEC))
        assertNull(TimeFmt.parse("-1", TimeUnitOpt.SEC))
        assertNull(TimeFmt.parse("1.2.3", TimeUnitOpt.SEC))
        assertNull(TimeFmt.parse("9".repeat(20), TimeUnitOpt.MS))
    }

    @Test
    fun roundTrip_secondsAndMsAreExact() {
        for (ms in listOf(10L, 250L, 999L, 1000L, 12_345L, 600_000L)) {
            assertEquals(ms, TimeFmt.parse(TimeFmt.format(ms, TimeUnitOpt.SEC), TimeUnitOpt.SEC))
            assertEquals(ms, TimeFmt.parse(TimeFmt.format(ms, TimeUnitOpt.MS), TimeUnitOpt.MS))
        }
    }

    @Test
    fun unit_fromCode() {
        assertEquals(TimeUnitOpt.MIN, TimeUnitOpt.fromCode("min"))
        assertEquals(TimeUnitOpt.MS, TimeUnitOpt.fromCode("???"))
        assertEquals(TimeUnitOpt.MS, TimeUnitOpt.fromCode(null))
    }
}

class UpdateParseTest {

    @Test
    fun buildNumber_prefersBodyThenAssetThenTag() {
        assertEquals(42, UpdateParse.buildNumber("Build #42", "AutoClicker-7.apk", "v9"))
        assertEquals(7, UpdateParse.buildNumber("no number", "AutoClicker-7.apk", "v9"))
        assertEquals(9, UpdateParse.buildNumber(null, "app.apk", "v9"))
        assertNull(UpdateParse.buildNumber("", "app.apk", "latest"))
    }

    @Test
    fun sha256_parsing() {
        val h = "a".repeat(64)
        assertEquals(h, UpdateParse.sha256("sha256:$h"))
        assertEquals(h, UpdateParse.sha256("${h.uppercase()}  AutoClicker-7.apk\n"))
        assertNull(UpdateParse.sha256("sha256:abc"))
        assertNull(UpdateParse.sha256(""))
        assertNull(UpdateParse.sha256(null))
    }
}
