package com.example.autoclicker

import kotlin.math.abs
import kotlin.math.sqrt

// ตรรกะจับภาพ/สี/ข้อความของ "ตา" — Kotlin ล้วน (ห้าม import android.*) เพื่อทดสอบด้วย unit test บน JVM ได้
// พิกเซลเป็น ARGB แบบ Android (Int)
object EyeMatch {
    private const val GRID = 32

    private fun r(p: Int) = (p shr 16) and 0xFF
    private fun g(p: Int) = (p shr 8) and 0xFF
    private fun b(p: Int) = p and 0xFF

    // ย่อภาพเป็นตารางเทา GRID×GRID โดยเฉลี่ยพิกเซลในแต่ละช่อง
    private fun grayGrid(px: IntArray, w: Int, h: Int): DoubleArray {
        val out = DoubleArray(GRID * GRID)
        if (w <= 0 || h <= 0 || px.size < w * h) return out
        for (gy in 0 until GRID) {
            val y0 = gy * h / GRID
            val y1 = maxOf(y0 + 1, (gy + 1) * h / GRID).coerceAtMost(h)
            for (gx in 0 until GRID) {
                val x0 = gx * w / GRID
                val x1 = maxOf(x0 + 1, (gx + 1) * w / GRID).coerceAtMost(w)
                var sum = 0.0
                var n = 0
                for (y in y0 until y1) for (x in x0 until x1) {
                    val p = px[y * w + x]
                    sum += 0.299 * r(p) + 0.587 * g(p) + 0.114 * b(p)
                    n++
                }
                out[gy * GRID + gx] = if (n > 0) sum / n else 0.0
            }
        }
        return out
    }

    // NCC บนส่วนที่ซ้อนกันของตาราง อนุญาตให้เหลื่อมได้เล็กน้อยเพื่อทนต่อพิกัด/การครอปที่คลาดกัน
    private fun correlation(a: DoubleArray, b: DoubleArray, dx: Int, dy: Int): Double {
        var sumA = 0.0
        var sumB = 0.0
        var count = 0
        for (y in 0 until GRID) {
            val by = y + dy
            if (by !in 0 until GRID) continue
            for (x in 0 until GRID) {
                val bx = x + dx
                if (bx !in 0 until GRID) continue
                sumA += a[y * GRID + x]
                sumB += b[by * GRID + bx]
                count++
            }
        }
        if (count == 0) return 0.0
        val meanA = sumA / count
        val meanB = sumB / count
        var covariance = 0.0
        var varianceA = 0.0
        var varianceB = 0.0
        for (y in 0 until GRID) {
            val by = y + dy
            if (by !in 0 until GRID) continue
            for (x in 0 until GRID) {
                val bx = x + dx
                if (bx !in 0 until GRID) continue
                val da = a[y * GRID + x] - meanA
                val db = b[by * GRID + bx] - meanB
                covariance += da * db
                varianceA += da * da
                varianceB += db * db
            }
        }
        val flatA = varianceA / count < 4.0
        val flatB = varianceB / count < 4.0
        if (flatA && flatB) return if (abs(meanA - meanB) <= 20.0) 1.0 else 0.0
        if (flatA || flatB) return 0.0
        // ค่าสัมบูรณ์ทำให้ลายเดิมยังตรงกันแม้สี/ความสว่างกลับขั้ว (เช่น ดำบนขาว → ขาวบนดำ)
        return abs(covariance / sqrt(varianceA * varianceB)).coerceIn(0.0, 1.0)
    }

    private data class EdgeFeature(val x: Int, val y: Int, val angle: Double)

    // ดึงขอบจาก Sobel gradient บนภาพ 32×32; threshold ปรับตามความเข้มขอบของภาพนั้นเอง
    private fun edgeFeatures(gray: DoubleArray): List<EdgeFeature> {
        val magnitude = DoubleArray(GRID * GRID)
        val angle = DoubleArray(GRID * GRID)
        var maxMagnitude = 0.0
        for (y in 1 until GRID - 1) for (x in 1 until GRID - 1) {
            val i = y * GRID + x
            val gx = -gray[i - GRID - 1] - 2.0 * gray[i - 1] - gray[i + GRID - 1] +
                gray[i - GRID + 1] + 2.0 * gray[i + 1] + gray[i + GRID + 1]
            val gy = -gray[i - GRID - 1] - 2.0 * gray[i - GRID] - gray[i - GRID + 1] +
                gray[i + GRID - 1] + 2.0 * gray[i + GRID] + gray[i + GRID + 1]
            val mag = sqrt(gx * gx + gy * gy)
            magnitude[i] = mag
            angle[i] = kotlin.math.atan2(gy, gx)
            if (mag > maxMagnitude) maxMagnitude = mag
        }
        if (maxMagnitude < 8.0) return emptyList()
        val threshold = maxOf(10.0, maxMagnitude * 0.22)
        val result = ArrayList<EdgeFeature>()
        for (y in 1 until GRID - 1) for (x in 1 until GRID - 1) {
            val i = y * GRID + x
            if (magnitude[i] >= threshold) result.add(EdgeFeature(x, y, angle[i]))
        }
        return result
    }

    private fun directionalEdgeCoverage(source: List<EdgeFeature>, target: List<EdgeFeature>): Double {
        if (source.isEmpty() || target.isEmpty()) return 0.0
        val targetGrid = arrayOfNulls<EdgeFeature>(GRID * GRID)
        target.forEach { targetGrid[it.y * GRID + it.x] = it }
        var total = 0.0
        for (a in source) {
            var best = 0.0
            for (dy in -2..2) for (dx in -2..2) {
                val x = a.x + dx
                val y = a.y + dy
                if (x !in 0 until GRID || y !in 0 until GRID) continue
                val b = targetGrid[y * GRID + x] ?: continue
                val distance = sqrt((dx * dx + dy * dy).toDouble())
                if (distance > 2.5) continue
                // ใช้ค่าสัมบูรณ์เพื่อให้ขอบเดิมยังจับคู่กันได้เมื่อสีสว่าง/มืดสลับกัน
                val orientation = kotlin.math.abs(kotlin.math.cos(a.angle - b.angle))
                if (orientation < 0.5) continue
                // โทษระยะทางแบบค่อยเป็นค่อยไป เพื่อไม่ให้การขยับ 1–2 พิกเซลทำคะแนนตกฮวบ
                val spatial = 1.0 / (1.0 + distance * 0.15)
                best = maxOf(best, spatial * (0.55 + 0.45 * orientation))
            }
            total += best
        }
        return total / source.size
    }

    // คะแนนรูปร่าง 0..1 แบบ symmetric Chamfer: วัดว่าขอบของทั้งสองภาพหาเพื่อนบ้านกันได้แค่ไหน
    fun shapeSimilarity(a: IntArray, aw: Int, ah: Int, b: IntArray, bw: Int, bh: Int): Float {
        if (aw <= 0 || ah <= 0 || bw <= 0 || bh <= 0 || a.size < aw * ah || b.size < bw * bh) return 0f
        val ga = grayGrid(a, aw, ah)
        val gb = grayGrid(b, bw, bh)
        val ea = edgeFeatures(ga)
        val eb = edgeFeatures(gb)
        if (ea.isEmpty() || eb.isEmpty()) {
            if (ea.isEmpty() && eb.isEmpty()) {
                val meanA = ga.average()
                val meanB = gb.average()
                return if (abs(meanA - meanB) <= 20.0) 1f else 0f
            }
            return 0f
        }
        val score = (directionalEdgeCoverage(ea, eb) + directionalEdgeCoverage(eb, ea)) / 2.0
        return score.toFloat().coerceIn(0f, 1f)
    }

    // ความเหมือนรวม: NCC ช่วยเรื่องลวดลาย/โทนภาพ ส่วน Shape score ช่วยจำโครงร่างเมื่อแสงและสีเปลี่ยน
    fun similarity(a: IntArray, aw: Int, ah: Int, b: IntArray, bw: Int, bh: Int): Float {
        if (aw <= 0 || ah <= 0 || bw <= 0 || bh <= 0 || a.size < aw * ah || b.size < bw * bh) return 0f
        val ga = grayGrid(a, aw, ah)
        val gb = grayGrid(b, bw, bh)
        var bestCorrelation = 0.0
        for (dy in -1..1) for (dx in -1..1) {
            bestCorrelation = maxOf(bestCorrelation, correlation(ga, gb, dx, dy))
        }
        val shape = run {
            val ea = edgeFeatures(ga)
            val eb = edgeFeatures(gb)
            if (ea.isEmpty() || eb.isEmpty()) {
                if (ea.isEmpty() && eb.isEmpty() && abs(ga.average() - gb.average()) <= 20.0) 1.0
                else 0.0
            } else {
                (directionalEdgeCoverage(ea, eb) + directionalEdgeCoverage(eb, ea)) / 2.0
            }
        }
        return (bestCorrelation * 0.60 + shape * 0.40).toFloat().coerceIn(0f, 1f)
    }

    private fun bin(p: Int) = ((r(p) shr 5) shl 6) or ((g(p) shr 5) shl 3) or (b(p) shr 5)

    private fun binColor(k: Int): Int {
        val rr = ((k shr 6) and 7) * 32 + 16
        val gg = ((k shr 3) and 7) * 32 + 16
        val bb = (k and 7) * 32 + 16
        return (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    }

    private fun colorDist(p: Int, c: Int): Double {
        val dr = (r(p) - r(c)).toDouble()
        val dg = (g(p) - g(c)).toDouble()
        val db = (b(p) - b(c)).toDouble()
        // ให้น้ำหนักช่องสีตามความไวของสายตามนุษย์ มากกว่าระยะ RGB แบบน้ำหนักเท่ากัน
        return sqrt(0.30 * dr * dr + 0.59 * dg * dg + 0.11 * db * db)
    }

    // สีที่พบมากสุดและสัดส่วน (ภาพว่าง → null)
    fun dominant(px: IntArray): Pair<Int, Float>? {
        if (px.isEmpty()) return null
        val counts = IntArray(512)
        px.forEach { counts[bin(it)]++ }
        var best = 0
        for (k in 1 until 512) if (counts[k] > counts[best]) best = k
        return binColor(best) to counts[best].toFloat() / px.size
    }

    // ภาพเกือบสีเดียวทั้งภาพ?
    fun isUniform(px: IntArray): Boolean = (dominant(px)?.second ?: 0f) >= 0.85f

    // เลือก "สีที่ใช้จับ": สีเด่นสุดที่ไม่ใช่พื้นหลัง (พื้นหลัง = สีที่พบมากสุด) ถ้าภาพเรียบใช้สีนั้นเลย
    // คืน (สี, สัดส่วนที่พบตอนล็อก)
    fun pickTargetColor(px: IntArray): Pair<Int, Float> {
        if (px.isEmpty()) return 0 to 0f
        val counts = IntArray(512)
        px.forEach { counts[bin(it)]++ }
        val order = (0 until 512).filter { counts[it] > 0 }.sortedByDescending { counts[it] }
        val bgBin = order.first()
        val bgColor = binColor(bgBin)
        // อย่าตัดสินว่าเป็นพื้นหลังล้วนเมื่อพื้นหลังเกิน 97%: ไอคอน/ข้อความเป้าหมายอาจมีพื้นที่น้อย
        // เลือกสีรองที่มีอย่างน้อย 1% และตัดกับพื้นหลังชัดเจน เพื่อลดการเลือก noise
        val fg = order.drop(1).firstOrNull {
            counts[it].toFloat() / px.size >= 0.01f && colorDist(binColor(it), bgColor) >= 60.0
        }
        val pick = fg ?: bgBin
        val c = binColor(pick)
        return c to colorFraction(px, c)
    }

    // สัดส่วนพิกเซลที่สีใกล้สีเป้าหมาย
    fun colorFraction(px: IntArray, color: Int, tol: Double = 68.0): Float {
        if (px.isEmpty()) return 0f
        var n = 0
        for (p in px) if (colorDist(p, color) <= tol) n++
        return n.toFloat() / px.size
    }

    fun colorThreshold(lockedFrac: Float): Float = maxOf(0.01f, lockedFrac.coerceIn(0f, 1f) * 0.45f)

    // พบสีที่ล็อกไว้ในกล่องเพียงพอ โดยเผื่อแสงและพิกเซลเปลี่ยนเล็กน้อย
    fun colorMatches(px: IntArray, color: Int, lockedFrac: Float): Boolean =
        colorFraction(px, color) >= colorThreshold(lockedFrac)

    // ตัดให้เหลือเฉพาะตัวอักษร/ตัวเลข ตัวพิมพ์เล็ก
    fun normText(s: String): String = buildString {
        for (ch in s) if (Character.isLetterOrDigit(ch)) append(ch.lowercaseChar())
    }

    // Levenshtein distance ใช้แก้ OCR ที่อ่านผิด/ตกหล่นตัวอักษรเล็กน้อย
    private fun editDistance(a: String, b: String): Int {
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + cost
                )
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    fun textThreshold(locked: String): Float = when (normText(locked).length) {
        0, 1, 2, 3 -> 1.0f
        in 4..5 -> 0.75f
        in 6..9 -> 0.82f
        else -> 0.86f
    }

    // คะแนนจับคู่ข้อความ 0..1: exact substring ได้ 1; หาก OCR ผิดเล็กน้อยจะเทียบหน้าต่างข้อความใกล้เคียง
    fun textSimilarity(live: String, locked: String): Float {
        val target = normText(locked)
        val actual = normText(live).take(240)
        if (target.isEmpty() || actual.isEmpty()) return 0f
        if (actual.contains(target)) return 1f
        if (target.length < 4) return 0f

        val minLen = maxOf(1, target.length - 2)
        val maxLen = minOf(actual.length, target.length + 2)
        var best = 0f
        for (len in minLen..maxLen) {
            for (start in 0..(actual.length - len)) {
                val candidate = actual.substring(start, start + len)
                val distance = editDistance(target, candidate)
                val score = 1f - distance.toFloat() / maxOf(target.length, candidate.length)
                if (score > best) best = score
                if (best >= 1f) return 1f
            }
        }
        return best.coerceIn(0f, 1f)
    }

    fun textMatches(live: String, locked: String): Boolean {
        val target = normText(locked)
        return target.isNotEmpty() && textSimilarity(live, locked) >= textThreshold(locked)
    }
}
