package com.example.autoclicker

import kotlin.math.abs
import kotlin.math.sqrt

// ตรรกะจับภาพ/สี/ข้อความของ "ตา" — Kotlin ล้วน (ห้าม import android.*) เพื่อทดสอบด้วย unit test บน JVM ได้
// พิกเซลเป็น ARGB แบบ Android (Int)
object EyeMatch {
    private const val GRID = 32

    private fun r(p: Int) = (p shr 16) and 0xFF
    private fun g(p: Int) = (p shr 8) and 0xFF
    private fun b(p: Int) = p and 0xFF

    // ย่อภาพเป็นตารางเทา GRID×GRID โดยเฉลี่ยพิกเซลในแต่ละช่อง
    private fun grayGrid(px: IntArray, w: Int, h: Int): DoubleArray {
        val out = DoubleArray(GRID * GRID)
        if (w <= 0 || h <= 0 || px.size < w * h) return out
        for (gy in 0 until GRID) {
            val y0 = gy * h / GRID
            val y1 = maxOf(y0 + 1, (gy + 1) * h / GRID).coerceAtMost(h)
            for (gx in 0 until GRID) {
                val x0 = gx * w / GRID
                val x1 = maxOf(x0 + 1, (gx + 1) * w / GRID).coerceAtMost(w)
                var sum = 0.0
                var n = 0
                for (y in y0 until y1) for (x in x0 until x1) {
                    val p = px[y * w + x]
                    sum += 0.299 * r(p) + 0.587 * g(p) + 0.114 * b(p)
                    n++
                }
                out[gy * GRID + gx] = if (n > 0) sum / n else 0.0
            }
        }
        return out
    }

    // ความเหมือนของสองภาพ 0..1 ด้วย normalized cross-correlation (ทนต่อความสว่างที่เปลี่ยน)
    // ภาพเรียบสนิททั้งคู่: เหมือนเมื่อระดับสีเทาต่างกันไม่เกิน 20
    fun similarity(a: IntArray, aw: Int, ah: Int, b: IntArray, bw: Int, bh: Int): Float {
        val ga = grayGrid(a, aw, ah)
        val gb = grayGrid(b, bw, bh)
        val n = ga.size
        val ma = ga.average()
        val mb = gb.average()
        var cov = 0.0
        var va = 0.0
        var vb = 0.0
        for (i in 0 until n) {
            val da = ga[i] - ma
            val db = gb[i] - mb
            cov += da * db
            va += da * da
            vb += db * db
        }
        val flatA = va / n < 4.0
        val flatB = vb / n < 4.0
        if (flatA && flatB) return if (abs(ma - mb) <= 20.0) 1f else 0f
        if (flatA || flatB) return 0f
        return (cov / sqrt(va * vb)).coerceIn(0.0, 1.0).toFloat()
    }

    private fun bin(p: Int) = ((r(p) shr 5) shl 6) or ((g(p) shr 5) shl 3) or (b(p) shr 5)

    private fun binColor(k: Int): Int {
        val rr = ((k shr 6) and 7) * 32 + 16
        val gg = ((k shr 3) and 7) * 32 + 16
        val bb = (k and 7) * 32 + 16
        return (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    }

    private fun colorDist(p: Int, c: Int): Double {
        val dr = (r(p) - r(c)).toDouble()
        val dg = (g(p) - g(c)).toDouble()
        val db = (b(p) - b(c)).toDouble()
        return sqrt(dr * dr + dg * dg + db * db)
    }

    // สีที่พบมากสุดและสัดส่วน (ภาพว่าง → null)
    fun dominant(px: IntArray): Pair<Int, Float>? {
        if (px.isEmpty()) return null
        val counts = IntArray(512)
        px.forEach { counts[bin(it)]++ }
        var best = 0
        for (k in 1 until 512) if (counts[k] > counts[best]) best = k
        return binColor(best) to counts[best].toFloat() / px.size
    }

    // ภาพเกือบสีเดียวทั้งภาพ?
    fun isUniform(px: IntArray): Boolean = (dominant(px)?.second ?: 0f) >= 0.85f

    // เลือก "สีที่ใช้จับ": สีเด่นสุดที่ไม่ใช่พื้นหลัง (พื้นหลัง = สีที่พบมากสุด) ถ้าภาพเรียบใช้สีนั้นเลย
    // คืน (สี, สัดส่วนที่พบตอนล็อก)
    fun pickTargetColor(px: IntArray): Pair<Int, Float> {
        if (px.isEmpty()) return 0 to 0f
        val counts = IntArray(512)
        px.forEach { counts[bin(it)]++ }
        val order = (0 until 512).filter { counts[it] > 0 }.sortedByDescending { counts[it] }
        val bgBin = order.first()
        val bgFrac = counts[bgBin].toFloat() / px.size
        if (bgFrac >= 0.97f) return binColor(bgBin) to bgFrac
        val bgColor = binColor(bgBin)
        val fg = order.drop(1).firstOrNull {
            counts[it].toFloat() / px.size >= 0.02f && colorDist(binColor(it), bgColor) >= 60.0
        }
        val pick = fg ?: bgBin
        val c = binColor(pick)
        return c to colorFraction(px, c)
    }

    // สัดส่วนพิกเซลที่สีใกล้สีเป้าหมาย (ระยะ RGB ไม่เกิน tol)
    fun colorFraction(px: IntArray, color: Int, tol: Double = 60.0): Float {
        if (px.isEmpty()) return 0f
        var n = 0
        for (p in px) if (colorDist(p, color) <= tol) n++
        return n.toFloat() / px.size
    }

    // พบสีที่ล็อกไว้ในกล่องเพียงพอ (อย่างน้อยครึ่งหนึ่งของที่เคยเห็นตอนล็อก และไม่ต่ำกว่า 1%)
    fun colorMatches(px: IntArray, color: Int, lockedFrac: Float): Boolean =
        colorFraction(px, color) >= maxOf(0.01f, lockedFrac * 0.5f)

    // ตัดให้เหลือเฉพาะตัวอักษร/ตัวเลข ตัวพิมพ์เล็ก (เปรียบเทียบข้อความที่ OCR อ่านได้แบบไม่สนช่องว่าง/เครื่องหมาย)
    fun normText(s: String): String = buildString {
        for (ch in s) if (Character.isLetterOrDigit(ch)) append(ch.lowercaseChar())
    }

    fun textMatches(live: String, locked: String): Boolean {
        val l = normText(locked)
        return l.isNotEmpty() && normText(live).contains(l)
    }
}
