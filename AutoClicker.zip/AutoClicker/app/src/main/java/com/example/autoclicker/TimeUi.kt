package com.example.autoclicker

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

fun unitLabel(ctx: Context, u: TimeUnitOpt): String = ctx.getString(
    when (u) {
        TimeUnitOpt.MS -> R.string.unit_ms
        TimeUnitOpt.SEC -> R.string.unit_sec
        TimeUnitOpt.MIN -> R.string.unit_min
    }
)

// ตัวเลื่อนเลือกหน่วยเวลา (มิลลิวินาที | วินาที | นาที): แตะหรือลากนิ้วข้ามได้ แถบสีเลื่อนตามอย่างนุ่มนวล
class UnitSlider(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val units = TimeUnitOpt.entries
    private val labels = units.map { unitLabel(context, it) }

    var onChange: ((TimeUnitOpt) -> Unit)? = null
    var selected: TimeUnitOpt = TimeUnitOpt.MS
        private set

    private var pos = 0f   // ตำแหน่งแถบสี 0..2 (เป็นทศนิยมระหว่างเลื่อน)
    private var anim: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2C2C2E") }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF3B30") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 13f, resources.displayMetrics)
    }

    // โหมดกะทัดรัด: แถบเตี้ยลง ตัวอักษรเล็กลง (ใช้ในหน้าต่างตั้งค่าเวลา)
    var compact: Boolean = false
        set(value) {
            field = value
            textPaint.textSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, if (value) 11f else 13f, resources.displayMetrics
            )
            requestLayout()
            invalidate()
        }

    init {
        contentDescription = labels[0]
    }

    fun select(u: TimeUnitOpt, animate: Boolean = true, notify: Boolean = false) {
        val changed = u != selected
        selected = u
        contentDescription = labels[units.indexOf(u)]
        val target = units.indexOf(u).toFloat()
        anim?.cancel()
        if (animate && isLaidOut) {
            anim = ValueAnimator.ofFloat(pos, target).apply {
                duration = 200
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    pos = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            pos = target
            invalidate()
        }
        if (changed && notify) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(u)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(resolveSize((300 * d).toInt(), widthMeasureSpec), ((if (compact) 32 else 44) * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        canvas.drawRoundRect(0f, 0f, w, h, r, r, trackPaint)

        val seg = w / units.size
        val pad = (if (compact) 3 else 4) * d
        canvas.drawRoundRect(pos * seg + pad, pad, pos * seg + seg - pad, h - pad, r - pad, r - pad, thumbPaint)

        val fm = textPaint.fontMetrics
        val y = h / 2f - (fm.ascent + fm.descent) / 2f
        labels.forEachIndexed { i, t ->
            textPaint.color = if (abs(pos - i) < 0.5f) Color.WHITE else Color.parseColor("#9A9AA0")
            canvas.drawText(t, seg * i + seg / 2f, y, textPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                pick(e.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                pick(e.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()

    private fun pick(x: Float) {
        val i = (x / (width.toFloat() / units.size)).toInt().coerceIn(0, units.size - 1)
        select(units[i], animate = true, notify = true)
    }
}

// ช่องกรอกเวลาที่ทำงานตามหน่วยที่เลือก: ค่าภายในเป็นมิลลิวินาที แสดง/พิมพ์เป็นมิลลิวินาที วินาที หรือนาที
// รูปแบบเรียบ ไม่มีกรอบกล่อง: ตัวเลขใหญ่ มีเส้นใต้ และชื่อหน่วยอยู่ท้ายช่อง
// valueMs < 0 = ช่องว่าง (ใช้ค่าเริ่มต้น) เมื่อ allowEmpty
class TimeField(
    private val ctx: Context,
    private val unitProvider: () -> TimeUnitOpt,
    initialMs: Long,
    private val minMs: Long,
    private val maxMs: Long,
    private val allowEmpty: Boolean,
    private val defaultMs: () -> Long?,
    private val onValue: (Long) -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    private var suppress = false

    var valueMs: Long = initialMs
        private set

    val edit = EditText(ctx).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#636366"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        setTypeface(typeface, Typeface.BOLD)
        setSingleLine()
        backgroundTintList = ColorStateList.valueOf(Color.parseColor("#48484A"))
        setPadding((2 * d).toInt(), (8 * d).toInt(), (2 * d).toInt(), (8 * d).toInt())
    }

    private val suffix = TextView(ctx).apply {
        setTextColor(Color.parseColor("#9A9AA0"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    }

    val view = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(suffix, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = (10 * d).toInt() })
    }

    init {
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppress) return
                val text = s?.toString().orEmpty()
                val ms = TimeFmt.parse(text, unitProvider())
                if (ms != null) {
                    valueMs = ms.coerceIn(minMs, maxMs)
                    onValue(valueMs)
                } else if (text.isBlank() && allowEmpty) {
                    valueMs = -1L
                    onValue(-1L)
                }
                // พิมพ์ค้างอยู่ในรูปที่ยังอ่านไม่ได้ (เช่น ".") = รอผู้ใช้พิมพ์ต่อ ไม่บันทึกอะไร
            }
        })
        // ออกจากช่อง = จัดรูปตัวเลขให้เรียบร้อย (เช่น ปรับค่าที่เกินช่วงให้พอดี)
        edit.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) refresh() }
        refresh()
    }

    // โหมดกะทัดรัด: ตัวเลขเล็กลง ช่องเตี้ยลง (ใช้ในหน้าต่างตั้งค่าเวลา; หน้าแอปหลักยังเป็นขนาดเดิม)
    fun compact() {
        edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        edit.setPadding((2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt())
        suffix.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        suffix.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = (6 * d).toInt() }
    }

    // แสดงค่าใหม่ตามหน่วยปัจจุบัน (เรียกเมื่อผู้ใช้เลื่อนเปลี่ยนหน่วย) — ไม่เขียนค่ากลับลงที่เก็บ จึงไม่มีค่าเพี้ยนจากการปัดเศษ
    fun refresh() {
        suppress = true
        val u = unitProvider()
        edit.setText(if (valueMs >= 0L) TimeFmt.format(valueMs, u) else "")
        edit.setSelection(edit.text.length)
        edit.hint = defaultMs()?.let { TimeFmt.format(it, u) } ?: ""
        suffix.text = unitLabel(ctx, u)
        suppress = false
    }
}
