package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bgBlack = Color.BLACK
    private val cardColor = Color.parseColor("#1C1C1E")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 14) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cardColor, 18)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) }
    }

    private fun btn(content: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = content
        setAllCaps(false)
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        background = rounded(bg)
        stateListAnimator = null
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(12) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgBlack
        window.navigationBarColor = bgBlack

        val prefs = getSharedPreferences(ClickService.PREFS, MODE_PRIVATE)

        // การ์ด 1: วิธีใช้
        val howTo = card().apply {
            addView(tv("วิธีใช้", 18f, Color.WHITE, true))
            addView(
                tv(
                    "1) เปิดการตั้งค่าการช่วยการเข้าถึง (Accessibility) แล้วเปิดใช้งานออโต้คลิก\n" +
                        "2) ตั้งช่วงเวลาระหว่างการแตะด้านล่าง\n" +
                        "3) ลากจุดสีแดงไปที่เป้าหมาย แล้วกดปุ่ม ▶\n" +
                        "4) กดปุ่ม ✕ เพื่อปิดออโต้คลิก (ต้องเปิดใหม่ในการช่วยการเข้าถึงถ้าจะใช้อีก)",
                    15f, Color.WHITE
                ).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.25f) }
            )
        }

        // การ์ด 2: ตั้งช่วงเวลา
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "เช่น 500"
            setHintTextColor(grayText)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            background = rounded(fieldColor, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setText(prefs.getLong(ClickService.KEY_INTERVAL, 500L).toString())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }
        val interval = card().apply {
            addView(tv("ช่วงเวลาระหว่างการแตะ (มิลลิวินาที)", 18f, Color.WHITE, true))
            addView(
                tv("ขั้นต่ำ ${ClickService.MIN_INTERVAL_MS} • 1000 มิลลิวินาที = 1 วินาที", 13f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(et)
            addView(btn("บันทึกช่วงเวลา", Color.parseColor("#3A3A3C")) {
                val v = et.text.toString().toLongOrNull()?.coerceAtLeast(ClickService.MIN_INTERVAL_MS) ?: 500L
                prefs.edit().putLong(ClickService.KEY_INTERVAL, v).apply()
                et.setText(v.toString())
                Toast.makeText(this@MainActivity, "บันทึกแล้ว: $v มิลลิวินาที", Toast.LENGTH_SHORT).show()
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            addView(tv("ออโต้คลิก", 30f, Color.WHITE, true))
            addView(
                tv("แตะหน้าจออัตโนมัติ • เวอร์ชัน ${BuildConfig.BUILD_NUMBER}", 14f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(howTo)
            addView(interval)
            addView(btn("เปิดตั้งค่าการช่วยการเข้าถึง", accent) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20)
            })
            addView(btn("ตรวจสอบอัปเดต", fieldColor) {
                UpdateChecker.check(this@MainActivity, false)
            })
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bgBlack)
            isFillViewport = true
            addView(root)
        })

        // เช็กอัปเดตเงียบๆ ตอนเปิดแอป (ถามเฉพาะเมื่อมีเวอร์ชันใหม่)
        UpdateChecker.check(this, true)
    }
}
