package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.widget.SeekBar
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bgBlack = Color.BLACK
    private val cardColor = Color.parseColor("#1C1C1E")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 14) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cardColor, 18)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) }
    }

    private fun btn(content: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = content
        setAllCaps(false)
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        background = rounded(bg)
        stateListAnimator = null
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(12) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgBlack
        window.navigationBarColor = bgBlack

        val prefs = getSharedPreferences(ClickService.PREFS, MODE_PRIVATE)

        // การ์ด 1: วิธีใช้
        val howTo = card().apply {
            addView(tv("วิธีใช้", 18f, Color.WHITE, true))
            addView(
                tv(
                    "1) เปิดการตั้งค่าการช่วยการเข้าถึง (Accessibility) แล้วเปิดใช้งานออโต้คลิก\n" +
                        "2) ตั้งช่วงเวลาระหว่างการแตะด้านล่าง\n" +
                        "3) ลากจุดสีแดงไปที่เป้าหมาย แล้วกดปุ่ม ▶\n" +
                        "4) กดปุ่ม ✕ เพื่อปิดออโต้คลิก (ต้องเปิดใหม่ในการช่วยการเข้าถึงถ้าจะใช้อีก)",
                    15f, Color.WHITE
                ).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.25f) }
            )
        }

        // การ์ด 2: ตั้งช่วงเวลา
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "เช่น 500"
            setHintTextColor(grayText)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            background = rounded(fieldColor, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setText(prefs.getLong(ClickService.KEY_INTERVAL, 500L).toString())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }
        val interval = card().apply {
            addView(tv("ช่วงเวลาระหว่างการแตะ (มิลลิวินาที)", 18f, Color.WHITE, true))
            addView(
                tv("ขั้นต่ำ ${ClickService.MIN_INTERVAL_MS} • 1000 มิลลิวินาที = 1 วินาที", 13f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(et)
            addView(btn("บันทึกช่วงเวลา", Color.parseColor("#3A3A3C")) {
                val v = et.text.toString().toLongOrNull()?.coerceAtLeast(ClickService.MIN_INTERVAL_MS) ?: 500L
                prefs.edit().putLong(ClickService.KEY_INTERVAL, v).apply()
                et.setText(v.toString())
                Toast.makeText(this@MainActivity, "บันทึกแล้ว: $v มิลลิวินาที", Toast.LENGTH_SHORT).show()
            })
        }


        // การ์ด 3: ขนาดปุ่ม (แผงเริ่ม/หยุด กับ จุดคลิก ปรับแยกกัน) + ตัวอย่างสด
        val panelPreview = PanelView(this)
        val markerPreview = MarkerView(this)
        fun previewColumn(view: View, caption: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(FrameLayout(this@MainActivity).apply {
                addView(view, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(96)))
            addView(tv(caption, 12f, grayText).apply { gravity = Gravity.CENTER })
        }
        fun showPanel(p: Int) { panelPreview.setScale(p) }
        fun showMarker(p: Int) {
            markerPreview.setScale(p)
            val size = markerPreview.sizePx(p)
            markerPreview.layoutParams = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        }
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(fieldColor, 14)
            setPadding(dp(8), dp(12), dp(8), dp(8))
            addView(previewColumn(panelPreview, "แผงเริ่ม/หยุด"),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(previewColumn(markerPreview, "จุดคลิก"),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }

        val seekBars = mutableListOf<Pair<SeekBar, TextView>>()
        fun sliderRow(title: String, key: String, onChange: (Int) -> Unit): LinearLayout {
            val cur = prefs.getInt(key, ClickService.DEFAULT_SCALE)
                .coerceIn(ClickService.MIN_SCALE, ClickService.MAX_SCALE)
            val valueText = tv("$cur%", 15f, Color.WHITE, true)
            val bar = SeekBar(this).apply {
                max = ClickService.MAX_SCALE - ClickService.MIN_SCALE
                progress = cur - ClickService.MIN_SCALE
                progressTintList = ColorStateList.valueOf(accent)
                thumbTintList = ColorStateList.valueOf(accent)
                progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#48484A"))
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                        val pct = value + ClickService.MIN_SCALE
                        valueText.text = "$pct%"
                        onChange(pct)
                        if (fromUser) prefs.edit().putInt(key, pct).apply()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            seekBars.add(bar to valueText)
            onChange(cur)
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(14) }
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    addView(tv(title, 15f, Color.WHITE),
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    addView(valueText)
                })
                addView(bar)
            }
        }

        val sizes = card().apply {
            addView(tv("ขนาดปุ่ม", 18f, Color.WHITE, true))
            addView(
                tv("เลื่อนเพื่อปรับ • ${ClickService.MIN_SCALE}–${ClickService.MAX_SCALE}% (ค่าเริ่มต้น ${ClickService.DEFAULT_SCALE}%) • ปรับแยกกันได้", 13f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(previewBox)
            addView(sliderRow("ขนาดแผงเริ่ม/หยุด", ClickService.KEY_PANEL_SCALE) { showPanel(it) })
            addView(sliderRow("ขนาดจุดคลิก", ClickService.KEY_MARKER_SCALE) { showMarker(it) })
            addView(btn("รีเซ็ตเป็น ${ClickService.DEFAULT_SCALE}%", Color.parseColor("#3A3A3C")) {
                prefs.edit()
                    .putInt(ClickService.KEY_PANEL_SCALE, ClickService.DEFAULT_SCALE)
                    .putInt(ClickService.KEY_MARKER_SCALE, ClickService.DEFAULT_SCALE)
                    .apply()
                seekBars.forEach { (bar, _) -> bar.progress = ClickService.DEFAULT_SCALE - ClickService.MIN_SCALE }
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            addView(tv("ออโต้คลิก", 30f, Color.WHITE, true))
            addView(
                tv("แตะหน้าจออัตโนมัติ • เวอร์ชัน ${BuildConfig.BUILD_NUMBER}", 14f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(howTo)
            addView(interval)
            addView(sizes)
            addView(btn("เปิดตั้งค่าการช่วยการเข้าถึง", accent) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20)
            })
            addView(btn("ตรวจสอบอัปเดต", fieldColor) {
                UpdateChecker.check(this@MainActivity, false)
            })
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bgBlack)
            isFillViewport = true
            addView(root)
        })

        // เช็กอัปเดตเงียบๆ ตอนเปิดแอป (ถามเฉพาะเมื่อมีเวอร์ชันใหม่)
        UpdateChecker.check(this, true)
    }
}
