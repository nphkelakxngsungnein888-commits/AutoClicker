package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : Activity() {

    private val bgBlack = Color.BLACK
    private val cardColor = Color.parseColor("#1C1C1E")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val buttonGray = Color.parseColor("#3A3A3C")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var statusButtons: LinearLayout
    private lateinit var lastRunText: TextView
    private lateinit var delayList: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 14) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cardColor, 18)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) }
    }

    private fun btn(content: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = content
        isAllCaps = false
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        background = rounded(bg)
        stateListAnimator = null
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(12) }
    }

    private fun fieldBox(initial: String, hint: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        this.hint = hint
        setHintTextColor(grayText)
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        background = rounded(fieldColor, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setText(initial)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) }
    }

    private fun watch(et: EditText, onChange: (String) -> Unit) {
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString().orEmpty())
            }
        })
    }

    // ช่องตัวเลขที่บันทึกอัตโนมัติทุกครั้งที่พิมพ์ (ไม่ต้องกดปุ่มบันทึก) และปรับค่าให้อยู่ในช่วงเมื่อออกจากช่อง
    private fun numberRow(
        title: String, sub: String, initial: Long, min: Long, max: Long, onSave: (Long) -> Unit
    ): LinearLayout {
        var last = initial
        val et = fieldBox(initial.toString(), "")
        watch(et) { text ->
            val v = text.toLongOrNull()
            if (v != null) {
                last = v.coerceIn(min, max)
                onSave(last)
            }
        }
        et.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) et.setText(last.toString())
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
            addView(tv(title, 16f, Color.WHITE, true))
            addView(tv(sub, 13f, grayText).apply { setPadding(0, dp(2), 0, 0) })
            addView(et)
        }
    }

    private fun intRow(title: String, sub: String, initial: Int, min: Int, max: Int, key: String) =
        numberRow(title, sub, initial.toLong(), min.toLong(), max.toLong()) {
            prefs.edit().putInt(key, it.toInt()).apply()
        }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean): LinearLayout {
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(title, 16f, Color.WHITE, true))
                addView(tv(sub, 13f, grayText).apply { setPadding(0, dp(2), dp(12), 0) })
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgBlack
        window.navigationBarColor = bgBlack

        prefs = ConfigStore.prefs(this)
        val st = ConfigStore.readSettings(prefs)

        // การ์ด 0: สถานะบริการ + ผลการคลิกครั้งล่าสุด
        statusText = tv("", 16f, Color.WHITE, true)
        lastRunText = tv("", 13f, grayText).apply { setPadding(0, dp(6), 0, 0) }
        statusButtons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val statusCard = card().apply {
            addView(statusText)
            addView(lastRunText)
            addView(statusButtons)
        }

        // การ์ด 1: วิธีใช้
        val howTo = card().apply {
            addView(tv(getString(R.string.howto_title), 18f, Color.WHITE, true))
            addView(
                tv(getString(R.string.howto_body, ClickService.MAX_POINTS), 15f, Color.WHITE)
                    .apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.25f) }
            )
        }

        // การ์ด 2: จังหวะการแตะ
        val timing = card().apply {
            addView(tv(getString(R.string.timing_title), 18f, Color.WHITE, true))
            addView(
                numberRow(
                    getString(R.string.interval_title),
                    getString(R.string.interval_sub, Limits.MIN_INTERVAL_MS),
                    st.intervalMs, Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS
                ) { prefs.edit().putLong(ConfigStore.KEY_INTERVAL, it).apply() }
            )
            addView(
                intRow(
                    getString(R.string.jitter_title), getString(R.string.jitter_sub, Limits.MAX_JITTER_PERCENT),
                    st.jitterPercent, 0, Limits.MAX_JITTER_PERCENT, ConfigStore.KEY_JITTER
                )
            )
            addView(
                intRow(
                    getString(R.string.pos_jitter_title), getString(R.string.pos_jitter_sub, Limits.MAX_POS_JITTER_PX),
                    st.posJitterPx, 0, Limits.MAX_POS_JITTER_PX, ConfigStore.KEY_POS_JITTER
                )
            )
            addView(
                numberRow(
                    getString(R.string.start_delay_title), getString(R.string.start_delay_sub),
                    st.startDelayMs, 0L, Limits.MAX_START_DELAY_MS
                ) { prefs.edit().putLong(ConfigStore.KEY_START_DELAY, it).apply() }
            )
        }

        // การ์ด 3: หน่วงรายจุด (สร้างใหม่ทุกครั้งที่กลับมาหน้านี้ เพราะจำนวนจุดอาจเปลี่ยน)
        delayList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val perPoint = card().apply {
            addView(tv(getString(R.string.perpoint_title), 18f, Color.WHITE, true))
            addView(tv(getString(R.string.perpoint_sub), 13f, grayText).apply { setPadding(0, dp(4), 0, 0) })
            addView(delayList)
        }

        // การ์ด 4: หยุดอัตโนมัติและความปลอดภัย
        val safety = card().apply {
            addView(tv(getString(R.string.safety_title), 18f, Color.WHITE, true))
            addView(
                intRow(
                    getString(R.string.max_count_title), getString(R.string.unlimited_hint),
                    st.maxCount, 0, Limits.MAX_COUNT, ConfigStore.KEY_MAX_COUNT
                )
            )
            addView(
                intRow(
                    getString(R.string.max_seconds_title), getString(R.string.unlimited_hint),
                    st.maxSeconds, 0, Limits.MAX_SECONDS, ConfigStore.KEY_MAX_SECONDS
                )
            )
            addView(
                switchRow(
                    getString(R.string.stop_screen_off_title), getString(R.string.stop_screen_off_sub),
                    ConfigStore.KEY_STOP_SCREEN_OFF, true
                )
            )
            addView(
                switchRow(
                    getString(R.string.stop_app_change_title), getString(R.string.stop_app_change_sub),
                    ConfigStore.KEY_STOP_APP_CHANGE, false
                )
            )
            addView(
                switchRow(
                    getString(R.string.hotkey_title), getString(R.string.hotkey_sub),
                    ConfigStore.KEY_HOTKEY, false
                )
            )
        }

        // การ์ด 5: โปรไฟล์
        val profiles = card().apply {
            addView(tv(getString(R.string.profiles_title), 18f, Color.WHITE, true))
            addView(tv(getString(R.string.profiles_sub), 13f, grayText).apply { setPadding(0, dp(4), 0, 0) })
            addView(btn(getString(R.string.profile_save), buttonGray) { promptSaveProfile() })
            addView(btn(getString(R.string.profile_load), buttonGray) { chooseProfile(delete = false) })
            addView(btn(getString(R.string.profile_delete), buttonGray) { chooseProfile(delete = true) })
        }

        // การ์ด 6: ขนาดปุ่ม (แผงเริ่ม/หยุด กับ จุดคลิก ปรับแยกกัน) + ตัวอย่างสด
        val panelPreview = PanelView(this)
        val markerPreview = MarkerView(this).apply { setLabel("1") }
        fun previewColumn(view: View, caption: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(FrameLayout(this@MainActivity).apply {
                addView(view, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(96)))
            addView(tv(caption, 12f, grayText).apply { gravity = Gravity.CENTER })
        }
        fun showPanel(p: Int) { panelPreview.setScale(p) }
        fun showMarker(p: Int) {
            markerPreview.setScale(p)
            val size = markerPreview.sizePx(p)
            markerPreview.layoutParams = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        }
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(fieldColor, 14)
            setPadding(dp(8), dp(12), dp(8), dp(8))
            addView(previewColumn(panelPreview, getString(R.string.preview_panel)),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(previewColumn(markerPreview, getString(R.string.preview_marker)),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }

        val seekBars = mutableListOf<SeekBar>()
        fun sliderRow(title: String, key: String, onChange: (Int) -> Unit): LinearLayout {
            val cur = prefs.getInt(key, Limits.DEFAULT_SCALE).coerceIn(Limits.MIN_SCALE, Limits.MAX_SCALE)
            val valueText = tv("$cur%", 15f, Color.WHITE, true)
            val bar = SeekBar(this).apply {
                max = Limits.MAX_SCALE - Limits.MIN_SCALE
                progress = cur - Limits.MIN_SCALE
                progressTintList = ColorStateList.valueOf(accent)
                thumbTintList = ColorStateList.valueOf(accent)
                progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#48484A"))
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                        val pct = value + Limits.MIN_SCALE
                        valueText.text = "$pct%"
                        onChange(pct)
                        if (fromUser) prefs.edit().putInt(key, pct).apply()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            seekBars.add(bar)
            onChange(cur)
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(14) }
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    addView(tv(title, 15f, Color.WHITE),
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    addView(valueText)
                })
                addView(bar)
            }
        }

        val sizes = card().apply {
            addView(tv(getString(R.string.sizes_title), 18f, Color.WHITE, true))
            addView(
                tv(getString(R.string.sizes_sub, Limits.MIN_SCALE, Limits.MAX_SCALE, Limits.DEFAULT_SCALE), 13f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(previewBox)
            addView(sliderRow(getString(R.string.size_panel), ConfigStore.KEY_PANEL_SCALE) { showPanel(it) })
            addView(sliderRow(getString(R.string.size_marker), ConfigStore.KEY_MARKER_SCALE) { showMarker(it) })
            addView(btn(getString(R.string.sizes_reset, Limits.DEFAULT_SCALE), buttonGray) {
                prefs.edit()
                    .putInt(ConfigStore.KEY_PANEL_SCALE, Limits.DEFAULT_SCALE)
                    .putInt(ConfigStore.KEY_MARKER_SCALE, Limits.DEFAULT_SCALE)
                    .apply()
                seekBars.forEach { it.progress = Limits.DEFAULT_SCALE - Limits.MIN_SCALE }
            })
        }

        // การ์ด 7: คำแนะนำเรื่องแบตเตอรี่ (บางยี่ห้อฆ่าบริการเบื้องหลัง)
        val battery = card().apply {
            addView(tv(getString(R.string.battery_title), 18f, Color.WHITE, true))
            addView(tv(getString(R.string.battery_body), 14f, grayText).apply { setPadding(0, dp(6), 0, 0) })
            addView(btn(getString(R.string.battery_button), buttonGray) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: ActivityNotFoundException) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            addView(tv(getString(R.string.app_name), 30f, Color.WHITE, true))
            addView(
                tv(getString(R.string.app_subtitle, BuildConfig.BUILD_NUMBER), 14f, grayText)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            addView(statusCard)
            addView(howTo)
            addView(timing)
            addView(perPoint)
            addView(safety)
            addView(profiles)
            addView(sizes)
            addView(battery)
            addView(btn(getString(R.string.check_update), fieldColor) {
                UpdateChecker.check(this@MainActivity, false)
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20)
            })
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bgBlack)
            isFillViewport = true
            clipToPadding = false
            addView(root)
        }
        // targetSdk 35 บังคับ edge-to-edge: เว้นขอบด้วย insets ของแถบระบบและรอยเว้ากล้อง
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            root.setPadding(dp(20) + b.left, dp(24) + b.top, dp(20) + b.right, dp(24) + b.bottom)
            insets
        }
        setContentView(scroll)

        // เช็กอัปเดตเงียบๆ ตอนเปิดแอป (ถามเฉพาะเมื่อมีเวอร์ชันใหม่ และไม่ถี่เกิน 6 ชม.)
        UpdateChecker.check(this, true)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshLastRun()
        refreshDelays()
    }

    // ---------- สถานะบริการ ----------

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, ClickService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun refreshStatus() {
        statusButtons.removeAllViews()
        val svc = ClickService.instance
        if (!isServiceEnabled()) {
            statusText.text = getString(R.string.status_off)
            statusText.setTextColor(accent)
            statusButtons.addView(btn(getString(R.string.open_accessibility), accent) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            return
        }
        statusText.setTextColor(Color.parseColor("#34C759"))
        if (svc == null) {
            statusText.text = getString(R.string.status_starting)
            return
        }
        statusText.text = getString(if (svc.overlaysVisible) R.string.status_on_visible else R.string.status_on_hidden)
        if (!svc.overlaysVisible) {
            statusButtons.addView(btn(getString(R.string.show_overlay), accent) {
                svc.showOverlays()
                refreshStatus()
            })
        }
        statusButtons.addView(btn(getString(R.string.stop_service), buttonGray) {
            svc.disableSelf()
            statusButtons.postDelayed({ refreshStatus() }, 500)
        })
    }

    private fun refreshLastRun() {
        val count = prefs.getInt(ConfigStore.KEY_LAST_COUNT, 0)
        if (count <= 0) {
            lastRunText.visibility = View.GONE
            return
        }
        val duration = prefs.getLong(ConfigStore.KEY_LAST_DURATION, 0L)
        val reason = runCatching { StopReason.valueOf(prefs.getString(ConfigStore.KEY_LAST_REASON, "") ?: "") }
            .getOrDefault(StopReason.MANUAL)
        val reasonText = getString(
            when (reason) {
                StopReason.MANUAL -> R.string.reason_manual
                StopReason.LIMIT -> R.string.reason_limit
                StopReason.SCREEN_OFF -> R.string.reason_screen_off
                StopReason.APP_CHANGED -> R.string.reason_app_changed
                StopReason.INTERRUPTED -> R.string.reason_interrupted
            }
        )
        val avg = averagePeriodMs(count, duration)
        val target = ConfigStore.readSettings(prefs).intervalMs
        val sb = StringBuilder()
        if (avg > 0.0) {
            sb.append(getString(R.string.lastrun_with_avg, count, avg, target, reasonText))
            // ช้ากว่าที่ตั้งมาก = เป็นขีดจำกัดของเครื่อง/ระบบ ไม่ใช่ความผิดพลาดของแอป
            if (avg > target * 1.3 && ConfigStore.readPoints(prefs).size <= 1) {
                sb.append('\n').append(getString(R.string.lastrun_slow_hint))
            }
        } else {
            sb.append(getString(R.string.lastrun_no_avg, count, reasonText))
        }
        lastRunText.text = sb.toString()
        lastRunText.visibility = View.VISIBLE
    }

    // ---------- หน่วงรายจุด ----------

    private fun refreshDelays() {
        delayList.removeAllViews()
        val pts = ConfigStore.readPoints(prefs)
        if (pts.isEmpty()) {
            delayList.addView(tv(getString(R.string.perpoint_empty), 14f, grayText).apply { setPadding(0, dp(8), 0, 0) })
            return
        }
        val delays = ConfigStore.readDelays(prefs)
        pts.forEachIndexed { i, p ->
            val typeLabel = getString(
                when (p.type) {
                    StepType.TAP -> R.string.type_tap
                    StepType.LONG -> R.string.type_long
                    StepType.SWIPE -> R.string.type_swipe
                }
            )
            val cur = delays.getOrNull(i) ?: -1L
            val et = fieldBox(if (cur >= 0L) cur.toString() else "", getString(R.string.perpoint_hint))
            var last = cur
            watch(et) { text ->
                val v = text.toLongOrNull()?.coerceIn(Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS) ?: -1L
                last = v
                val list = ConfigStore.readDelays(prefs).toMutableList()
                while (list.size <= i) list.add(-1L)
                list[i] = v
                ConfigStore.writeDelays(prefs, list)
            }
            et.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) et.setText(if (last >= 0L) last.toString() else "")
            }
            delayList.addView(tv(getString(R.string.perpoint_row, i + 1, typeLabel), 15f, Color.WHITE)
                .apply { setPadding(0, dp(12), 0, 0) })
            delayList.addView(et)
        }
    }

    // ---------- โปรไฟล์ ----------

    private fun promptSaveProfile() {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            hint = getString(R.string.profile_name_hint)
            setText(getString(R.string.profile_default_name, ConfigStore.listProfiles(prefs).size + 1))
            selectAll()
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.profile_save)
            .setView(et)
            .setPositiveButton(R.string.ok) { _, _ ->
                val name = et.text.toString().trim().take(40)
                if (name.isEmpty()) {
                    Toast.makeText(this, R.string.profile_name_empty, Toast.LENGTH_SHORT).show()
                } else if (ConfigStore.saveProfile(prefs, ConfigStore.currentProfile(prefs, name))) {
                    Toast.makeText(this, getString(R.string.profile_saved, name), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, getString(R.string.profile_full, ConfigStore.MAX_PROFILES), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun chooseProfile(delete: Boolean) {
        val list = ConfigStore.listProfiles(prefs)
        if (list.isEmpty()) {
            Toast.makeText(this, R.string.profile_none, Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (delete) R.string.profile_delete else R.string.profile_load)
            .setItems(list.map { it.name }.toTypedArray()) { _, which ->
                val p = list[which]
                if (delete) {
                    ConfigStore.deleteProfile(prefs, p.name)
                    Toast.makeText(this, getString(R.string.profile_deleted, p.name), Toast.LENGTH_SHORT).show()
                } else {
                    ConfigStore.applyProfile(prefs, p)
                    Toast.makeText(this, getString(R.string.profile_loaded, p.name), Toast.LENGTH_SHORT).show()
                    recreate()   // โหลดค่าใหม่ลงทุกช่องในหน้านี้
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
