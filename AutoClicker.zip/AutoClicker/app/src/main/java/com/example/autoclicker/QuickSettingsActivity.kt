package com.example.autoclicker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// ตั้งค่ามาตรฐานจากแผง: กดค้างมาตรฐานของปุ่มแตะ + หน่วงก่อนเริ่ม (เป็นค่าเดียวกับในหน้าแอป บันทึกอัตโนมัติ)
// เป็น Activity เพราะหน้าต่างลอยของบริการพิมพ์ตัวเลขไม่ได้
class QuickSettingsActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = ConfigStore.prefs(this)
        val unit = ConfigStore.readTimeUnit(prefs)
        val st = ConfigStore.readSettings(prefs)

        val holdField = TimeField(
            this, { unit }, ConfigStore.readDefaultHold(prefs),
            Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS, false, { null }
        ) { v -> prefs.edit().putLong(ConfigStore.KEY_DEFAULT_HOLD, v).apply() }
        val delayField = TimeField(
            this, { unit }, st.startDelayMs,
            0L, Limits.MAX_START_DELAY_MS, false, { null }
        ) { v -> prefs.edit().putLong(ConfigStore.KEY_START_DELAY, v).apply() }

        fun row(caption: String, field: TimeField) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#262629"), 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(tv(caption, 12f, Color.parseColor("#9A9AA0")))
            addView(field.view)
        }

        val match = LinearLayout.LayoutParams.MATCH_PARENT
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#1C1C1E"), 16)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(tv(getString(R.string.quick_title), 16f, Color.WHITE, true))
            addView(row(getString(R.string.quick_hold), holdField),
                LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })
            addView(row(getString(R.string.quick_delay), delayField),
                LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
            addView(Button(this@QuickSettingsActivity).apply {
                text = getString(R.string.timeset_done)
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                background = rounded(Color.parseColor("#FF3B30"), 12)
                stateListAnimator = null
                setOnClickListener { finish() }
            }, LinearLayout.LayoutParams(match, dp(44)).apply { topMargin = dp(14) })
        }
        setContentView(ScrollView(this).apply { addView(root) })
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
