package com.example.autoclicker

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.random.Random

// ไฟล์นี้ต้องเป็น Kotlin ล้วน (ห้าม import android.*) เพื่อให้ทดสอบด้วย unit test บน JVM ได้

object Limits {
    const val MIN_INTERVAL_MS = 10L        // ช่วงเวลาขั้นต่ำระหว่างการแตะ
    const val MAX_INTERVAL_MS = 3_600_000L // 1 ชั่วโมง
    const val MIN_EYE_SCAN_MS = 100L
    const val MAX_EYE_SCAN_MS = 60_000L
    const val TAP_DURATION_MS = 50L        // ระยะเวลาของการแตะแต่ละครั้ง (ค่าเริ่มต้น)
    const val MIN_HOLD_MS = 30L
    const val MAX_HOLD_MS = 60_000L        // ท่าทางยาวสุดที่ Android รับได้ ~60 วินาที
    const val LONG_PRESS_MS = 600L         // ระยะเวลากดค้าง
    const val MAX_JITTER_PERCENT = 90
    const val MAX_POS_JITTER_PX = 100
    const val MAX_START_DELAY_MS = 600_000L
    const val MAX_COUNT = 10_000_000
    const val MAX_SECONDS = 86_400
    const val MIN_SCALE = 30
    const val MAX_SCALE = 150
    const val DEFAULT_SCALE = 100
}

enum class StepType(val code: String) {
    TAP("tap"), LONG("long"), EYE("eye");

    fun next(): StepType = when (this) {
        TAP -> LONG
        LONG -> TAP
        EYE -> EYE   // ตา: สร้างจากปุ่มตาเท่านั้น ไม่อยู่ในวงสลับชนิด
    }

    companion object {
        // โปรไฟล์เก่าที่เคยมีจุดลากจะแปลงเป็นแตะ เพื่อให้โหลดต่อได้โดยไม่พัง
        fun fromCode(code: String?): StepType = when (code) {
            "tap" -> TAP
            "long" -> LONG
            "eye" -> EYE
            "swipe" -> TAP
            else -> TAP
        }
    }
}

// ตัวตรวจจับของ "ตา": อัตโนมัติ = ให้แอปเลือกให้ตอนล็อก (ข้อความ → สีล้วน → รูป)
enum class EyeMode(val code: String) {
    AUTO("auto"), IMAGE("image"), TEXT("text"), COLOR("color");

    fun next(): EyeMode = entries[(ordinal + 1) % entries.size]

    companion object {
        fun fromCode(code: String?): EyeMode = entries.firstOrNull { it.code == code } ?: AUTO
    }
}

// ค่าของตาหนึ่งตัว: mode = ที่ผู้ใช้เลือก, kind = ชนิดจริงที่ใช้ตรวจ (ได้ตอนล็อก, ไม่เป็น AUTO)
// file ว่าง = ยังไม่ล็อก (ยังไม่มีภาพอ้างอิง) → ตาจะไม่แตะอะไร
data class EyeCfg(
    val mode: EyeMode = EyeMode.AUTO,
    val kind: EyeMode = EyeMode.IMAGE,
    val text: String = "",
    val color: Int = 0,
    val colorFrac: Float = 0f,
    val threshold: Int = 90,   // ความเหมือนของรูป (เปอร์เซ็นต์)
    val file: String = ""      // ชื่อไฟล์ภาพอ้างอิงใน filesDir
) {
    val locked: Boolean get() = file.isNotEmpty()
}

// พิกัดเป็น "จุดกึ่งกลาง" ในระบบพิกัดของหน้าต่างลอย
// EYE: (x2,y2) = (กว้าง,สูง) ของกล่อง และ eye = ค่าตรวจจับ
data class ClickPoint(
    val type: StepType = StepType.TAP,
    val x: Int,
    val y: Int,
    val x2: Int = x,
    val y2: Int = y,
    val eye: EyeCfg? = null
)

data class RunSettings(
    val intervalMs: Long = 500L,
    val eyeScanIntervalMs: Long = 500L, // ความถี่ตั้งต้นของการอ่านภาพ; ระบบ Android อาจบังคับช่วงห่างมากกว่า
    val jitterPercent: Int = 0,
    val posJitterPx: Int = 0,
    val startDelayMs: Long = 0L,
    val maxCount: Int = 0,          // 0 = ไม่จำกัด
    val maxSeconds: Int = 0,        // 0 = ไม่จำกัด
    val stopOnScreenOff: Boolean = true,
    val stopOnAppChange: Boolean = false,
    val volumeHotkey: Boolean = false
) {
    // บังคับให้ค่าอยู่ในช่วงที่ปลอดภัยเสมอ (กันค่าเสียจากไฟล์/โปรไฟล์)
    fun sanitized() = copy(
        intervalMs = intervalMs.coerceIn(Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS),
        eyeScanIntervalMs = eyeScanIntervalMs.coerceIn(Limits.MIN_EYE_SCAN_MS, Limits.MAX_EYE_SCAN_MS),
        jitterPercent = jitterPercent.coerceIn(0, Limits.MAX_JITTER_PERCENT),
        posJitterPx = posJitterPx.coerceIn(0, Limits.MAX_POS_JITTER_PX),
        startDelayMs = startDelayMs.coerceIn(0L, Limits.MAX_START_DELAY_MS),
        maxCount = maxCount.coerceIn(0, Limits.MAX_COUNT),
        maxSeconds = maxSeconds.coerceIn(0, Limits.MAX_SECONDS)
    )
}

// delays: ช่วงห่างการทำงานรายจุด (มิลลิวินาที) ค่า < 0 หรือไม่มี = ใช้ช่วงเวลากลาง
data class Profile(
    val name: String,
    val settings: RunSettings,
    val points: List<ClickPoint>,
    val delays: List<Long>,
    // เวลากดรายจุด (มิลลิวินาที) ค่า < 0 หรือไม่มี = ใช้ค่าเริ่มต้นตามชนิดจุด
    val holds: List<Long> = emptyList()
)

enum class StopReason { MANUAL, LIMIT, SCREEN_OFF, APP_CHANGED, INTERRUPTED }

object Timing {

    fun stepDelay(settings: RunSettings, delays: List<Long>, index: Int): Long {
        val d = delays.getOrNull(index) ?: -1L
        val base = if (d >= 0L) d else settings.intervalMs
        return base.coerceIn(Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS)
    }

    // สุ่มเวลา ±percent% รอบค่ากลาง (ไม่ต่ำกว่าขั้นต่ำ)
    fun jitterDelay(base: Long, percent: Int, rnd: Random): Long {
        val p = percent.coerceIn(0, Limits.MAX_JITTER_PERCENT)
        if (p == 0) return base
        val span = base * p / 100
        if (span <= 0L) return base
        return (base + rnd.nextLong(-span, span + 1)).coerceAtLeast(Limits.MIN_INTERVAL_MS)
    }

    fun jitterCoord(v: Float, radius: Int, rnd: Random): Float =
        if (radius <= 0) v else v + rnd.nextInt(-radius, radius + 1)

    fun gestureDurationMs(type: StepType): Long = when (type) {
        StepType.TAP -> Limits.TAP_DURATION_MS
        StepType.LONG -> Limits.LONG_PRESS_MS
        StepType.EYE -> Limits.TAP_DURATION_MS   // ตาเจอแล้วแตะกลางกล่อง
    }

    // เวลากดของจุดที่ index: ใช้ค่าที่ผู้ใช้ตั้งรายจุด ถ้าไม่ได้ตั้งใช้ค่าเริ่มต้นตามชนิด
    fun holdMs(type: StepType, holds: List<Long>, index: Int): Long {
        val h = holds.getOrNull(index) ?: -1L
        return if (h >= 0L) h.coerceIn(Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS) else gestureDurationMs(type)
    }
}

// คะแนนยืนยันภาพแบบทนเฟรมแกว่ง: hit เพิ่มคะแนน, near คงคะแนน, miss ล้างคะแนน
object EyeConfirmation {
    fun nextScore(current: Int, hit: Boolean, strong: Boolean, near: Boolean): Int = when {
        strong -> 2
        hit -> (current + 1).coerceAtMost(2)
        near -> current.coerceIn(0, 2)
        else -> 0
    }

    fun confirmed(score: Int, hit: Boolean, strong: Boolean): Boolean = strong || (hit && score >= 2)
}

class StopPolicy(private val maxCount: Int, private val maxSeconds: Int) {
    fun reached(count: Int, elapsedMs: Long): Boolean =
        (maxCount > 0 && count >= maxCount) ||
            (maxSeconds > 0 && elapsedMs >= maxSeconds * 1000L)
}

// ค่าเฉลี่ยคาบจริงระหว่างการแตะ (มิลลิวินาที) จากเวลาแตะครั้งแรกถึงครั้งสุดท้าย
fun averagePeriodMs(count: Int, durationMs: Long): Double =
    if (count > 1 && durationMs >= 0) durationMs.toDouble() / (count - 1) else 0.0

object UpdateParse {
    private val bodyRe = Regex("Build\\s*#(\\d+)")
    private val nameRe = Regex("(\\d+)\\.apk$", RegexOption.IGNORE_CASE)
    private val tagRe = Regex("(\\d+)$")
    private val hexRe = Regex("^[0-9a-fA-F]{64}$")

    // หาเลข Build จาก body → ชื่อไฟล์ .apk → ชื่อ tag ตามลำดับ
    fun buildNumber(body: String?, apkName: String?, tag: String?): Int? =
        body?.let { bodyRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?: apkName?.let { nameRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?: tag?.let { tagRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }

    // รับ "sha256:<hex>" หรือไฟล์ .sha256 รูปแบบ "<hex>  filename"
    fun sha256(text: String?): String? {
        val token = text?.trim()?.removePrefix("sha256:")?.trim()?.split(Regex("\\s+"))?.firstOrNull()
        return token?.takeIf { hexRe.matches(it) }?.lowercase()
    }
}

// หน่วยเวลาที่ผู้ใช้เลือกแสดง/พิมพ์ (ค่าภายในเก็บเป็นมิลลิวินาทีเสมอ)
enum class TimeUnitOpt(val code: String, val factor: Long, val maxDecimals: Int) {
    MS("ms", 1L, 0), SEC("s", 1_000L, 3), MIN("min", 60_000L, 4);

    companion object {
        fun fromCode(code: String?): TimeUnitOpt = entries.firstOrNull { it.code == code } ?: MS
    }
}

object TimeFmt {
    private val numberRe = Regex("^(\\d+\\.?\\d*|\\.\\d+)$")

    // มิลลิวินาที → ข้อความในหน่วยที่เลือก (ปัดเศษตามจำนวนทศนิยมสูงสุดของหน่วย ตัดศูนย์ท้าย)
    fun format(ms: Long, unit: TimeUnitOpt): String {
        if (ms <= 0L) return "0"
        val v = BigDecimal(ms).divide(BigDecimal(unit.factor), unit.maxDecimals, RoundingMode.HALF_UP)
        return if (v.signum() == 0) "0" else v.stripTrailingZeros().toPlainString()
    }

    // ข้อความในหน่วยที่เลือก → มิลลิวินาที (รับจุดหรือจุลภาคเป็นทศนิยม) ไม่ถูกต้อง/ว่าง = null
    fun parse(text: String?, unit: TimeUnitOpt): Long? {
        val t = text?.trim()?.replace(',', '.') ?: return null
        if (t.isEmpty() || t.length > 12 || !numberRe.matches(t)) return null
        return BigDecimal(t).multiply(BigDecimal(unit.factor)).setScale(0, RoundingMode.HALF_UP).toLong()
    }
}
