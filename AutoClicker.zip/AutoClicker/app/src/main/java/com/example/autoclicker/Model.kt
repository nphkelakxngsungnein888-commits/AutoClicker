package com.example.autoclicker

import kotlin.random.Random

// ไฟล์นี้ต้องเป็น Kotlin ล้วน (ห้าม import android.*) เพื่อให้ทดสอบด้วย unit test บน JVM ได้

object Limits {
    const val MIN_INTERVAL_MS = 10L        // ช่วงเวลาขั้นต่ำระหว่างการแตะ
    const val MAX_INTERVAL_MS = 3_600_000L // 1 ชั่วโมง
    const val TAP_DURATION_MS = 10L        // ระยะเวลาของการแตะแต่ละครั้ง (ค่าเริ่มต้น)
    const val MIN_HOLD_MS = 1L
    const val MAX_HOLD_MS = 60_000L        // ท่าทางยาวสุดที่ Android รับได้ ~60 วินาที
    const val LONG_PRESS_MS = 600L         // ระยะเวลากดค้าง
    const val SWIPE_MS = 300L              // ระยะเวลาปัด
    const val MAX_JITTER_PERCENT = 90
    const val MAX_POS_JITTER_PX = 100
    const val MAX_START_DELAY_MS = 600_000L
    const val MAX_COUNT = 10_000_000
    const val MAX_SECONDS = 86_400
    const val MIN_SCALE = 30
    const val MAX_SCALE = 150
    const val DEFAULT_SCALE = 100
}

enum class StepType(val code: String) {
    TAP("tap"), LONG("long"), SWIPE("swipe");

    fun next(): StepType = when (this) {
        TAP -> LONG
        LONG -> SWIPE
        SWIPE -> TAP
    }

    companion object {
        fun fromCode(code: String?): StepType = entries.firstOrNull { it.code == code } ?: TAP
    }
}

// พิกัดเป็น "จุดกึ่งกลาง" ในระบบพิกัดของหน้าต่างลอย (x2,y2 ใช้เฉพาะ SWIPE)
data class ClickPoint(
    val type: StepType = StepType.TAP,
    val x: Int,
    val y: Int,
    val x2: Int = x,
    val y2: Int = y
)

data class RunSettings(
    val intervalMs: Long = 500L,
    val jitterPercent: Int = 0,
    val posJitterPx: Int = 0,
    val startDelayMs: Long = 0L,
    val maxCount: Int = 0,          // 0 = ไม่จำกัด
    val maxSeconds: Int = 0,        // 0 = ไม่จำกัด
    val stopOnScreenOff: Boolean = true,
    val stopOnAppChange: Boolean = false,
    val volumeHotkey: Boolean = false
) {
    // บังคับให้ค่าอยู่ในช่วงที่ปลอดภัยเสมอ (กันค่าเสียจากไฟล์/โปรไฟล์)
    fun sanitized() = copy(
        intervalMs = intervalMs.coerceIn(Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS),
        jitterPercent = jitterPercent.coerceIn(0, Limits.MAX_JITTER_PERCENT),
        posJitterPx = posJitterPx.coerceIn(0, Limits.MAX_POS_JITTER_PX),
        startDelayMs = startDelayMs.coerceIn(0L, Limits.MAX_START_DELAY_MS),
        maxCount = maxCount.coerceIn(0, Limits.MAX_COUNT),
        maxSeconds = maxSeconds.coerceIn(0, Limits.MAX_SECONDS)
    )
}

// delays: หน่วงหลังแตะแต่ละจุด (มิลลิวินาที) ค่า < 0 หรือไม่มี = ใช้ช่วงเวลากลาง
data class Profile(
    val name: String,
    val settings: RunSettings,
    val points: List<ClickPoint>,
    val delays: List<Long>,
    // เวลากด/ปัดรายจุด (มิลลิวินาที) ค่า < 0 หรือไม่มี = ใช้ค่าเริ่มต้นตามชนิดจุด
    val holds: List<Long> = emptyList()
)

enum class StopReason { MANUAL, LIMIT, SCREEN_OFF, APP_CHANGED, INTERRUPTED }

object Timing {

    fun stepDelay(settings: RunSettings, delays: List<Long>, index: Int): Long {
        val d = delays.getOrNull(index) ?: -1L
        val base = if (d >= 0L) d else settings.intervalMs
        return base.coerceIn(Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS)
    }

    // สุ่มเวลา ±percent% รอบค่ากลาง (ไม่ต่ำกว่าขั้นต่ำ)
    fun jitterDelay(base: Long, percent: Int, rnd: Random): Long {
        val p = percent.coerceIn(0, Limits.MAX_JITTER_PERCENT)
        if (p == 0) return base
        val span = base * p / 100
        if (span <= 0L) return base
        return (base + rnd.nextLong(-span, span + 1)).coerceAtLeast(Limits.MIN_INTERVAL_MS)
    }

    fun jitterCoord(v: Float, radius: Int, rnd: Random): Float =
        if (radius <= 0) v else v + rnd.nextInt(-radius, radius + 1)

    fun gestureDurationMs(type: StepType): Long = when (type) {
        StepType.TAP -> Limits.TAP_DURATION_MS
        StepType.LONG -> Limits.LONG_PRESS_MS
        StepType.SWIPE -> Limits.SWIPE_MS
    }

    // เวลากดของจุดที่ index: ใช้ค่าที่ผู้ใช้ตั้งรายจุด ถ้าไม่ได้ตั้งใช้ค่าเริ่มต้นตามชนิด
    fun holdMs(type: StepType, holds: List<Long>, index: Int): Long {
        val h = holds.getOrNull(index) ?: -1L
        return if (h >= 0L) h.coerceIn(Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS) else gestureDurationMs(type)
    }
}

class StopPolicy(private val maxCount: Int, private val maxSeconds: Int) {
    fun reached(count: Int, elapsedMs: Long): Boolean =
        (maxCount > 0 && count >= maxCount) ||
            (maxSeconds > 0 && elapsedMs >= maxSeconds * 1000L)
}

// ค่าเฉลี่ยคาบจริงระหว่างการแตะ (มิลลิวินาที) จากเวลาแตะครั้งแรกถึงครั้งสุดท้าย
fun averagePeriodMs(count: Int, durationMs: Long): Double =
    if (count > 1 && durationMs >= 0) durationMs.toDouble() / (count - 1) else 0.0

object UpdateParse {
    private val bodyRe = Regex("Build\\s*#(\\d+)")
    private val nameRe = Regex("(\\d+)\\.apk$", RegexOption.IGNORE_CASE)
    private val tagRe = Regex("(\\d+)$")
    private val hexRe = Regex("^[0-9a-fA-F]{64}$")

    // หาเลข Build จาก body → ชื่อไฟล์ .apk → ชื่อ tag ตามลำดับ
    fun buildNumber(body: String?, apkName: String?, tag: String?): Int? =
        body?.let { bodyRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?: apkName?.let { nameRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?: tag?.let { tagRe.find(it)?.groupValues?.get(1)?.toIntOrNull() }

    // รับ "sha256:<hex>" หรือไฟล์ .sha256 รูปแบบ "<hex>  filename"
    fun sha256(text: String?): String? {
        val token = text?.trim()?.removePrefix("sha256:")?.trim()?.split(Regex("\\s+"))?.firstOrNull()
        return token?.takeIf { hexRe.matches(it) }?.lowercase()
    }
}
