package com.example.autoclicker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

// ที่เก็บการตั้งค่าทั้งหมด (SharedPreferences) — ใช้ร่วมกันระหว่างหน้าตั้งค่ากับ ClickService
// ความเป็นเจ้าของข้อมูล: จุดคลิก/ตำแหน่งแผง = ClickService, ช่วงหน่วงรายจุด/ค่าตั้งค่าอื่น = MainActivity
object ConfigStore {
    const val PREFS = "cfg"

    // คงคีย์เดิมไว้เพื่อให้ผู้ใช้เก่าไม่เสียค่าที่ตั้งไว้
    const val KEY_INTERVAL = "interval"
    const val KEY_EYE_SCAN_INTERVAL = "eye_scan_interval"
    const val KEY_PANEL_SCALE = "panel_scale"
    const val KEY_MARKER_SCALE = "marker_scale"

    const val KEY_JITTER = "jitter_pct"
    const val KEY_POS_JITTER = "pos_jitter_px"
    const val KEY_START_DELAY = "start_delay_ms"
    const val KEY_MAX_COUNT = "max_count"
    const val KEY_MAX_SECONDS = "max_seconds"
    const val KEY_STOP_SCREEN_OFF = "stop_screen_off"
    const val KEY_STOP_APP_CHANGE = "stop_app_change"
    const val KEY_HOTKEY = "volume_hotkey"
    const val KEY_SEQUENTIAL = "sequential_mode"   // true = โหมดเรียงลำดับ 1 → 2 → 3

    const val KEY_POINTS = "points"
    const val KEY_DELAYS = "delays"
    const val KEY_HOLDS = "holds"
    const val KEY_STRENGTHS = "strengths"            // ความแรงลากรายจุด
    const val KEY_COUNTS = "counts"                  // จำนวนครั้งที่กดต่อรอบรายปุ่ม (โหมดเรียงลำดับ)
    const val KEY_DRAG_STRENGTH = "drag_strength_default"   // ความแรงลากมาตรฐาน (ตั้งในแอป)
    const val KEY_TIME_UNIT = "time_unit"
    const val KEY_DEFAULT_HOLD = "default_hold"     // กดค้างมาตรฐานของปุ่มแตะ (ms) — ใช้เมื่อปุ่มนั้นไม่ได้ตั้งกดค้างรายปุ่ม
    const val KEY_PANEL_FOLDED = "panel_folded"    // แผงเครื่องมือถูกพับอยู่ (เหลือแค่ปุ่มเริ่ม/หยุด + ปุ่มพับ)
    const val KEY_PANEL_X = "panel_x"
    const val KEY_PANEL_Y = "panel_y"
    const val KEY_TS_W = "timeset_w"          // ขนาด/ตำแหน่งหน้าต่างตั้งค่าเวลา (px; x,y = ระยะเยื้องจากกึ่งกลางจอ)
    const val KEY_TS_H = "timeset_h"
    const val KEY_TS_X = "timeset_x"
    const val KEY_TS_Y = "timeset_y"
    const val KEY_REV = "profile_rev"          // เพิ่มค่าเมื่อโหลดโปรไฟล์ → ให้ ClickService สร้างปุ่มลอยใหม่
    const val KEY_PROFILES = "profiles"
    const val KEY_SELECTED = "sel_point"        // ปุ่มที่ถูกเลือกในหน้าตั้งค่าเวลา (นับจาก 0)
    const val KEY_ONLY_PLAY = "only_play"       // "เล่นเฉพาะ": "i,j|จำนวนปุ่มตอนเลือก" (ปุ่มนับจาก 0)

    const val KEY_LAST_COUNT = "last_count"
    const val KEY_LAST_DURATION = "last_duration_ms"
    const val KEY_LAST_REASON = "last_reason"
    const val KEY_LAST_UPDATE_CHECK = "last_update_check"

    const val MAX_PROFILES = 30

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- การตั้งค่าการทำงาน ----------

    fun readSettings(p: SharedPreferences) = RunSettings(
        intervalMs = p.getLong(KEY_INTERVAL, 500L),
        eyeScanIntervalMs = p.getLong(KEY_EYE_SCAN_INTERVAL, 500L),
        jitterPercent = p.getInt(KEY_JITTER, 0),
        posJitterPx = p.getInt(KEY_POS_JITTER, 0),
        startDelayMs = p.getLong(KEY_START_DELAY, 0L),
        maxCount = p.getInt(KEY_MAX_COUNT, 0),
        maxSeconds = p.getInt(KEY_MAX_SECONDS, 0),
        stopOnScreenOff = p.getBoolean(KEY_STOP_SCREEN_OFF, true),
        stopOnAppChange = p.getBoolean(KEY_STOP_APP_CHANGE, false),
        volumeHotkey = p.getBoolean(KEY_HOTKEY, false),
        sequential = p.getBoolean(KEY_SEQUENTIAL, false)
    ).sanitized()

    private fun writeSettings(e: SharedPreferences.Editor, s0: RunSettings) {
        val s = s0.sanitized()
        e.putLong(KEY_INTERVAL, s.intervalMs)
            .putLong(KEY_EYE_SCAN_INTERVAL, s.eyeScanIntervalMs)
            .putInt(KEY_JITTER, s.jitterPercent)
            .putInt(KEY_POS_JITTER, s.posJitterPx)
            .putLong(KEY_START_DELAY, s.startDelayMs)
            .putInt(KEY_MAX_COUNT, s.maxCount)
            .putInt(KEY_MAX_SECONDS, s.maxSeconds)
            .putBoolean(KEY_STOP_SCREEN_OFF, s.stopOnScreenOff)
            .putBoolean(KEY_STOP_APP_CHANGE, s.stopOnAppChange)
            .putBoolean(KEY_HOTKEY, s.volumeHotkey)
            .putBoolean(KEY_SEQUENTIAL, s.sequential)
    }

    // ---------- จุดคลิก / หน่วงรายจุด / ตำแหน่งแผง ----------

    fun readPoints(p: SharedPreferences): List<ClickPoint> {
        migrateLegacySwipePrefs(p)
        return pointsFromJson(p.getString(KEY_POINTS, null))
    }

    fun writePoints(p: SharedPreferences, points: List<ClickPoint>) {
        p.edit().putString(KEY_POINTS, pointsToJson(points).toString()).apply()
    }

    fun writeEyeScanInterval(p: SharedPreferences, intervalMs: Long) {
        p.edit().putLong(
            KEY_EYE_SCAN_INTERVAL,
            intervalMs.coerceIn(Limits.MIN_EYE_SCAN_MS, Limits.MAX_EYE_SCAN_MS)
        ).apply()
    }

    fun readDelays(p: SharedPreferences): List<Long> = delaysFromJson(p.getString(KEY_DELAYS, null))

    fun writeDelays(p: SharedPreferences, delays: List<Long>) {
        p.edit().putString(KEY_DELAYS, delaysToJson(delays).toString()).apply()
    }

    fun readHolds(p: SharedPreferences): List<Long> {
        migrateLegacySwipePrefs(p)
        return delaysFromJson(p.getString(KEY_HOLDS, null))
    }

    fun writeHolds(p: SharedPreferences, holds: List<Long>) {
        p.edit().putString(KEY_HOLDS, delaysToJson(holds).toString()).apply()
    }

    fun readStrengths(p: SharedPreferences): List<Long> = delaysFromJson(p.getString(KEY_STRENGTHS, null))

    fun readCounts(p: SharedPreferences): List<Long> = delaysFromJson(p.getString(KEY_COUNTS, null))

    fun writeCounts(p: SharedPreferences, counts: List<Long>) {
        p.edit().putString(KEY_COUNTS, delaysToJson(counts).toString()).apply()
    }

    fun writeStrengths(p: SharedPreferences, strengths: List<Long>) {
        p.edit().putString(KEY_STRENGTHS, delaysToJson(strengths).toString()).apply()
    }

    fun readDragStrengthDefault(p: SharedPreferences): Long =
        p.getLong(KEY_DRAG_STRENGTH, Limits.DEFAULT_DRAG_STRENGTH)
            .coerceIn(Limits.MIN_DRAG_STRENGTH, Limits.MAX_DRAG_STRENGTH)

    fun readDefaultHold(p: SharedPreferences): Long =
        p.getLong(KEY_DEFAULT_HOLD, Limits.TAP_DURATION_MS).coerceIn(Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS)

    fun readPanelFolded(p: SharedPreferences): Boolean = p.getBoolean(KEY_PANEL_FOLDED, false)

    fun writePanelFolded(p: SharedPreferences, folded: Boolean) {
        p.edit().putBoolean(KEY_PANEL_FOLDED, folded).apply()
    }

    // ชุดปุ่มที่ "เล่นเฉพาะ" (นับจาก 0); null = เล่นทุกปุ่ม
    // ถ้าจำนวนปุ่มตอนนี้ไม่ตรงกับตอนที่เลือกไว้ (เพิ่ม/ลบ/โหลดโปรไฟล์) ถือว่าที่เลือกไว้ใช้ไม่ได้ เพื่อไม่ให้เลขชี้ผิดปุ่ม
    fun readOnlyPlay(p: SharedPreferences, pointCount: Int): Set<Int>? {
        val raw = p.getString(KEY_ONLY_PLAY, null) ?: return null
        val parts = raw.split("|")
        if (parts.size != 2 || parts[1].toIntOrNull() != pointCount) return null
        val set = parts[0].split(",").mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 0 until pointCount }.toSet()
        return set.takeIf { it.isNotEmpty() }
    }

    // selected ว่าง/null = ล้างการเลือก (เล่นทุกปุ่ม)
    fun writeOnlyPlay(p: SharedPreferences, selected: Set<Int>?, pointCount: Int) {
        if (selected.isNullOrEmpty()) {
            p.edit().remove(KEY_ONLY_PLAY).apply()
        } else {
            p.edit().putString(KEY_ONLY_PLAY, selected.sorted().joinToString(",") + "|" + pointCount).apply()
        }
    }

    fun readSelected(p: SharedPreferences): Int = p.getInt(KEY_SELECTED, 0)

    fun writeSelected(p: SharedPreferences, index: Int) {
        p.edit().putInt(KEY_SELECTED, index.coerceAtLeast(0)).apply()
    }

    fun readTimeUnit(p: SharedPreferences): TimeUnitOpt = TimeUnitOpt.fromCode(p.getString(KEY_TIME_UNIT, null))

    fun writeTimeUnit(p: SharedPreferences, unit: TimeUnitOpt) {
        p.edit().putString(KEY_TIME_UNIT, unit.code).apply()
    }

    fun readPanelPos(p: SharedPreferences): Pair<Int, Int>? =
        if (p.contains(KEY_PANEL_X) && p.contains(KEY_PANEL_Y))
            p.getInt(KEY_PANEL_X, 0) to p.getInt(KEY_PANEL_Y, 0)
        else null

    fun writePanelPos(p: SharedPreferences, x: Int, y: Int) {
        p.edit().putInt(KEY_PANEL_X, x).putInt(KEY_PANEL_Y, y).apply()
    }

    // [กว้าง, สูง, เยื้องX, เยื้องY] ของหน้าต่างตั้งค่าเวลา; null = ยังไม่เคยปรับ
    fun readTimeWindow(p: SharedPreferences): IntArray? =
        if (p.contains(KEY_TS_W) && p.contains(KEY_TS_H) && p.contains(KEY_TS_X) && p.contains(KEY_TS_Y))
            intArrayOf(p.getInt(KEY_TS_W, 0), p.getInt(KEY_TS_H, 0), p.getInt(KEY_TS_X, 0), p.getInt(KEY_TS_Y, 0))
        else null

    fun writeTimeWindow(p: SharedPreferences, w: Int, h: Int, x: Int, y: Int) {
        p.edit().putInt(KEY_TS_W, w).putInt(KEY_TS_H, h).putInt(KEY_TS_X, x).putInt(KEY_TS_Y, y).apply()
    }

    fun writeLastRun(p: SharedPreferences, count: Int, durationMs: Long, reason: StopReason) {
        p.edit().putInt(KEY_LAST_COUNT, count)
            .putLong(KEY_LAST_DURATION, durationMs)
            .putString(KEY_LAST_REASON, reason.name)
            .apply()
    }

    // ---------- โปรไฟล์ ----------

    fun currentProfile(p: SharedPreferences, name: String) =
        Profile(name, readSettings(p), readPoints(p), readDelays(p), readHolds(p), readStrengths(p), readCounts(p))

    fun listProfiles(p: SharedPreferences): List<Profile> {
        val raw = p.getString(KEY_PROFILES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { runCatching { profileFromJson(arr.getJSONObject(it)) }.getOrNull() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeProfiles(p: SharedPreferences, list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(profileToJson(it)) }
        p.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    // ชื่อซ้ำ = เขียนทับ; คืน false ถ้าเกินจำนวนที่เก็บได้
    fun saveProfile(p: SharedPreferences, profile: Profile): Boolean {
        val list = listProfiles(p).toMutableList()
        val i = list.indexOfFirst { it.name == profile.name }
        if (i >= 0) list[i] = profile
        else {
            if (list.size >= MAX_PROFILES) return false
            list.add(profile)
        }
        writeProfiles(p, list)
        return true
    }

    fun deleteProfile(p: SharedPreferences, name: String) {
        writeProfiles(p, listProfiles(p).filter { it.name != name })
    }

    fun applyProfile(p: SharedPreferences, profile: Profile) {
        val e = p.edit()
        writeSettings(e, profile.settings)
        e.putString(KEY_POINTS, pointsToJson(profile.points).toString())
        e.putString(KEY_DELAYS, delaysToJson(profile.delays).toString())
        e.putString(KEY_HOLDS, delaysToJson(profile.holds).toString())
        e.putString(KEY_STRENGTHS, delaysToJson(profile.strengths).toString())
        e.putString(KEY_COUNTS, delaysToJson(profile.counts).toString())
        e.remove(KEY_ONLY_PLAY)   // โหลดโปรไฟล์ = ชุดปุ่มใหม่ ล้าง "เล่นเฉพาะ" เดิม
        e.putInt(KEY_REV, p.getInt(KEY_REV, 0) + 1)
        e.apply()
    }

    // ---------- JSON ----------

    fun pointsToJson(points: List<ClickPoint>): JSONArray {
        val arr = JSONArray()
        points.forEach {
            arr.put(
                JSONObject().put("t", it.type.code).put("x", it.x).put("y", it.y)
                    .put("x2", it.x2).put("y2", it.y2).apply {
                        it.eye?.let { e ->
                            put(
                                "eye", JSONObject().put("mode", e.mode.code).put("kind", e.kind.code)
                                    .put("text", e.text).put("color", e.color).put("frac", e.colorFrac.toDouble())
                                    .put("thr", e.threshold).put("file", e.file)
                            )
                        }
                    }
            )
        }
        return arr
    }

    fun pointsFromJson(raw: String?): List<ClickPoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val x = o.getInt("x")
                val y = o.getInt("y")
                val eye = o.optJSONObject("eye")?.let { e ->
                    EyeCfg(
                        mode = EyeMode.fromCode(e.optString("mode")),
                        kind = EyeMode.fromCode(e.optString("kind")).let { k -> if (k == EyeMode.AUTO) EyeMode.IMAGE else k },
                        text = e.optString("text", ""),
                        color = e.optInt("color", 0),
                        colorFrac = e.optDouble("frac", 0.0).toFloat(),
                        threshold = e.optInt("thr", 90).coerceIn(0, 100),
                        file = e.optString("file", "")
                    )
                }
                ClickPoint(StepType.fromCode(o.optString("t")), x, y, o.optInt("x2", x), o.optInt("y2", y), eye)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun delaysToJson(delays: List<Long>): JSONArray {
        val arr = JSONArray()
        delays.forEach { arr.put(it) }
        return arr
    }

    fun delaysFromJson(raw: String?): List<Long> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getLong(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ย้ายข้อมูลเดิมเพียงครั้งเดียว: จุด swipe เป็น tap และระยะเวลาปัดเดิมไม่ถูกนำไปใช้เป็นเวลากดค้าง
    // จุดชนิด long (L) เป็น tap และคงเวลากดค้างเดิมไว้เป็นค่า "กดค้าง" รายจุด
    private fun migrateLegacySwipePrefs(p: SharedPreferences) {
        val rawPoints = p.getString(KEY_POINTS, null) ?: return
        val hasLegacy = try {
            val arr = JSONArray(rawPoints)
            (0 until arr.length()).any {
                val t = arr.optJSONObject(it)?.optString("t")
                t == "swipe" || t == "long"
            }
        } catch (_: Exception) {
            false
        }
        if (!hasLegacy) return

        val migratedPoints = pointsFromJson(rawPoints)
        val migratedHolds = keepLegacyLongHolds(
            clearLegacySwipeHolds(delaysFromJson(p.getString(KEY_HOLDS, null)), rawPoints), rawPoints
        )
        p.edit()
            .putString(KEY_POINTS, pointsToJson(migratedPoints).toString())
            .putString(KEY_HOLDS, delaysToJson(migratedHolds).toString())
            .apply()
    }

    // โปรไฟล์รุ่นเก่าเก็บเวลาปัดไว้ใน holds; เมื่อย้ายเป็นแตะต้องคืนค่าเริ่มต้นของการแตะ ไม่ใช่กดค้างยาว
    private fun clearLegacySwipeHolds(holds: List<Long>, pointsRaw: String?): List<Long> {
        if (holds.isEmpty() || pointsRaw.isNullOrBlank()) return holds
        return try {
            val points = JSONArray(pointsRaw)
            val migrated = holds.toMutableList()
            for (i in 0 until minOf(points.length(), migrated.size)) {
                if (points.optJSONObject(i)?.optString("t") == "swipe") migrated[i] = -1L
            }
            migrated
        } catch (_: Exception) {
            holds
        }
    }

    // จุด L เดิมใช้เวลากดค้างเริ่มต้น 600 มิลลิวินาทีเมื่อไม่ได้ตั้งค่าเอง; เมื่อแปลงเป็นแตะต้องเขียนค่านั้นลงไปตรง ๆ
    // ไม่เช่นนั้นจะกลายเป็นแตะสั้น 50 มิลลิวินาทีโดยไม่รู้ตัว (ค่าที่ผู้ใช้ตั้งเองไว้แล้วคงเดิม)
    private fun keepLegacyLongHolds(holds: List<Long>, pointsRaw: String?): List<Long> {
        if (pointsRaw.isNullOrBlank()) return holds
        return try {
            val points = JSONArray(pointsRaw)
            val out = holds.toMutableList()
            for (i in 0 until points.length()) {
                if (points.optJSONObject(i)?.optString("t") != "long") continue
                while (out.size <= i) out.add(-1L)
                if (out[i] < 0L) out[i] = Limits.LONG_PRESS_MS
            }
            out
        } catch (_: Exception) {
            holds
        }
    }

    fun profileToJson(pr: Profile): JSONObject {
        val s = pr.settings
        return JSONObject()
            .put("name", pr.name)
            .put(
                "s", JSONObject()
                    .put("interval", s.intervalMs).put("eyeScanInterval", s.eyeScanIntervalMs).put("jitter", s.jitterPercent)
                    .put("posJitter", s.posJitterPx).put("startDelay", s.startDelayMs)
                    .put("maxCount", s.maxCount).put("maxSeconds", s.maxSeconds)
                    .put("screenOff", s.stopOnScreenOff).put("appChange", s.stopOnAppChange)
                    .put("hotkey", s.volumeHotkey).put("sequential", s.sequential)
            )
            .put("p", pointsToJson(pr.points))
            .put("d", delaysToJson(pr.delays))
            .put("h", delaysToJson(pr.holds))
            .put("g", delaysToJson(pr.strengths))
            .put("c", delaysToJson(pr.counts))
    }

    fun profileFromJson(o: JSONObject): Profile {
        val d = RunSettings()
        val s = o.getJSONObject("s")
        val settings = RunSettings(
            intervalMs = s.optLong("interval", d.intervalMs),
            eyeScanIntervalMs = s.optLong("eyeScanInterval", d.eyeScanIntervalMs),
            jitterPercent = s.optInt("jitter", d.jitterPercent),
            posJitterPx = s.optInt("posJitter", d.posJitterPx),
            startDelayMs = s.optLong("startDelay", d.startDelayMs),
            maxCount = s.optInt("maxCount", d.maxCount),
            maxSeconds = s.optInt("maxSeconds", d.maxSeconds),
            stopOnScreenOff = s.optBoolean("screenOff", d.stopOnScreenOff),
            stopOnAppChange = s.optBoolean("appChange", d.stopOnAppChange),
            volumeHotkey = s.optBoolean("hotkey", d.volumeHotkey),
            sequential = s.optBoolean("sequential", d.sequential)
        ).sanitized()
        val pointsRaw = o.optJSONArray("p")?.toString()
        val holds = keepLegacyLongHolds(
            clearLegacySwipeHolds(delaysFromJson(o.optJSONArray("h")?.toString()), pointsRaw), pointsRaw
        )
        return Profile(
            o.getString("name"),
            settings,
            pointsFromJson(pointsRaw),
            delaysFromJson(o.optJSONArray("d")?.toString()),
            holds,
            delaysFromJson(o.optJSONArray("g")?.toString()),
            delaysFromJson(o.optJSONArray("c")?.toString())
        )
    }
}
