package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.abs

class ClickService : AccessibilityService() {

    companion object {
        const val PREFS = "cfg"
        const val KEY_INTERVAL = "interval"
        const val MIN_INTERVAL_MS = 10L   // ช่วงเวลาขั้นต่ำระหว่างการแตะ
        const val TAP_DURATION_MS = 10L   // ระยะเวลาของการแตะแต่ละครั้ง
        const val KEY_PANEL_SCALE = "panel_scale"     // ขนาดแผงเริ่ม/หยุด (เปอร์เซ็นต์)
        const val KEY_MARKER_SCALE = "marker_scale"   // ขนาดจุดคลิก (เปอร์เซ็นต์)
        const val MIN_SCALE = 30
        const val MAX_SCALE = 150
        const val DEFAULT_SCALE = 100
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var wm: WindowManager? = null

    private var marker: MarkerView? = null
    private var markerLp: WindowManager.LayoutParams? = null
    private var panel: PanelView? = null

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == KEY_PANEL_SCALE || key == KEY_MARKER_SCALE) applyScales()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        if (marker == null) {
            addMarker()
            addPanel()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // TYPE_ACCESSIBILITY_OVERLAY: an AccessibilityService can add this window type
    // without the SYSTEM_ALERT_WINDOW permission.
    private fun overlayLp(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun scaleOf(key: String) =
        prefs.getInt(key, DEFAULT_SCALE).coerceIn(MIN_SCALE, MAX_SCALE)

    private fun addMarker() {
        val v = MarkerView(this)
        v.setScale(scaleOf(KEY_MARKER_SCALE))
        val size = v.sizePx(v.scale)
        val lp = overlayLp(size, size, dp(150), dp(300))
        makeDraggable(v, lp, null)
        wm?.addView(v, lp)
        marker = v
        markerLp = lp
    }

    private fun addPanel() {
        val root = PanelView(this)
        root.setScale(scaleOf(KEY_PANEL_SCALE))
        val lp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(16), dp(120))
        val close = root.close
        // ตอนกำลังคลิก: แค่ "แตะลง" (DOWN) ที่ปุ่มก็หยุดทันที ไม่ต้องรอปล่อยนิ้ว
        // เพราะการแตะอัตโนมัติความเร็วสูงอาจทำให้การแตะของผู้ใช้ถูกยกเลิกก่อนปล่อยนิ้ว
        // แตะโซนปุ่ม ✕ (x >= close.left) = ปิดแอป, แตะโซนอื่น = เริ่ม/หยุด
        makeDraggable(root, lp, { x ->
            if (x >= close.left) closeApp() else toggle()
        }, { x ->
            if (job?.isActive == true) {
                if (x >= close.left) closeApp() else stopClicking()
                true
            } else false
        })
        wm?.addView(root, lp)
        panel = root
    }

    // ปรับขนาดแผงและจุดคลิกทันทีเมื่อผู้ใช้เลื่อนแถบในหน้าตั้งค่า (ไม่ต้องปิด/เปิดบริการใหม่)
    private fun applyScales() {
        val m = marker
        val mlp = markerLp
        if (m != null && mlp != null) {
            val pct = scaleOf(KEY_MARKER_SCALE)
            val newSize = m.sizePx(pct)
            val delta = (mlp.width - newSize) / 2   // ขยาย/ย่อรอบจุดกึ่งกลางเดิม ตำแหน่งแตะไม่ขยับ
            mlp.x += delta
            mlp.y += delta
            mlp.width = newSize
            mlp.height = newSize
            m.setScale(pct)
            wm?.updateViewLayout(m, mlp)
        }
        val p = panel
        if (p != null) {
            p.setScale(scaleOf(KEY_PANEL_SCALE))
            (p.layoutParams as? WindowManager.LayoutParams)?.let { wm?.updateViewLayout(p, it) }
        }
    }

    // อัปเดตสีจุดคลิกและปุ่มเริ่ม/หยุดให้ตรงกับสถานะ
    private fun setRunningUi(running: Boolean) {
        marker?.setColor(if (running) OVERLAY_GREEN else OVERLAY_RED)
        panel?.setRunning(running)
    }

    // ปิดออโต้คลิก: หยุดคลิก เอาปุ่มลอยออก แล้วปิดบริการการช่วยการเข้าถึง
    private fun closeApp() {
        stopClicking()
        removeOverlays()
        disableSelf()
    }

    private fun removeOverlays() {
        marker?.let { wm?.removeView(it) }
        panel?.let { wm?.removeView(it) }
        marker = null
        markerLp = null
        panel = null
    }

    private fun makeDraggable(
        v: View,
        lp: WindowManager.LayoutParams,
        onTap: ((Float) -> Unit)?,
        onDown: ((Float) -> Boolean)? = null
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var consumed = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    consumed = onDown?.invoke(e.x) == true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved && !consumed) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm?.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && !consumed) onTap?.invoke(e.x)
                    true
                }
                // ถ้าระบบยกเลิกการแตะของผู้ใช้ที่ปุ่มระหว่างกำลังคลิก ให้ถือว่าผู้ใช้ต้องการหยุด
                MotionEvent.ACTION_CANCEL -> {
                    if (onDown != null && job?.isActive == true) stopClicking()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggle() {
        if (job?.isActive == true) stopClicking() else startClicking()
    }

    private fun startClicking() {
        val m = marker ?: return
        val lp = markerLp ?: return
        val loc = IntArray(2)
        m.getLocationOnScreen(loc)
        val x = loc[0] + m.width / 2f
        val y = loc[1] + m.height / 2f
        val interval = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getLong(KEY_INTERVAL, 500L).coerceAtLeast(MIN_INTERVAL_MS)

        // Let taps pass through the marker so it doesn't swallow its own clicks.
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm?.updateViewLayout(m, lp)
        setRunningUi(true)

        // กำหนดจังหวะแบบ fixed-rate จากนาฬิการะบบ: ไม่เอา "เวลาที่ใช้แตะ" มาบวกสะสมทุกรอบ
        // (แบบเดิม tap แล้ว delay(interval) ทำให้คาบจริง = interval + เวลา dispatch ซึ่งเพิ่มขึ้นเมื่อเครื่องหน่วง)
        job = scope.launch {
            var next = SystemClock.uptimeMillis()
            while (isActive) {
                tap(x, y)
                next += interval
                val now = SystemClock.uptimeMillis()
                if (next <= now) next = now   // ตามไม่ทัน: เริ่มนับใหม่ ไม่แตะรัวชดเชย
                else delay(next - now)
            }
        }
    }

    private fun stopClicking() {
        job?.cancel()
        job = null
        val m = marker
        val lp = markerLp
        if (m != null && lp != null) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            wm?.updateViewLayout(m, lp)
        }
        setRunningUi(false)
    }

    // Waits until the gesture completes/cancels so taps never overlap.
    private suspend fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, TAP_DURATION_MS))
            .build()
        // กัน callback ไม่ถูกเรียก (ระบบหน่วง/ถูกยกเลิกเงียบ ๆ) ไม่ให้ลูปค้าง
        withTimeoutOrNull(1000L) { suspendCancellableCoroutine<Unit> { c ->
            val accepted = dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(Unit)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(Unit)
                    }
                },
                null
            )
            if (!accepted && c.isActive) c.resume(Unit)
        } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        job?.cancel()
        removeOverlays()
        scope.cancel()
        super.onDestroy()
    }
}
