package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.cancelChildren
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.random.Random

class ClickService : AccessibilityService() {

    companion object {
        const val MAX_POINTS = 20
        private const val TAG = "AutoClicker"
        private const val SYSTEM_UI_PKG = "com.android.systemui"
        // ให้ MainActivity สั่งแสดงปุ่มลอย/ปิดบริการได้ (อยู่ใน process และ main thread เดียวกัน)
        @Volatile
        var instance: ClickService? = null
            private set
    }

    // จุดคลิกหนึ่งจุด = ป้ายวงกลม หรือกล่องตรวจจับของโหมดตา
    private class PointView(
        var type: StepType,
        val marker: MarkerView,
        val lp: WindowManager.LayoutParams
    ) {
        var eye: EyeCfg? = null          // ค่าตรวจจับ (เฉพาะชนิดตา)
        var handle: View? = null         // มุมจับปรับขนาดกล่องตา
    }

    // ภาพอ้างอิงที่ล็อกไว้ (พิกเซล ARGB)
    private class Tpl(val px: IntArray, val w: Int, val h: Int)

    // ตาตอนวิ่ง: ตำแหน่งกล่องบนจอจริง ณ ตอนกดเริ่ม + ภาพอ้างอิงที่โหลดไว้แล้ว
    private class EyeRt(val cfg: EyeCfg?, val left: Int, val top: Int, val w: Int, val h: Int, val tpl: Tpl?) {
        // OCR มีต้นทุนสูง: เก็บผลเมื่อกรอบภาพไม่เปลี่ยน เพื่อไม่อ่านข้อความเดิมซ้ำทุกเฟรม
        var lastTextFingerprint: Long? = null
        var lastTextResult: EyeResult? = null
    }

    private class EyeResult(
        val hit: Boolean, val strong: Boolean, val near: Boolean, val label: String,
        val cacheable: Boolean = true
    )

    // แยกสาเหตุที่ gesture ไม่สำเร็จ เพื่อ retry เฉพาะกรณี Android ปฏิเสธก่อนเริ่มจริง
    private enum class GestureOutcome { COMPLETED, REJECTED, CANCELLED, TIMED_OUT }

    // หนึ่งเหตุการณ์แตะที่ส่งเข้า dispatcher กลาง เพื่อรวมหลายจุดเป็น Multi-touch ชุดเดียว
    private class TapAction(val target: Target, val pointIndex: Int)

    // พิกัดจริงบนหน้าจอ ณ ตอนกดเริ่ม
    private class Target(
        val type: StepType, val x: Float, val y: Float, val holdMs: Long,
        val eye: EyeRt? = null
    )

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main +
            CoroutineExceptionHandler { _, _ -> stopClicking(StopReason.INTERRUPTED) }
    )
    private var job: Job? = null
    private var wm: WindowManager? = null

    private val points = mutableListOf<PointView>()
    private var panel: PanelView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var eyeCapture: FrameLayout? = null   // หน้าต่างจับการลากกล่องตอนสร้างตา
    private var eyePanel: EyePanelView? = null
    private var eyePv: PointView? = null
    private var eyeJob: Job? = null               // วนอัปเดตภาพสดในหน้าต่างตั้งค่าตา
    private var eyeLockJob: Job? = null
    // ภาพตัวอย่างล่าสุด (ใช้ตอนกดล็อกเพื่อไม่ต้องจับภาพซ้ำ — Android จำกัดความถี่การจับภาพ)
    private var lastPreviewCrop: Bitmap? = null
    private var lastPreviewAt = 0L
    private var lastPreviewLoc = intArrayOf(-1, -1)
    @Volatile private var eyeLockBusy = false
    // Android จำกัดความถี่จับภาพ: เว้นช่วงขั้นต่ำระหว่างครั้ง และขยายเองอัตโนมัติเมื่อโดนปฏิเสธ (รหัส 3)
    private var lastShotAt = 0L
    private val screenshotMutex = Mutex()
    // Android 11 (API 30) จำกัดคำขอภาพไว้ราว 1 วินาที; API ใหม่ใช้ช่วงสั้นลงได้
    @Volatile private var minShotGapMs = if (Build.VERSION.SDK_INT == 30) 1100L else 400L
    private var eyeFailShown = false
    @Volatile private var lastShotError = 0   // รหัสล่าสุดที่จับภาพไม่ได้: 1-6 = รหัสของ Android, -1 หมดเวลา, -2 ข้อผิดพลาด, -3 แปลงภาพไม่ได้
    private var tplCache: Pair<String, Tpl?>? = null
    private val recognizerLazy = lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    var overlaysVisible = false
        private set
    // ซ่อนเฉพาะจุดกด/กรอบตา แต่คงแผงเครื่องมือไว้ให้เรียกคืนได้
    private var pointsHidden = false

    private var fgPkg: String? = null
    private var runPkg: String? = null
    private var runCount = 0
    private var runFirst = 0L
    private var runLast = 0L
    private var hotkeyOn = false
    private var receiverRegistered = false

    private val prefs by lazy { ConfigStore.prefs(this) }
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            ConfigStore.KEY_PANEL_SCALE, ConfigStore.KEY_MARKER_SCALE -> applyScales()
            ConfigStore.KEY_REV -> {
                if (overlaysVisible) rebuildOverlays()
            }
            ConfigStore.KEY_HOTKEY -> applyKeyFlag()
            else -> {}
        }
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (job != null && ConfigStore.readSettings(prefs).stopOnScreenOff) {
                stopClicking(StopReason.SCREEN_OFF)
            }
        }
    }

    // ---------- วงจรชีวิตบริการ ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this, screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
        applyKeyFlag()
        if (!overlaysVisible) showOverlays()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        clampAll()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == SYSTEM_UI_PKG) return
        fgPkg = pkg
        if (job != null && ConfigStore.readSettings(prefs).stopOnAppChange) {
            val running = runPkg
            if (running == null) runPkg = pkg
            else if (pkg != running) stopClicking(StopReason.APP_CHANGED)
        }
    }

    // ปุ่มลัด: ปุ่มเพิ่มเสียง = เริ่ม/หยุด (เปิดใช้เฉพาะเมื่อผู้ใช้เปิดในหน้าตั้งค่า)
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!hotkeyOn || !overlaysVisible || event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggle()
        return true
    }

    override fun onInterrupt() {
        stopClicking(StopReason.INTERRUPTED)
    }

    override fun onDestroy() {
        instance = null
        prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenOffReceiver) }
            receiverRegistered = false
        }
        job?.cancel()
        job = null
        removeOverlays()
        scope.cancel()
        if (recognizerLazy.isInitialized()) runCatching { recognizerLazy.value.close() }
        super.onDestroy()
    }

    // การขอรับเหตุการณ์ปุ่มกด (FLAG_REQUEST_FILTER_KEY_EVENTS) เปิดเฉพาะตอนผู้ใช้เปิดปุ่มลัด
    private fun applyKeyFlag() {
        hotkeyOn = ConfigStore.readSettings(prefs).volumeHotkey
        val info = serviceInfo ?: return
        val flag = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        val has = info.flags and flag != 0
        if (hotkeyOn != has) {
            info.flags = if (hotkeyOn) info.flags or flag else info.flags and flag.inv()
            serviceInfo = info
        }
    }

    // ---------- เครื่องมือช่วย ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screenSize(): Pair<Int, Int> {
        val w = wm
        if (w != null) {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = w.currentWindowMetrics.bounds
                return b.width() to b.height()
            }
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            w.defaultDisplay.getRealMetrics(dm)
            return dm.widthPixels to dm.heightPixels
        }
        val dm = resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }

    private fun clampLp(lp: WindowManager.LayoutParams, w: Int, h: Int) {
        val (sw, sh) = screenSize()
        lp.x = lp.x.coerceIn(0, maxOf(0, sw - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, sh - h))
    }

    // TYPE_ACCESSIBILITY_OVERLAY: บริการช่วยการเข้าถึงเพิ่มหน้าต่างชนิดนี้ได้โดยไม่ต้องขอสิทธิ์ SYSTEM_ALERT_WINDOW
    private fun overlayLp(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun scaleOf(key: String) =
        prefs.getInt(key, Limits.DEFAULT_SCALE).coerceIn(Limits.MIN_SCALE, Limits.MAX_SCALE)

    private fun centerOf(lp: WindowManager.LayoutParams) = (lp.x + lp.width / 2) to (lp.y + lp.height / 2)

    private fun safeRemove(v: View) {
        try {
            wm?.removeView(v)
        } catch (_: IllegalArgumentException) {
            // view ไม่ได้ถูกเพิ่มอยู่แล้ว
        }
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm?.updateViewLayout(v, lp)
        } catch (_: IllegalArgumentException) {
        }
    }

    // ---------- สร้าง/ลบปุ่มลอย ----------

    fun showOverlays() {
        if (overlaysVisible || wm == null) return
        pointsHidden = false
        val saved = ConfigStore.readPoints(prefs).take(MAX_POINTS)
        // ครั้งแรกที่ยังไม่เคยบันทึกจุด = สร้างปุ่ม 1 ให้; ถ้าผู้ใช้ลบหมดแล้ว (บันทึกเป็นรายการว่าง) ให้ว่างต่อไป
        val firstRun = !prefs.contains(ConfigStore.KEY_POINTS)
        val list = if (firstRun) listOf(defaultPoint()) else saved
        list.forEach { points.add(createPointView(it)) }
        addPanel()
        overlaysVisible = true
        relabel()
        if (firstRun) savePoints()
    }

    private fun defaultPoint(): ClickPoint {
        val (sw, sh) = screenSize()
        return ClickPoint(StepType.TAP, minOf(dp(180), sw / 2), minOf(dp(330), sh / 2))
    }

    fun hideOverlays() {
        stopClicking(StopReason.MANUAL)
        removeOverlays()
    }

    private fun rebuildOverlays() {
        stopClicking(StopReason.MANUAL)
        removeOverlays()
        showOverlays()
    }

    private fun removeOverlays() {
        points.forEach { pv ->
            safeRemove(pv.marker)
        }
        points.clear()
        stopEyeRecord()
        closeEyePanel()
        panel?.let { safeRemove(it) }
        panel = null
        panelLp = null
        pointsHidden = false
        overlaysVisible = false
    }

    private fun createPointView(model: ClickPoint): PointView {
        val marker = MarkerView(this)
        marker.setScale(scaleOf(ConfigStore.KEY_MARKER_SCALE))
        val isEye = model.type == StepType.EYE
        val (sw, sh) = screenSize()
        val w = if (isEye) model.x2.coerceIn(dp(32), sw) else marker.sizePx(marker.scale)
        val h = if (isEye) model.y2.coerceIn(dp(32), sh) else w
        val lp = overlayLp(w, h, model.x - w / 2, model.y - h / 2)
        clampLp(lp, w, h)
        val pv = PointView(model.type, marker, lp)
        pv.eye = model.eye
        if (isEye) marker.setRect(true)
        // แตะที่จุดเพื่อสลับชนิด: แตะ ↔ กดค้าง
        makeDraggable(marker, lp, onTap = { cycleType(pv) }, onDragEnd = { savePoints() })
        if (pointsHidden) marker.visibility = View.INVISIBLE
        wm?.addView(marker, lp)
        if (isEye) attachEyeHandle(pv)
        return pv
    }

    private fun addPanel() {
        val root = PanelView(this)
        root.setScale(scaleOf(ConfigStore.KEY_PANEL_SCALE))
        val (px, py) = ConfigStore.readPanelPos(prefs) ?: (dp(16) to dp(120))
        val lp = overlayLp(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            maxOf(px, 0), maxOf(py, 0)
        )
        // ตอนกำลังคลิก: แค่ "แตะลง" (DOWN) ที่ปุ่มก็หยุดทันที ไม่ต้องรอปล่อยนิ้ว
        // เพราะการแตะอัตโนมัติความเร็วสูงอาจทำให้การแตะของผู้ใช้ถูกยกเลิกก่อนปล่อยนิ้ว
        makeDraggable(
            root, lp,
            onTap = { x ->
                when (root.actionAt(x)) {
                    PanelAction.TOGGLE -> toggle()
                    PanelAction.ADD -> addPoint()
                    PanelAction.REMOVE -> removePoint()
                    PanelAction.EYE -> if (eyeCapture != null) stopEyeRecord() else startEyeRecord()
                    PanelAction.SAVE -> openProfileDialog(ProfileDialogActivity.MODE_SAVE)
                    PanelAction.LOAD -> openProfileDialog(ProfileDialogActivity.MODE_LOAD)
                    PanelAction.SETTINGS -> openTimeSettings()
                    PanelAction.TOGGLE_POINTS -> togglePointVisibility()
                    PanelAction.HIDE -> hideOverlays()
                }
            },
            onDown = { x ->
                if (job != null) {
                    if (root.actionAt(x) == PanelAction.HIDE) hideOverlays() else stopClicking(StopReason.MANUAL)
                    true
                } else false
            },
            onDragEnd = { ConfigStore.writePanelPos(prefs, lp.x, lp.y) }
        )
        wm?.addView(root, lp)
        panel = root
        panelLp = lp
        // ขนาดจริงของแผงรู้หลังจัดวาง → ดึงกลับเข้าจอถ้าตำแหน่งที่บันทึกไว้หลุดขอบ
        root.post {
            if (panel === root) {
                clampLp(lp, root.width, root.height)
                safeUpdate(root, lp)
            }
        }
    }

    // ซ่อน/แสดงเฉพาะปุ่มจุดทั้งหมด โดยไม่แตะแผงเครื่องมือ
    private fun togglePointVisibility() {
        pointsHidden = !pointsHidden
        val visibility = if (pointsHidden) View.INVISIBLE else View.VISIBLE
        points.forEach { it.marker.visibility = visibility }
        panel?.setPointsHidden(pointsHidden)
    }

    // เปิดหน้าตั้งค่าเวลา (กล่องโต้ตอบ) — ใช้ Activity เพราะหน้าต่างลอยของบริการพิมพ์ตัวเลขไม่ได้
    private fun openTimeSettings() {
        if (job != null) return
        startActivity(Intent(this, TimeSettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // เปิดกล่องเซฟ/โหลด (Activity เพราะต้องพิมพ์ชื่อด้วยแป้นพิมพ์) — เซฟตำแหน่งจุดล่าสุดลงที่เก็บก่อนเสมอ
    private fun openProfileDialog(mode: String) {
        if (job != null) return
        savePoints()
        startActivity(
            Intent(this, ProfileDialogActivity::class.java)
                .putExtra(ProfileDialogActivity.EXTRA_MODE, mode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------- จัดการจุด ----------

    private fun relabel() {
        points.forEachIndexed { i, pv ->
            val n = i + 1
            pv.marker.setLabel(
                when (pv.type) {
                    StepType.TAP -> "$n"
                    StepType.LONG -> "${n}L"
                    StepType.EYE -> "${n}E"
                }
            )
        }
    }

    private fun savePoints() {
        ConfigStore.writePoints(prefs, points.map { pv ->
            val (cx, cy) = centerOf(pv.lp)
            if (pv.type == StepType.EYE) ClickPoint(pv.type, cx, cy, pv.lp.width, pv.lp.height, pv.eye)
            else ClickPoint(pv.type, cx, cy)
        })
    }

    private fun cycleType(pv: PointView) {
        if (job != null) return
        if (pv.type == StepType.EYE) {   // แตะกล่องตา = เปิดหน้าต่างตั้งค่า/ล็อก
            openEyePanel(pv)
            return
        }
        // หน้าตั้งค่าเปิดอยู่: แตะปุ่ม = เลือกปุ่มนั้นเพื่อดูค่า (ไม่สลับชนิด)
        if (TimeSettingsActivity.isOpen) {
            ConfigStore.writeSelected(prefs, points.indexOf(pv))
            return
        }
        pv.type = pv.type.next()
        relabel()
        savePoints()
    }

    private fun addPoint() {
        if (job != null) return
        if (points.size >= MAX_POINTS) return
        val last = points.lastOrNull()
        if (last == null) {
            // ไม่มีปุ่มเหลือเลย: เริ่มที่ตำแหน่งเริ่มต้น
            points.add(createPointView(defaultPoint()))
            relabel()
            savePoints()
            return
        }
        val (cx, cy) = centerOf(last.lp)
        val (sw, _) = screenSize()
        var nx = cx + dp(70)
        var ny = cy
        if (nx > sw - dp(40)) {
            nx = dp(60)
            ny = cy + dp(70)
        }
        points.add(createPointView(ClickPoint(StepType.TAP, nx, ny)))
        relabel()
        savePoints()
    }

    private fun removePoint() {
        if (job != null || points.isEmpty()) return
        val pv = points.removeAt(points.lastIndex)
        if (eyePv === pv) closeEyePanel()
        safeRemove(pv.marker)
        relabel()
        savePoints()
        // ตัดค่าเวลาหน่วง/เวลากดรายจุดของปุ่มที่ลบทิ้ง ไม่ให้ปุ่มที่เพิ่มทีหลังได้ค่าเก่าไป
        val delays = ConfigStore.readDelays(prefs)
        if (delays.size > points.size) ConfigStore.writeDelays(prefs, delays.take(points.size))
        val holds = ConfigStore.readHolds(prefs)
        if (holds.size > points.size) ConfigStore.writeHolds(prefs, holds.take(points.size))
        ConfigStore.writeSelected(prefs, ConfigStore.readSelected(prefs).coerceAtMost(maxOf(0, points.lastIndex)))
    }

    // ---------- ขนาด/ตำแหน่ง ----------

    private fun resizeAround(v: MarkerView, lp: WindowManager.LayoutParams, pct: Int) {
        val newSize = v.sizePx(pct)
        val delta = (lp.width - newSize) / 2   // ขยาย/ย่อรอบจุดกึ่งกลางเดิม ตำแหน่งแตะไม่ขยับ
        lp.x += delta
        lp.y += delta
        lp.width = newSize
        lp.height = newSize
        v.setScale(pct)
        safeUpdate(v, lp)
    }

    // ปรับขนาดแผงและจุดคลิกทันทีเมื่อผู้ใช้เลื่อนแถบในหน้าตั้งค่า (ไม่ต้องปิด/เปิดบริการใหม่)
    private fun applyScales() {
        points.forEach { pv ->
            if (pv.type == StepType.EYE) pv.marker.setScale(scaleOf(ConfigStore.KEY_MARKER_SCALE))   // กล่องตาขนาดตามที่ลาก ไม่ย่อ/ขยายตามสเกลปุ่ม
            else resizeAround(pv.marker, pv.lp, scaleOf(ConfigStore.KEY_MARKER_SCALE))
        }
        val p = panel
        val lp = panelLp
        if (p != null && lp != null) {
            p.setScale(scaleOf(ConfigStore.KEY_PANEL_SCALE))
            safeUpdate(p, lp)
        }
    }

    // หมุนจอ/เปลี่ยนขนาดจอ: ดึงปุ่มทั้งหมดกลับเข้าในจอ
    private fun clampAll() {
        points.forEach { pv ->
            clampLp(pv.lp, pv.lp.width, pv.lp.height)
            safeUpdate(pv.marker, pv.lp)
        }
        val p = panel
        val lp = panelLp
        if (p != null && lp != null) {
            clampLp(lp, p.width, p.height)
            safeUpdate(p, lp)
        }
    }

    private fun makeDraggable(
        v: View,
        lp: WindowManager.LayoutParams,
        onTap: ((Float) -> Unit)?,
        onDown: ((Float) -> Boolean)? = null,
        onDragEnd: (() -> Unit)? = null
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var consumed = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    consumed = onDown?.invoke(e.x) == true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved && !consumed) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        clampLp(lp, v.width, v.height)
                        safeUpdate(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!consumed) {
                        if (moved) onDragEnd?.invoke() else onTap?.invoke(e.x)
                    }
                    true
                }
                // ถ้าระบบยกเลิกการแตะของผู้ใช้ที่ปุ่มระหว่างกำลังคลิก ให้ถือว่าผู้ใช้ต้องการหยุด
                MotionEvent.ACTION_CANCEL -> {
                    if (onDown != null && job != null) stopClicking(StopReason.MANUAL)
                    else if (moved && !consumed) onDragEnd?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- เริ่ม/หยุด ----------

    private fun toggle() {
        if (job != null) stopClicking(StopReason.MANUAL) else {
            stopEyeRecord()
            closeEyePanel()
            startClicking()
        }
    }

    private fun screenCenter(v: View): Pair<Float, Float> {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return (loc[0] + v.width / 2f) to (loc[1] + v.height / 2f)
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        // ให้การแตะทะลุป้ายลงไป เพื่อไม่ให้ป้ายกลืนการแตะของตัวเอง
        fun apply(v: View, lp: WindowManager.LayoutParams) {
            lp.flags = if (touchable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            safeUpdate(v, lp)
        }
        points.forEach { pv ->
            apply(pv.marker, pv.lp)
        }
    }

    // อัปเดตสีจุดคลิกและปุ่มเริ่ม/หยุดให้ตรงกับสถานะ
    private fun setRunningUi(running: Boolean) {
        points.forEach { it.marker.setColor(if (running) OVERLAY_GREEN else OVERLAY_RED) }
        panel?.setRunning(running)
    }

    private fun startClicking() {
        if (job != null || points.isEmpty()) return
        val settings = ConfigStore.readSettings(prefs)
        val delays = ConfigStore.readDelays(prefs)
        val holds = ConfigStore.readHolds(prefs)
        val targets = points.mapIndexed { i, pv ->
            val (x, y) = screenCenter(pv.marker)
            Target(pv.type, x, y, Timing.holdMs(pv.type, holds, i), if (pv.type == StepType.EYE) buildEyeRt(pv) else null)
        }
        val eyes = targets.mapIndexedNotNull { index, target ->
            val cfg = target.eye?.cfg
            if (target.type == StepType.EYE && cfg?.locked == true) index to target else null
        }
        if (Build.VERSION.SDK_INT < 30 && targets.any { it.type == StepType.EYE }) {
            Toast.makeText(this, getString(R.string.eye_need_android11), Toast.LENGTH_LONG).show()
        }
        eyeFailShown = false

        runCount = 0
        runFirst = 0L
        runLast = 0L
        runPkg = fgPkg
        setMarkersTouchable(false)
        setEyeBoxesVisible(false)
        setRunningUi(true)

        val runtimeStrokeLimit = GestureDescription.getMaxStrokeCount().coerceAtLeast(1)
        if (targets.size > runtimeStrokeLimit) {
            Toast.makeText(
                this,
                getString(R.string.multi_touch_limit, runtimeStrokeLimit),
                Toast.LENGTH_LONG
            ).show()
        }

        // Producers แยกกัน: ทุกปุ่มธรรมดามีตัวจับเวลาของตัวเอง; ทุกดวงตาใช้ภาพหน้าจอร่วมกัน
        // มี dispatcher เดียวเท่านั้นที่เรียก dispatchGesture ป้องกัน gesture ตัดกันเอง
        job = scope.launch {
            val actions = Channel<TapAction>(Channel.BUFFERED)
            var stopForLimit = false
            try {
                if (settings.startDelayMs > 0L) delay(settings.startDelayMs)
                val begin = SystemClock.uptimeMillis()
                val policy = StopPolicy(settings.maxCount, settings.maxSeconds)
                coroutineScope {
                    val pendingPoints = HashSet<Int>()
                    fun enqueue(action: TapAction): Boolean {
                        if (!pendingPoints.add(action.pointIndex)) return false
                        if (!actions.trySend(action).isSuccess) {
                            pendingPoints.remove(action.pointIndex)
                            return false
                        }
                        return true
                    }

                    // ปุ่มแตะ/กดค้าง: ทำงานอิสระตาม wait time ของแต่ละปุ่ม
                    targets.forEachIndexed { index, target ->
                        if (target.type != StepType.EYE) {
                            launch {
                                val rnd = Random.Default
                                var nextAt = begin
                                while (isActive) {
                                    val wait = nextAt - SystemClock.uptimeMillis()
                                    if (wait > 0L) delay(wait)
                                    if (!isActive) break
                                    enqueue(TapAction(target, index))
                                    val interval = Timing.jitterDelay(
                                        Timing.stepDelay(settings, delays, index),
                                        settings.jitterPercent, rnd
                                    )
                                    val now = SystemClock.uptimeMillis()
                                    nextAt = maxOf(nextAt + interval, now + Limits.MIN_INTERVAL_MS)
                                }
                            }
                        }
                    }

                    // ตรวจตาตามลำดับหมายเลขจากน้อยไปมาก ใช้ภาพเต็มจอหนึ่งภาพร่วมกัน
                    // ประมวลผลทีละดวงบน worker thread เพื่อลดการแย่ง CPU/RAM เมื่อมีปุ่มจำนวนมาก
                    if (eyes.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                        launch {
                            val hitStreak = IntArray(targets.size)
                            val nextEyeTapAt = LongArray(targets.size)
                            val rnd = Random.Default
                            while (isActive) {
                                val scanStarted = SystemClock.uptimeMillis()
                                val frame = captureScreenRetry()
                                if (frame == null) {
                                    if (!eyeFailShown) {
                                        eyeFailShown = true
                                        Toast.makeText(
                                            this@ClickService,
                                            getString(R.string.eye_capture_fail_code, lastShotError),
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                } else {
                                    eyeFailShown = false
                                    try {
                                        // eyes ได้มาจาก mapIndexedNotNull จึงเรียงตามหมายเลขปุ่มอยู่แล้ว
                                        for ((index, target) in eyes) {
                                            if (!isActive) break
                                            val result = withContext(Dispatchers.Default) {
                                                evalEyeFrame(target, frame)
                                            }
                                            val evaluatedAt = SystemClock.uptimeMillis()
                                            if (result == null) {
                                                hitStreak[index] = 0
                                                continue
                                            }
                                            // ใช้การยืนยันแบบ 2 ในช่วงล่าสุด: เฟรมที่เกือบตรง (near)
                                            // จะไม่ล้างคะแนนทั้งหมด จึงทนภาพกะพริบ/แอนิเมชันได้ดีกว่า streak แบบติดกันเท่านั้น
                                            hitStreak[index] = EyeConfirmation.nextScore(
                                                hitStreak[index], result.hit, result.strong, result.near
                                            )
                                            val confirmed = EyeConfirmation.confirmed(hitStreak[index], result.hit, result.strong)
                                            if (!confirmed || evaluatedAt < nextEyeTapAt[index]) continue

                                            if (enqueue(TapAction(target, index))) {
                                                val interval = Timing.jitterDelay(
                                                    Timing.stepDelay(settings, delays, index),
                                                    settings.jitterPercent, rnd
                                                )
                                                nextEyeTapAt[index] = evaluatedAt + interval
                                            } else {
                                                Log.d(TAG, "Eye #${index + 1} matched but action is already pending")
                                            }
                                        }
                                    } finally {
                                        if (!frame.isRecycled) frame.recycle()
                                    }
                                }

                                // Android 11 จำกัดความถี่จับภาพ; ไม่ฝืนให้รอบสแกนเร็วเกินที่ระบบอนุญาต
                                val scanGap = maxOf(settings.eyeScanIntervalMs, minShotGapMs)
                                val wait = scanStarted + scanGap - SystemClock.uptimeMillis()
                                if (wait > 0L) delay(wait)
                            }
                        }
                    }

                    // ปุ่มตาต้องแตะเรียงตามหมายเลขทีละจุด; ปุ่มธรรมดายังรวม Multi-touch ได้
                    var deferredAction: TapAction? = null
                    while (isActive) {
                        val first = deferredAction ?: withTimeoutOrNull(50L) { actions.receive() }
                        deferredAction = null
                        if (first == null) {
                            if (policy.reached(runCount, SystemClock.uptimeMillis() - begin)) {
                                stopForLimit = true
                                break
                            }
                            continue
                        }
                        val batch = mutableListOf(first)
                        if (first.target.type != StepType.EYE) {
                            delay(8L) // รวมเฉพาะปุ่มธรรมดาที่ครบกำหนดใกล้กัน
                            while (true) {
                                val next = actions.tryReceive().getOrNull() ?: break
                                if (next.target.type == StepType.EYE) {
                                    deferredAction = next
                                    break
                                }
                                batch.add(next)
                            }
                        }

                        val remaining = if (settings.maxCount > 0)
                            (settings.maxCount - runCount).coerceAtLeast(0)
                        else Int.MAX_VALUE
                        if (remaining == 0) {
                            stopForLimit = true
                            break
                        }
                        val allowed = batch.take(remaining)
                        for (chunk in allowed.chunked(runtimeStrokeLimit)) {
                            try {
                                val startedAt = SystemClock.uptimeMillis()
                                val accepted = performBatch(chunk, settings.posJitterPx, Random.Default)
                                if (accepted) {
                                    if (runCount == 0) runFirst = startedAt
                                    runCount += chunk.size
                                    runLast = SystemClock.uptimeMillis()
                                }
                            } finally {
                                chunk.forEach { pendingPoints.remove(it.pointIndex) }
                            }
                            if (policy.reached(runCount, SystemClock.uptimeMillis() - begin)) {
                                stopForLimit = true
                                break
                            }
                        }
                        // กรณี maxCount ตัดท้าย batch ทิ้ง ให้เคลียร์ pending ด้วยก่อนออก
                        batch.drop(allowed.size).forEach { pendingPoints.remove(it.pointIndex) }
                        if (stopForLimit) break
                        if (policy.reached(runCount, SystemClock.uptimeMillis() - begin)) {
                            stopForLimit = true
                            break
                        }
                    }
                    if (stopForLimit) this.coroutineContext.cancelChildren()
                }
            } finally {
                actions.close()
            }
            if (stopForLimit) stopClicking(StopReason.LIMIT)
        }
    }

    // จุดเดียวที่ใช้หยุดทุกกรณี (ผู้ใช้กด, ครบกำหนด, จอดับ, สลับแอป, ถูกระบบขัดจังหวะ)
    private fun stopClicking(reason: StopReason) {
        val wasRunning = job != null
        job?.cancel()
        job = null
        if (!wasRunning) return
        runPkg = null
        setEyeBoxesVisible(true)
        setMarkersTouchable(true)
        setRunningUi(false)
        if (runCount > 0) ConfigStore.writeLastRun(prefs, runCount, runLast - runFirst, reason)
    }

    // ส่งท่าทางแล้วแยกผลสำเร็จ / Android ปฏิเสธ / ถูกยกเลิก / ไม่ตอบ callback
    // การแยกผลทำให้ retry ได้เฉพาะ REJECTED ซึ่งยืนยันว่า Android ยังไม่ได้เริ่มท่าทาง
    private suspend fun dispatchAwait(gesture: GestureDescription, timeoutMs: Long): GestureOutcome =
        withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<GestureOutcome> { c ->
                val accepted = try {
                    dispatchGesture(
                        gesture,
                        object : AccessibilityService.GestureResultCallback() {
                            override fun onCompleted(gestureDescription: GestureDescription?) {
                                if (c.isActive) c.resume(GestureOutcome.COMPLETED)
                            }

                            override fun onCancelled(gestureDescription: GestureDescription?) {
                                if (c.isActive) c.resume(GestureOutcome.CANCELLED)
                            }
                        },
                        null
                    )
                } catch (e: RuntimeException) {
                    Log.w(TAG, "dispatchGesture threw before acceptance", e)
                    false
                }
                if (!accepted && c.isActive) c.resume(GestureOutcome.REJECTED)
            }
        } ?: GestureOutcome.TIMED_OUT

    // รวมหลายตำแหน่งเป็น GestureDescription เดียว; Stroke ทุกเส้นเริ่มเวลา 0 จึงแตะพร้อมกัน
    // หาก Android ปฏิเสธก่อนเริ่ม จะลองใหม่ได้สูงสุด 2 ครั้ง; ไม่ retry cancelled/timeout เพราะอาจแตะไปแล้วบางส่วน
    private suspend fun performBatch(actions: List<TapAction>, posJitter: Int, rnd: Random): Boolean {
        if (actions.isEmpty()) return false
        val (sw, sh) = screenSize()
        val builder = GestureDescription.Builder()
        var longest = Limits.TAP_DURATION_MS
        for (action in actions) {
            val target = action.target
            // จุดตาต้องกดตรงกลางกล่องที่กำหนดเสมอ ไม่สุ่มเลื่อนตำแหน่งจนหลุดจากปุ่มจริง
            val jitter = if (target.type == StepType.EYE) 0 else posJitter
            val x = Timing.jitterCoord(target.x, jitter, rnd).coerceIn(0f, (sw - 1).toFloat())
            val y = Timing.jitterCoord(target.y, jitter, rnd).coerceIn(0f, (sh - 1).toFloat())
            val path = android.graphics.Path().apply { moveTo(x, y) }
            val duration = target.holdMs.coerceIn(Limits.MIN_HOLD_MS, GestureDescription.getMaxGestureDuration())
            builder.addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            longest = maxOf(longest, duration)
        }
        val gesture = builder.build()
        for (attempt in 0..2) {
            when (val outcome = dispatchAwait(gesture, longest + 1500L)) {
                GestureOutcome.COMPLETED -> return true
                GestureOutcome.REJECTED -> {
                    Log.w(TAG, "dispatchGesture rejected; attempt=${attempt + 1}, points=${actions.size}")
                    if (attempt < 2) delay(80L * (attempt + 1))
                    else return false
                }
                GestureOutcome.CANCELLED -> {
                    Log.w(TAG, "Gesture cancelled by Android; points=${actions.size}")
                    return false
                }
                GestureOutcome.TIMED_OUT -> {
                    Log.w(TAG, "Gesture callback timed out; points=${actions.size}")
                    return false
                }
            }
        }
        return false
    }

    // ---------- ตา: ตรวจจับรูป/ข้อความ/สีในกล่อง ----------

    private fun buildEyeRt(pv: PointView): EyeRt {
        val loc = IntArray(2)
        pv.marker.getLocationOnScreen(loc)
        val cfg = pv.eye
        val tpl = cfg?.takeIf { it.locked }?.let { loadTpl(it.file) }
        return EyeRt(cfg, loc[0], loc[1], pv.marker.width, pv.marker.height, tpl)
    }

    private fun setEyeBoxesVisible(visible: Boolean) {
        points.forEach { if (it.type == StepType.EYE) it.marker.setCaptureMode(!visible) }   // กล่องยังแสดงอยู่ แต่ซ่อนจุดกลาง/ป้ายเลข
    }

    private fun loadTpl(file: String): Tpl? {
        val c = tplCache
        if (c != null && c.first == file) return c.second
        val tpl = try {
            val f = File(filesDir, file)
            val bmp = BitmapFactory.decodeFile(f.path)
            if (bmp == null) null else {
                val scale = minOf(1f, 96f / maxOf(bmp.width, bmp.height).toFloat())
                val sample = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        bmp,
                        (bmp.width * scale).toInt().coerceAtLeast(1),
                        (bmp.height * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else bmp
                val t = Tpl(pixelsOf(sample), sample.width, sample.height)
                if (sample !== bmp) sample.recycle()
                bmp.recycle()
                t
            }
        } catch (_: Exception) {
            null
        }
        tplCache = file to tpl
        return tpl
    }

    private fun pixelsOf(b: Bitmap): IntArray {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        return px
    }

    // ลายเซ็นภาพจิ๋ว 16×16 ใช้ตรวจว่ากรอบข้อความเปลี่ยนหรือไม่ โดยไม่ต้องเรียก OCR ซ้ำ
    private fun quickFingerprint(bitmap: Bitmap): Long {
        val sample = Bitmap.createScaledBitmap(bitmap, 16, 16, false)
        return try {
            val pixels = pixelsOf(sample)
            var hash = 1469598103934665603L
            for (pixel in pixels) {
                val gray = (((pixel shr 16) and 0xFF) * 30 +
                    ((pixel shr 8) and 0xFF) * 59 + (pixel and 0xFF) * 11) / 100
                hash = (hash xor (gray shr 4).toLong()) * 1099511628211L
            }
            hash
        } finally {
            if (sample !== bitmap && !sample.isRecycled) sample.recycle()
        }
    }

    // จับภาพทั้งจอผ่านบริการช่วยการเข้าถึง (Android 11+) ได้ภาพซอฟต์แวร์ ARGB_8888 หรือ null ถ้าไม่สำเร็จ
    @SuppressLint("NewApi")
    private suspend fun captureScreen(): Bitmap? = screenshotMutex.withLock {
        if (Build.VERSION.SDK_INT < 30) return@withLock null
        val gapWait = lastShotAt + minShotGapMs - SystemClock.uptimeMillis()
        if (gapWait > 0) delay(gapWait)
        lastShotAt = SystemClock.uptimeMillis()
        lastShotError = -1
        val bmp = withTimeoutOrNull(3000L) {
            suspendCancellableCoroutine<Bitmap?> { c ->
                try {
                    takeScreenshot(
                        Display.DEFAULT_DISPLAY,
                        ContextCompat.getMainExecutor(this@ClickService),
                        object : AccessibilityService.TakeScreenshotCallback {
                            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                                val copy = try {
                                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                                    try {
                                        hw?.copy(Bitmap.Config.ARGB_8888, false)
                                    } finally {
                                        hw?.recycle()
                                    }
                                } catch (_: Exception) {
                                    null
                                } finally {
                                    runCatching { result.hardwareBuffer.close() }
                                }
                                if (c.isActive) {
                                    lastShotError = if (copy == null) -3 else 0
                                    c.resume(copy)
                                } else {
                                    copy?.recycle()
                                }
                            }

                            override fun onFailure(errorCode: Int) {
                                if (c.isActive) {
                                    lastShotError = errorCode
                                    if (errorCode == 3) minShotGapMs = (minShotGapMs + 250L).coerceAtMost(1200L)
                                    c.resume(null)
                                }
                            }
                        }
                    )
                } catch (_: Exception) {
                    if (c.isActive) {
                        lastShotError = -2
                        c.resume(null)
                    }
                }
            }
        }
        if (bmp == null && lastShotError == -1) lastShotError = -1
        bmp
    }

    // จับภาพซ้ำเมื่อโดนจำกัดความถี่ (รหัส 3 = ห่างจากครั้งก่อนสั้นเกินไป) หรือหมดเวลา
    private suspend fun captureScreenRetry(): Bitmap? {
        repeat(4) { attempt ->
            val shot = captureScreen()
            if (shot != null) return shot
            val retryable = lastShotError == 3 || lastShotError == -1 || lastShotError == 1
            if (!retryable) return null
            delay(150L + attempt * 150L)
        }
        return null
    }

    // ตัดเฉพาะในกล่อง (เว้นขอบกล่อง 5dp) จากภาพทั้งจอ
    private suspend fun captureRegion(left: Int, top: Int, w: Int, h: Int, retry: Boolean = false): Bitmap? {
        val shot = (if (retry) captureScreenRetry() else captureScreen()) ?: return null
        val inset = dp(5)
        val l = (left + inset).coerceIn(0, shot.width - 1)
        val t = (top + inset).coerceIn(0, shot.height - 1)
        val cw = minOf(w - 2 * inset, shot.width - l)
        val ch = minOf(h - 2 * inset, shot.height - t)
        if (cw < 4 || ch < 4) {
            shot.recycle()
            return null
        }
        val out = try {
            Bitmap.createBitmap(shot, l, t, cw, ch)
        } catch (_: Exception) {
            null
        }
        if (out !== shot) shot.recycle()
        return out
    }

    private suspend fun ocr(bmp: Bitmap): String {
        // ML Kit ทำงานแบบ asynchronous และอาจยังอ่านภาพหลัง coroutine timeout/cancel แล้ว
        // ใช้สำเนาแยกและ recycle เมื่อ Task จบจริง ไม่ให้ภาพต้นฉบับถูก recycle ระหว่างอ่าน
        val ocrBitmap = try {
            bmp.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: Exception) {
            null
        } ?: return ""

        return withTimeoutOrNull(1800L) {
            suspendCancellableCoroutine { c ->
                val released = AtomicBoolean(false)
                fun releaseBitmap() {
                    if (released.compareAndSet(false, true) && !ocrBitmap.isRecycled) ocrBitmap.recycle()
                }
                try {
                    recognizerLazy.value.process(InputImage.fromBitmap(ocrBitmap, 0))
                        .addOnSuccessListener {
                            releaseBitmap()
                            if (c.isActive) c.resume(it.text)
                        }
                        .addOnFailureListener {
                            releaseBitmap()
                            if (c.isActive) c.resume("")
                        }
                } catch (_: Exception) {
                    releaseBitmap()
                    if (c.isActive) c.resume("")
                }
            }
        } ?: ""
    }

    // ตรวจภาพในกล่องกับสิ่งที่ล็อกไว้ ตามชนิด (ข้อความ/สี/รูป)
    private suspend fun evalCrop(cfg: EyeCfg, tpl: Tpl?, crop: Bitmap): EyeResult {
        return when (cfg.kind) {
            EyeMode.TEXT -> {
                val text = ocr(crop).replace('\n', ' ').trim()
                val score = EyeMatch.textSimilarity(text, cfg.text)
                val threshold = EyeMatch.textThreshold(cfg.text)
                EyeResult(
                    hit = score >= threshold,
                    strong = score >= 0.99f,
                    near = score >= threshold - 0.12f,
                    label = getString(R.string.eye_detail_text, text.take(24)),
                    cacheable = text.isNotBlank()
                )
            }
            EyeMode.COLOR -> {
                val fraction = EyeMatch.colorFraction(pixelsOf(crop), cfg.color)
                val threshold = EyeMatch.colorThreshold(cfg.colorFrac)
                EyeResult(
                    hit = fraction >= threshold,
                    strong = fraction >= threshold * 1.25f,
                    near = fraction >= threshold * 0.7f,
                    label = getString(R.string.eye_detail_color, (fraction * 100).toInt())
                )
            }
            else -> {
                if (tpl == null) {
                    EyeResult(false, false, false, getString(R.string.eye_detail_notpl))
                } else {
                    val score = EyeMatch.similarity(pixelsOf(crop), crop.width, crop.height, tpl.px, tpl.w, tpl.h) * 100f
                    EyeResult(
                        hit = score >= cfg.threshold,
                        strong = score >= (cfg.threshold + 2).coerceAtMost(100),
                        near = score >= cfg.threshold - 8,
                        label = getString(R.string.eye_detail_image, score.toInt())
                    )
                }
            }
        }
    }

    // ตัดกรอบตาจากภาพเต็มจอที่จับไว้ร่วมกัน ไม่เรียก takeScreenshot แยกแต่ละดวง
    private suspend fun evalEyeFrame(tg: Target, frame: Bitmap): EyeResult? {
        val rt = tg.eye ?: return null
        val cfg = rt.cfg ?: return null
        if (!cfg.locked) return null
        val inset = dp(5)
        val left = (rt.left + inset).coerceIn(0, frame.width - 1)
        val top = (rt.top + inset).coerceIn(0, frame.height - 1)
        val width = minOf(rt.w - 2 * inset, frame.width - left)
        val height = minOf(rt.h - 2 * inset, frame.height - top)
        if (width < 4 || height < 4) return null
        // รูป/สีไม่จำเป็นต้องใช้ภาพเต็มความละเอียด: ย่อด้านยาวสุดเหลือ 96px
        // ลดการคัดลอกพิกเซลและการคำนวณซ้ำ โดยคงภาพเต็มไว้เฉพาะ OCR ที่ต้องอ่านรายละเอียดตัวอักษร
        val scale = if (cfg.kind == EyeMode.TEXT) 1f
            else minOf(1f, 96f / maxOf(width, height).toFloat())
        val matrix = Matrix().apply { setScale(scale, scale) }
        val crop = try { Bitmap.createBitmap(frame, left, top, width, height, matrix, scale < 1f) }
            catch (_: Exception) { null } ?: return null
        return try {
            if (cfg.kind == EyeMode.TEXT) {
                val fingerprint = quickFingerprint(crop)
                val cached = rt.lastTextResult
                if (cached != null && rt.lastTextFingerprint == fingerprint) {
                    cached
                } else {
                    val result = evalCrop(cfg, rt.tpl, crop)
                    if (result.cacheable) {
                        rt.lastTextFingerprint = fingerprint
                        rt.lastTextResult = result
                    }
                    result
                }
            } else {
                evalCrop(cfg, rt.tpl, crop)
            }
        } finally {
            if (!crop.isRecycled) crop.recycle()
        }
    }

    // ---------- สร้างกล่องตา (ลากนิ้ว) ----------

    private fun startEyeRecord() {
        if (job != null || eyeCapture != null || points.size >= MAX_POINTS) return
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, getString(R.string.eye_need_android11), Toast.LENGTH_LONG).show()
            return
        }
        closeEyePanel()
        val hint = TextView(this).apply {
            text = getString(R.string.eye_hint)
            setTextColor(Color.WHITE)
            setTextSize(14f)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.argb(200, 28, 28, 30))
        }
        val box = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), OVERLAY_BLUE)
            }
            visibility = View.GONE
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(40, 10, 132, 255))
            addView(
                hint,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL
                ).apply { topMargin = dp(60) }
            )
            addView(box, FrameLayout.LayoutParams(0, 0))
        }
        var sx = 0f
        var sy = 0f
        fun rectOf(x: Float, y: Float): IntArray {
            val l = minOf(sx, x).toInt()
            val t = minOf(sy, y).toInt()
            return intArrayOf(l, t, kotlin.math.abs(x - sx).toInt(), kotlin.math.abs(y - sy).toInt())
        }
        fun showBox(x: Float, y: Float) {
            val r = rectOf(x, y)
            val lp = box.layoutParams as FrameLayout.LayoutParams
            lp.leftMargin = r[0]
            lp.topMargin = r[1]
            lp.width = r[2]
            lp.height = r[3]
            box.layoutParams = lp
        }
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.x
                    sy = e.y
                    box.visibility = View.VISIBLE
                    showBox(e.x, e.y)
                }
                MotionEvent.ACTION_MOVE -> showBox(e.x, e.y)
                MotionEvent.ACTION_UP -> {
                    val r = rectOf(e.x, e.y)
                    stopEyeRecord()
                    if (r[2] >= dp(32) && r[3] >= dp(32)) {
                        addEyePoint(r[0] + r[2] / 2, r[1] + r[3] / 2, r[2], r[3])
                    } else {
                        Toast.makeText(this, getString(R.string.eye_too_small), Toast.LENGTH_SHORT).show()
                    }
                }
                MotionEvent.ACTION_CANCEL -> stopEyeRecord()
            }
            true
        }
        wm?.addView(root, overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0, 0))
        eyeCapture = root
        // ยกแผงขึ้นบนสุด เพื่อให้กดปุ่มตาซ้ำเพื่อยกเลิกได้
        val p = panel
        val plp = panelLp
        if (p != null && plp != null) {
            safeRemove(p)
            wm?.addView(p, plp)
        }
    }

    private fun stopEyeRecord() {
        eyeCapture?.let { safeRemove(it) }
        eyeCapture = null
    }

    private fun addEyePoint(cx: Int, cy: Int, w: Int, h: Int) {
        if (points.size >= MAX_POINTS) return
        val pv = createPointView(ClickPoint(StepType.EYE, cx, cy, w, h))
        points.add(pv)
        relabel()
        savePoints()
        ConfigStore.writeSelected(prefs, points.lastIndex)
        openEyePanel(pv)   // สร้างเสร็จเปิดหน้าต่างตั้งค่าให้ล็อกต่อได้เลย
    }

    // มุมขวาล่างของกล่อง: ลากเพื่อปรับขนาด (ซ่อนตอนเปิดหน้าต่างตั้งค่าและตอนวิ่ง)
    private fun attachEyeHandle(pv: PointView) {
        val hd = View(this).apply {
            background = GradientDrawable().apply {
                setColor(OVERLAY_BLUE)
                cornerRadius = dp(3).toFloat()
            }
        }
        pv.marker.addView(hd, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.BOTTOM or Gravity.END))
        pv.handle = hd
        var w0 = 0
        var h0 = 0
        var tx = 0f
        var ty = 0f
        hd.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    w0 = pv.lp.width
                    h0 = pv.lp.height
                    tx = e.rawX
                    ty = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val (sw, sh) = screenSize()
                    pv.lp.width = (w0 + (e.rawX - tx)).toInt().coerceIn(dp(32), maxOf(dp(32), sw - pv.lp.x))
                    pv.lp.height = (h0 + (e.rawY - ty)).toInt().coerceIn(dp(32), maxOf(dp(32), sh - pv.lp.y))
                    safeUpdate(pv.marker, pv.lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> savePoints()
            }
            true
        }
    }

    // ---------- หน้าต่างตั้งค่าตา: ภาพสด + ล็อก + โหมด + ความเหมือน ----------

    private fun modeName(m: EyeMode) = getString(
        when (m) {
            EyeMode.AUTO -> R.string.eye_mode_auto
            EyeMode.IMAGE -> R.string.eye_mode_image
            EyeMode.TEXT -> R.string.eye_mode_text
            EyeMode.COLOR -> R.string.eye_mode_color
        }
    )

    private fun openEyePanel(pv: PointView) {
        if (job != null) return
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, getString(R.string.eye_need_android11), Toast.LENGTH_LONG).show()
            return
        }
        closeEyePanel()
        eyePv = pv
        pv.marker.setCaptureMode(true)
        pv.handle?.visibility = View.INVISIBLE
        val ep = EyePanelView(
            this,
            onLock = { lockEye(pv) },
            onMode = { cycleEyeMode(pv) },
            onThreshold = { d -> changeEyeThreshold(pv, d) },
            onClose = { closeEyePanel() }
        )
        val (_, sh) = screenSize()
        val (_, cy) = centerOf(pv.lp)
        val lp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0, dp(40))
        // วางหน้าต่างฝั่งตรงข้ามกล่อง ไม่ให้บังสิ่งที่ตามอง
        lp.gravity = Gravity.CENTER_HORIZONTAL or (if (cy > sh / 2) Gravity.TOP else Gravity.BOTTOM)
        wm?.addView(ep, lp)
        eyePanel = ep
        refreshEyePanel(pv)
        eyeJob = scope.launch {
            delay(150L)   // รอให้จุดกลางที่เพิ่งซ่อนหายไปจากภาพ
            while (isActive) {
                eyePreviewOnce(pv)
                delay(600L)
            }
        }
    }

    private fun closeEyePanel() {
        eyeJob?.cancel()
        eyeJob = null
        eyeLockJob?.cancel()
        eyeLockJob = null
        eyePanel?.setPreview(null)
        eyePanel?.let { safeRemove(it) }
        eyePanel = null
        lastPreviewCrop?.takeIf { !it.isRecycled }?.recycle()
        lastPreviewCrop = null
        lastPreviewAt = 0L
        lastPreviewLoc = intArrayOf(-1, -1)
        eyePv?.let {
            it.marker.setCaptureMode(false)
            it.handle?.visibility = View.VISIBLE
        }
        eyePv = null
    }

    private fun refreshEyePanel(pv: PointView) {
        val cfg = pv.eye ?: EyeCfg()
        eyePanel?.setModeLabel(getString(R.string.eye_mode_fmt, modeName(cfg.mode)))
        eyePanel?.setThreshold(cfg.threshold)
    }

    private suspend fun eyePreviewOnce(pv: PointView) {
        if (eyeLockBusy) return   // กำลังล็อกอยู่: ไม่จับภาพชนกัน
        val loc = IntArray(2)
        pv.marker.getLocationOnScreen(loc)
        val crop = captureRegion(loc[0], loc[1], pv.marker.width, pv.marker.height)
        val panelNow = eyePanel
        if (crop == null) {
            panelNow?.setStatus(getString(R.string.eye_capture_fail))
            return
        }
        // ระหว่างจับภาพอาจมีการปิดแผง/เปลี่ยนจุด ให้ทิ้งภาพแทนการอัปเดตแผงเก่า
        if (panelNow == null || panelNow !== eyePanel || eyePv !== pv) {
            crop.recycle()
            return
        }
        val previous = lastPreviewCrop
        panelNow.setPreview(crop)
        lastPreviewCrop = crop
        lastPreviewAt = System.currentTimeMillis()
        lastPreviewLoc = loc
        if (previous != null && previous !== crop && !previous.isRecycled) previous.recycle()

        val cfg = pv.eye
        if (cfg == null || !cfg.locked) {
            panelNow.setStatus(getString(R.string.eye_status_unlocked))
            return
        }
        val res = evalCrop(cfg, loadTpl(cfg.file), crop)
        if (panelNow === eyePanel && eyePv === pv) {
            panelNow.setStatus(getString(if (res.hit) R.string.eye_status_hit else R.string.eye_status_miss, res.label))
        }
    }

    private fun lockEye(pv: PointView) {
        eyeLockJob?.cancel()
        eyeLockJob = scope.launch {
            eyeLockBusy = true
            try {
                lockEyeInner(pv)
            } finally {
                eyeLockBusy = false
            }
        }
    }

    private suspend fun lockEyeInner(pv: PointView) {
        val loc = IntArray(2)
        pv.marker.getLocationOnScreen(loc)
        // ใช้ภาพตัวอย่างที่เพิ่งจับได้ถ้ากล่องยังอยู่ที่เดิม เพื่อลดการขอจับภาพซ้ำ
        val recent = lastPreviewCrop
        val reuse = recent != null && !recent.isRecycled &&
            System.currentTimeMillis() - lastPreviewAt < 2500L &&
            lastPreviewLoc[0] == loc[0] && lastPreviewLoc[1] == loc[1]
        val crop = if (reuse) {
            recent!!.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            captureRegion(loc[0], loc[1], pv.marker.width, pv.marker.height, retry = true)
        }
        if (crop == null) {
            Toast.makeText(
                this@ClickService, getString(R.string.eye_capture_fail_code, lastShotError), Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            val old = pv.eye ?: EyeCfg()
            val px = pixelsOf(crop)
            var kind = old.mode
            var text = ""
            if (old.mode == EyeMode.AUTO || old.mode == EyeMode.TEXT) {
                text = ocr(crop).replace('\n', ' ').trim()
                val enough = EyeMatch.normText(text).length >= (if (old.mode == EyeMode.TEXT) 1 else 2)
                kind = when {
                    enough -> EyeMode.TEXT
                    old.mode == EyeMode.TEXT -> EyeMode.TEXT
                    EyeMatch.isUniform(px) -> EyeMode.COLOR
                    else -> EyeMode.IMAGE
                }
                if (kind == EyeMode.TEXT && !enough) {
                    Toast.makeText(this@ClickService, getString(R.string.eye_no_text), Toast.LENGTH_LONG).show()
                    return
                }
                if (kind != EyeMode.TEXT) text = ""
            }
            val (color, frac) = if (kind == EyeMode.COLOR) EyeMatch.pickTargetColor(px) else (0 to 0f)
            val name = "eye_${System.currentTimeMillis()}.png"
            val saved = try {
                File(filesDir, name).outputStream().use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (_: Exception) {
                false
            }
            if (!saved) {
                Toast.makeText(this@ClickService, getString(R.string.eye_capture_fail), Toast.LENGTH_LONG).show()
                return
            }
            tplCache = null
            pv.eye = old.copy(kind = kind, text = text, color = color, colorFrac = frac, file = name)
            savePoints()
            refreshEyePanel(pv)
            Toast.makeText(this@ClickService, getString(R.string.eye_locked, modeName(kind)), Toast.LENGTH_SHORT).show()
        } finally {
            if (!crop.isRecycled) crop.recycle()
        }
    }

    // เปลี่ยนโหมด = ต้องล็อกใหม่ (ปลดล็อกของเดิม) เพื่อให้ค่าที่จำตรงกับโหมดที่เลือก
    private fun cycleEyeMode(pv: PointView) {
        val old = pv.eye ?: EyeCfg()
        pv.eye = old.copy(mode = old.mode.next(), file = "", text = "", color = 0, colorFrac = 0f)
        savePoints()
        refreshEyePanel(pv)
    }

    private fun changeEyeThreshold(pv: PointView, delta: Int) {
        val old = pv.eye ?: EyeCfg()
        pv.eye = old.copy(threshold = (old.threshold + delta).coerceIn(50, 100))
        savePoints()
        refreshEyePanel(pv)
    }
}
