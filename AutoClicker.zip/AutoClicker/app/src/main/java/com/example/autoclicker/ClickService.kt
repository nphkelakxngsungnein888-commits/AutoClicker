package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class ClickService : AccessibilityService() {

    companion object {
        const val MAX_POINTS = 20
        private const val END_SCALE_FACTOR = 0.7f
        private const val SYSTEM_UI_PKG = "com.android.systemui"
        private const val MIRROR_START_DELAY_MS = 50L   // รอให้หน้าต่างบันทึกหดก่อน ค่อยฉีดการแตะลงแอปด้านล่าง

        // ให้ MainActivity สั่งแสดงปุ่มลอย/ปิดบริการได้ (อยู่ใน process และ main thread เดียวกัน)
        @Volatile
        var instance: ClickService? = null
            private set
    }

    // จุดคลิกหนึ่งจุด = ป้ายวงกลม (และป้ายปลายทางถ้าเป็น SWIPE)
    private class PointView(
        var type: StepType,
        val marker: MarkerView,
        val lp: WindowManager.LayoutParams,
        var end: MarkerView? = null,
        var endLp: WindowManager.LayoutParams? = null
    )

    // พิกัดจริงบนหน้าจอ ณ ตอนกดเริ่ม
    private class Target(val type: StepType, val x: Float, val y: Float, val x2: Float, val y2: Float, val holdMs: Long)

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main +
            CoroutineExceptionHandler { _, _ -> stopClicking(StopReason.INTERRUPTED) }
    )
    private var job: Job? = null
    private var wm: WindowManager? = null

    private val points = mutableListOf<PointView>()
    private var panel: PanelView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var capture: FrameLayout? = null   // หน้าต่างจับการลากนิ้วตอนบันทึกการปัด
    private var arrowView: ArrowView? = null   // ลูกศรจากปุ่มแม่ไปปุ่มลูกของจุดปัด
    private var captureLp: WindowManager.LayoutParams? = null
    private var swipeMirror: SwipeMirror? = null   // ตัวฉีดการลากสดลงแอปด้านล่างระหว่างบันทึกการปัด
    private val mainHandler = Handler(Looper.getMainLooper())
    var overlaysVisible = false
        private set

    private var fgPkg: String? = null
    private var runPkg: String? = null
    private var runCount = 0
    private var runFirst = 0L
    private var runLast = 0L
    private var hotkeyOn = false
    private var receiverRegistered = false

    private val prefs by lazy { ConfigStore.prefs(this) }
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            ConfigStore.KEY_PANEL_SCALE, ConfigStore.KEY_MARKER_SCALE -> applyScales()
            ConfigStore.KEY_REV -> {
                if (overlaysVisible) rebuildOverlays()
            }
            ConfigStore.KEY_HOTKEY -> applyKeyFlag()
            else -> {}
        }
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (job != null && ConfigStore.readSettings(prefs).stopOnScreenOff) {
                stopClicking(StopReason.SCREEN_OFF)
            }
        }
    }

    // ---------- วงจรชีวิตบริการ ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this, screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
        applyKeyFlag()
        if (!overlaysVisible) showOverlays()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        clampAll()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == SYSTEM_UI_PKG) return
        fgPkg = pkg
        if (job != null && ConfigStore.readSettings(prefs).stopOnAppChange) {
            val running = runPkg
            if (running == null) runPkg = pkg
            else if (pkg != running) stopClicking(StopReason.APP_CHANGED)
        }
    }

    // ปุ่มลัด: ปุ่มเพิ่มเสียง = เริ่ม/หยุด (เปิดใช้เฉพาะเมื่อผู้ใช้เปิดในหน้าตั้งค่า)
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!hotkeyOn || !overlaysVisible || event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggle()
        return true
    }

    override fun onInterrupt() {
        stopClicking(StopReason.INTERRUPTED)
    }

    override fun onDestroy() {
        instance = null
        prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenOffReceiver) }
            receiverRegistered = false
        }
        job?.cancel()
        job = null
        removeOverlays()
        scope.cancel()
        super.onDestroy()
    }

    // การขอรับเหตุการณ์ปุ่มกด (FLAG_REQUEST_FILTER_KEY_EVENTS) เปิดเฉพาะตอนผู้ใช้เปิดปุ่มลัด
    private fun applyKeyFlag() {
        hotkeyOn = ConfigStore.readSettings(prefs).volumeHotkey
        val info = serviceInfo ?: return
        val flag = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        val has = info.flags and flag != 0
        if (hotkeyOn != has) {
            info.flags = if (hotkeyOn) info.flags or flag else info.flags and flag.inv()
            serviceInfo = info
        }
    }

    // ---------- เครื่องมือช่วย ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screenSize(): Pair<Int, Int> {
        val w = wm
        if (w != null) {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = w.currentWindowMetrics.bounds
                return b.width() to b.height()
            }
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            w.defaultDisplay.getRealMetrics(dm)
            return dm.widthPixels to dm.heightPixels
        }
        val dm = resources.displayMetrics
        return dm.widthPixels to dm.heightPixels
    }

    private fun clampLp(lp: WindowManager.LayoutParams, w: Int, h: Int) {
        val (sw, sh) = screenSize()
        lp.x = lp.x.coerceIn(0, maxOf(0, sw - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, sh - h))
    }

    // TYPE_ACCESSIBILITY_OVERLAY: บริการช่วยการเข้าถึงเพิ่มหน้าต่างชนิดนี้ได้โดยไม่ต้องขอสิทธิ์ SYSTEM_ALERT_WINDOW
    private fun overlayLp(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun scaleOf(key: String) =
        prefs.getInt(key, Limits.DEFAULT_SCALE).coerceIn(Limits.MIN_SCALE, Limits.MAX_SCALE)

    private fun endScale() = (scaleOf(ConfigStore.KEY_MARKER_SCALE) * END_SCALE_FACTOR).toInt().coerceAtLeast(20)

    private fun centerOf(lp: WindowManager.LayoutParams) = (lp.x + lp.width / 2) to (lp.y + lp.height / 2)

    private fun safeRemove(v: View) {
        try {
            wm?.removeView(v)
        } catch (_: IllegalArgumentException) {
            // view ไม่ได้ถูกเพิ่มอยู่แล้ว
        }
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm?.updateViewLayout(v, lp)
        } catch (_: IllegalArgumentException) {
        }
    }

    // ---------- สร้าง/ลบปุ่มลอย ----------

    fun showOverlays() {
        if (overlaysVisible || wm == null) return
        val saved = ConfigStore.readPoints(prefs).take(MAX_POINTS)
        // ครั้งแรกที่ยังไม่เคยบันทึกจุด = สร้างปุ่ม 1 ให้; ถ้าผู้ใช้ลบหมดแล้ว (บันทึกเป็นรายการว่าง) ให้ว่างต่อไป
        val firstRun = !prefs.contains(ConfigStore.KEY_POINTS)
        val list = if (firstRun) listOf(defaultPoint()) else saved
        addArrow()   // เพิ่มก่อนป้าย เพื่อให้ลูกศรอยู่ใต้ป้ายและแผง
        list.forEach { points.add(createPointView(it)) }
        addPanel()
        overlaysVisible = true
        relabel()
        if (firstRun) savePoints()
    }

    private fun defaultPoint(): ClickPoint {
        val (sw, sh) = screenSize()
        return ClickPoint(StepType.TAP, minOf(dp(180), sw / 2), minOf(dp(330), sh / 2))
    }

    fun hideOverlays() {
        stopClicking(StopReason.MANUAL)
        removeOverlays()
    }

    private fun rebuildOverlays() {
        stopClicking(StopReason.MANUAL)
        removeOverlays()
        showOverlays()
    }

    private fun removeOverlays() {
        points.forEach { pv ->
            safeRemove(pv.marker)
            pv.end?.let { safeRemove(it) }
        }
        points.clear()
        stopSwipeRecord()
        panel?.let { safeRemove(it) }
        panel = null
        panelLp = null
        arrowView?.let { safeRemove(it) }
        arrowView = null
        overlaysVisible = false
    }

    private fun addArrow() {
        val v = ArrowView(this)
        val lp = overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0, 0)
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE   // แตะทะลุเสมอ
        wm?.addView(v, lp)
        arrowView = v
    }

    // วาดลูกศรใหม่จากตำแหน่งปัจจุบันของปุ่มแม่/ปุ่มลูก (เรียกทุกครั้งที่ปุ่มขยับ เปลี่ยนขนาด เพิ่ม/ลบ)
    private fun updateArrows() {
        val v = arrowView ?: return
        val list = points.mapIndexedNotNull { i, pv ->
            val elp = pv.endLp ?: return@mapIndexedNotNull null
            val (cx, cy) = centerOf(pv.lp)
            val (ex, ey) = centerOf(elp)
            ArrowView.Arrow(i, cx.toFloat(), cy.toFloat(), ex.toFloat(), ey.toFloat(), pv.lp.width / 2f, elp.width / 2f)
        }
        v.setArrows(list, scaleOf(ConfigStore.KEY_MARKER_SCALE))
    }

    private fun createPointView(model: ClickPoint): PointView {
        val marker = MarkerView(this)
        marker.setScale(scaleOf(ConfigStore.KEY_MARKER_SCALE))
        val size = marker.sizePx(marker.scale)
        val lp = overlayLp(size, size, model.x - size / 2, model.y - size / 2)
        clampLp(lp, size, size)
        val pv = PointView(model.type, marker, lp)
        // แตะที่จุด (ไม่ลาก) = สลับชนิด: แตะ → กดค้าง → ปัด
        makeDraggable(marker, lp, onTap = { cycleType(pv) }, onDragEnd = { savePoints() })
        wm?.addView(marker, lp)
        if (model.type == StepType.SWIPE) addEnd(pv, model.x2, model.y2)
        return pv
    }

    private fun addEnd(pv: PointView, cx: Int, cy: Int) {
        val m = MarkerView(this)
        m.setColor(OVERLAY_BLUE)
        m.setScale(endScale())
        val size = m.sizePx(m.scale)
        val lp = overlayLp(size, size, cx - size / 2, cy - size / 2)
        clampLp(lp, size, size)
        makeDraggable(m, lp, onTap = { if (TimeSettingsActivity.isOpen) ConfigStore.writeSelected(prefs, points.indexOf(pv)) }, onDragEnd = { savePoints() })
        wm?.addView(m, lp)
        pv.end = m
        pv.endLp = lp
    }

    private fun removeEnd(pv: PointView) {
        pv.end?.let { safeRemove(it) }
        pv.end = null
        pv.endLp = null
    }

    private fun addPanel() {
        val root = PanelView(this)
        root.setScale(scaleOf(ConfigStore.KEY_PANEL_SCALE))
        val (px, py) = ConfigStore.readPanelPos(prefs) ?: (dp(16) to dp(120))
        val lp = overlayLp(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            maxOf(px, 0), maxOf(py, 0)
        )
        // ตอนกำลังคลิก: แค่ "แตะลง" (DOWN) ที่ปุ่มก็หยุดทันที ไม่ต้องรอปล่อยนิ้ว
        // เพราะการแตะอัตโนมัติความเร็วสูงอาจทำให้การแตะของผู้ใช้ถูกยกเลิกก่อนปล่อยนิ้ว
        makeDraggable(
            root, lp,
            onTap = { x ->
                when (root.actionAt(x)) {
                    PanelAction.TOGGLE -> toggle()
                    PanelAction.ADD -> addPoint()
                    PanelAction.REMOVE -> removePoint()
                    PanelAction.SWIPE -> if (capture != null) stopSwipeRecord() else startSwipeRecord()
                    PanelAction.SAVE -> openProfileDialog(ProfileDialogActivity.MODE_SAVE)
                    PanelAction.LOAD -> openProfileDialog(ProfileDialogActivity.MODE_LOAD)
                    PanelAction.SETTINGS -> openTimeSettings()
                    PanelAction.HIDE -> hideOverlays()
                }
            },
            onDown = { x ->
                if (job != null) {
                    if (root.actionAt(x) == PanelAction.HIDE) hideOverlays() else stopClicking(StopReason.MANUAL)
                    true
                } else false
            },
            onDragEnd = { ConfigStore.writePanelPos(prefs, lp.x, lp.y) }
        )
        wm?.addView(root, lp)
        panel = root
        panelLp = lp
        // ขนาดจริงของแผงรู้หลังจัดวาง → ดึงกลับเข้าจอถ้าตำแหน่งที่บันทึกไว้หลุดขอบ
        root.post {
            if (panel === root) {
                clampLp(lp, root.width, root.height)
                safeUpdate(root, lp)
            }
        }
    }

    // เปิดหน้าตั้งค่าเวลา (กล่องโต้ตอบ) — ใช้ Activity เพราะหน้าต่างลอยของบริการพิมพ์ตัวเลขไม่ได้
    private fun openTimeSettings() {
        if (job != null) return
        startActivity(Intent(this, TimeSettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // เปิดกล่องเซฟ/โหลด (Activity เพราะต้องพิมพ์ชื่อด้วยแป้นพิมพ์) — เซฟตำแหน่งจุดล่าสุดลงที่เก็บก่อนเสมอ
    private fun openProfileDialog(mode: String) {
        if (job != null) return
        savePoints()
        startActivity(
            Intent(this, ProfileDialogActivity::class.java)
                .putExtra(ProfileDialogActivity.EXTRA_MODE, mode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------- บันทึกการปัดแบบเรียลไทม์ ----------
    // เปิดโหมด: มีหน้าต่างโปร่งเต็มจอรับการลากนิ้ว กดค้างที่จุดเริ่มแล้วลากไปจุดสิ้นสุด ปล่อยนิ้ว = สร้างจุดปัดใหม่
    // เวลาปัด = เวลาจริงตั้งแต่แตะลงถึงปล่อย (เก็บใน holds) ความแรง = ระยะ ÷ เวลา คำนวณจากค่านี้
    private fun startSwipeRecord() {
        if (job != null || capture != null || points.size >= MAX_POINTS) return
        val hint = TextView(this).apply {
            text = getString(R.string.swipe_hint)
            setTextColor(Color.WHITE)
            setTextSize(14f)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.argb(200, 28, 28, 30))
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(60, 10, 132, 255))
            addView(
                hint,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL
                ).apply { topMargin = dp(60) }
            )
        }
        var sx = 0f
        var sy = 0f
        var offX = 0
        var offY = 0
        var t0 = 0L
        var device = -1
        root.setOnTouchListener { v, e ->
            // การแตะที่ระบบฉีดเอง (คนละอุปกรณ์กับนิ้วจริง) ไม่นับเป็นการบันทึก
            if (device != -1 && e.deviceId != device) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val loc = IntArray(2)
                    v.getLocationOnScreen(loc)
                    offX = loc[0]
                    offY = loc[1]
                    device = e.deviceId
                    sx = e.rawX - offX
                    sy = e.rawY - offY
                    t0 = SystemClock.uptimeMillis()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        // หดหน้าต่างบันทึกให้เล็กสุด เพื่อให้การแตะที่ฉีดลงไปทะลุถึงแอปด้านล่าง
                        // (นิ้วจริงยังส่งเหตุการณ์ต่อให้หน้าต่างเดิมจนปล่อยนิ้ว — ใช้พิกัดจอ rawX/rawY)
                        swipeMirror = SwipeMirror(e.rawX, e.rawY, t0)
                        shrinkCapture()
                    }
                }
                MotionEvent.ACTION_MOVE -> swipeMirror?.moveTo(e.rawX, e.rawY)
                MotionEvent.ACTION_UP -> {
                    val dur = (SystemClock.uptimeMillis() - t0).coerceIn(Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS)
                    val ex = e.rawX - offX
                    val ey = e.rawY - offY
                    val mirror = swipeMirror
                    swipeMirror = null
                    // สร้างจุดปัดหลังฉีดช่วงสุดท้ายเสร็จ เพื่อไม่ให้ป้ายใหม่บังการแตะที่กำลังฉีด
                    val create: () -> Unit = {
                        if (overlaysVisible && hypot(ex - sx, ey - sy) >= dp(24)) {
                            addSwipePoint(sx.toInt(), sy.toInt(), ex.toInt(), ey.toInt(), dur)
                        }
                    }
                    if (mirror == null) create() else {
                        mirror.onEnd = create
                        mirror.finishAt(e.rawX, e.rawY)
                    }
                    stopSwipeRecord()
                }
                MotionEvent.ACTION_CANCEL -> stopSwipeRecord()
            }
            true
        }
        val captureParams = overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0, 0)
        wm?.addView(root, captureParams)
        captureLp = captureParams
        capture = root
        // ยกแผงขึ้นบนสุด เพื่อให้กดปุ่มปัดซ้ำเพื่อยกเลิกได้
        val p = panel
        val plp = panelLp
        if (p != null && plp != null) {
            safeRemove(p)
            wm?.addView(p, plp)
        }
    }

    private fun stopSwipeRecord() {
        swipeMirror?.finish()   // ส่งช่วงสุดท้ายให้นิ้วที่ฉีดไว้ยกขึ้นเสมอ ไม่ให้ค้าง
        swipeMirror = null
        capture?.let { safeRemove(it) }
        capture = null
        captureLp = null
    }

    private fun shrinkCapture() {
        val v = capture ?: return
        val lp = captureLp ?: return
        lp.width = 1
        lp.height = 1
        lp.x = 0
        lp.y = 0
        safeUpdate(v, lp)
    }

    // ฉีดการลากของนิ้วจริงลงแอปด้านล่างแบบเรียลไทม์ระหว่างบันทึกการปัด (ท่าทางต่อเนื่องหลายช่วง)
    // ส่งช่วงถัดไปเมื่อช่วงก่อนหน้าเสร็จ โดยลากจากตำแหน่งที่ฉีดไปแล้วถึงตำแหน่งนิ้วล่าสุด
    @RequiresApi(Build.VERSION_CODES.O)
    private inner class SwipeMirror(startX: Float, startY: Float, downTime: Long) {
        var onEnd: (() -> Unit)? = null
        private var stroke: GestureDescription.StrokeDescription? = null
        private var curX = startX
        private var curY = startY
        private var tgtX = startX
        private var tgtY = startY
        private var started = false
        private var inFlight = false
        private var finishing = false
        private var finalSent = false
        private var closed = false
        private var seq = 0
        private var lastTime = downTime

        init {
            mainHandler.postDelayed({
                started = true
                pump()
            }, MIRROR_START_DELAY_MS)
        }

        private fun setTarget(x: Float, y: Float) {
            val (sw, sh) = screenSize()
            tgtX = x.coerceIn(0f, (sw - 1).toFloat())
            tgtY = y.coerceIn(0f, (sh - 1).toFloat())
        }

        fun moveTo(x: Float, y: Float) {
            if (closed || finishing) return
            setTarget(x, y)
            pump()
        }

        fun finishAt(x: Float, y: Float) {
            if (closed || finishing) return
            setTarget(x, y)
            finishing = true
            pump()
        }

        fun finish() {
            if (closed || finishing) return
            finishing = true
            pump()
        }

        private fun close() {
            if (closed) return
            closed = true
            val cb = onEnd
            onEnd = null
            cb?.invoke()
        }

        private fun pump() {
            if (closed || inFlight || !started) return
            val moved = tgtX != curX || tgtY != curY
            if (stroke != null && !moved && !finishing) return   // รอให้นิ้วขยับก่อนค่อยส่งช่วงถัดไป
            val now = SystemClock.uptimeMillis()
            val path = Path().apply {
                moveTo(curX, curY)
                if (moved) lineTo(tgtX, tgtY)
            }
            val dur = (now - lastTime).coerceIn(1L, 1000L)
            val cont = !finishing
            val prev = stroke
            val s = try {
                prev?.continueStroke(path, 0L, dur, cont)
                    ?: GestureDescription.StrokeDescription(path, 0L, dur, cont)
            } catch (_: Exception) {
                close()
                return
            }
            val my = ++seq
            inFlight = true
            val accepted = dispatchGesture(
                GestureDescription.Builder().addStroke(s).build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (my == seq) done(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (my == seq) done(false)
                    }
                },
                null
            )
            if (!accepted) {
                inFlight = false
                close()
                return
            }
            stroke = s
            curX = tgtX
            curY = tgtY
            lastTime = now
            if (!cont) finalSent = true
            // กัน callback ไม่ถูกเรียก: ถ้าเงียบเกิน 1.5 วินาที ให้ปิดท่าทาง (ส่งช่วงสุดท้ายถ้ายังไม่ได้ส่ง)
            mainHandler.postDelayed({
                if (my == seq && inFlight && !closed) {
                    seq++
                    inFlight = false
                    if (finalSent) close() else {
                        finishing = true
                        pump()
                    }
                }
            }, 1500L)
        }

        private fun done(ok: Boolean) {
            inFlight = false
            if (finalSent || !ok) {
                close()
                return
            }
            pump()
        }
    }

    private fun addSwipePoint(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long) {
        if (points.size >= MAX_POINTS) return
        points.add(createPointView(ClickPoint(StepType.SWIPE, x1, y1, x2, y2)))
        val idx = points.lastIndex
        relabel()
        savePoints()
        val holds = ConfigStore.readHolds(prefs).toMutableList()
        while (holds.size <= idx) holds.add(-1L)
        holds[idx] = durationMs
        ConfigStore.writeHolds(prefs, holds)
        ConfigStore.writeSelected(prefs, idx)
    }

    // ---------- จัดการจุด ----------

    private fun relabel() {
        points.forEachIndexed { i, pv ->
            val n = i + 1
            pv.marker.setLabel(
                when (pv.type) {
                    StepType.TAP -> "$n"
                    StepType.LONG -> "${n}L"
                    StepType.SWIPE -> "${n}S"
                }
            )
            pv.end?.setLabel("$n→")
        }
        updateArrows()
    }

    private fun savePoints() {
        ConfigStore.writePoints(prefs, points.map { pv ->
            val (cx, cy) = centerOf(pv.lp)
            val (ex, ey) = pv.endLp?.let { centerOf(it) } ?: (cx to cy)
            ClickPoint(pv.type, cx, cy, ex, ey)
        })
    }

    private fun cycleType(pv: PointView) {
        if (job != null) return
        // หน้าตั้งค่าเปิดอยู่: แตะปุ่ม = เลือกปุ่มนั้นเพื่อดูค่า (ไม่สลับชนิด)
        if (TimeSettingsActivity.isOpen) {
            ConfigStore.writeSelected(prefs, points.indexOf(pv))
            return
        }
        // จุดปัดสร้างจากปุ่มปัดเท่านั้น: แตะจุดปัดไม่สลับชนิด; แตะ ↔ กดค้าง สลับกันได้
        if (pv.type == StepType.SWIPE) return
        val next = pv.type.next().let { if (it == StepType.SWIPE) StepType.TAP else it }
        pv.type = next
        if (next == StepType.SWIPE) {
            val (cx, cy) = centerOf(pv.lp)
            val (sw, _) = screenSize()
            val ex = if (cx + dp(110) < sw) cx + dp(110) else cx - dp(110)
            addEnd(pv, ex, cy)
        } else {
            removeEnd(pv)
        }
        relabel()
        savePoints()
    }

    private fun addPoint() {
        if (job != null) return
        if (points.size >= MAX_POINTS) return
        val last = points.lastOrNull()
        if (last == null) {
            // ไม่มีปุ่มเหลือเลย: เริ่มที่ตำแหน่งเริ่มต้น
            points.add(createPointView(defaultPoint()))
            relabel()
            savePoints()
            return
        }
        val (cx, cy) = centerOf(last.lp)
        val (sw, _) = screenSize()
        var nx = cx + dp(70)
        var ny = cy
        if (nx > sw - dp(40)) {
            nx = dp(60)
            ny = cy + dp(70)
        }
        points.add(createPointView(ClickPoint(StepType.TAP, nx, ny)))
        relabel()
        savePoints()
    }

    private fun removePoint() {
        if (job != null || points.isEmpty()) return
        val pv = points.removeAt(points.lastIndex)
        safeRemove(pv.marker)
        removeEnd(pv)
        relabel()
        savePoints()
        // ตัดค่าเวลาหน่วง/เวลากดรายจุดของปุ่มที่ลบทิ้ง ไม่ให้ปุ่มที่เพิ่มทีหลังได้ค่าเก่าไป
        val delays = ConfigStore.readDelays(prefs)
        if (delays.size > points.size) ConfigStore.writeDelays(prefs, delays.take(points.size))
        val holds = ConfigStore.readHolds(prefs)
        if (holds.size > points.size) ConfigStore.writeHolds(prefs, holds.take(points.size))
        ConfigStore.writeSelected(prefs, ConfigStore.readSelected(prefs).coerceAtMost(maxOf(0, points.lastIndex)))
    }

    // ---------- ขนาด/ตำแหน่ง ----------

    private fun resizeAround(v: MarkerView, lp: WindowManager.LayoutParams, pct: Int) {
        val newSize = v.sizePx(pct)
        val delta = (lp.width - newSize) / 2   // ขยาย/ย่อรอบจุดกึ่งกลางเดิม ตำแหน่งแตะไม่ขยับ
        lp.x += delta
        lp.y += delta
        lp.width = newSize
        lp.height = newSize
        v.setScale(pct)
        safeUpdate(v, lp)
    }

    // ปรับขนาดแผงและจุดคลิกทันทีเมื่อผู้ใช้เลื่อนแถบในหน้าตั้งค่า (ไม่ต้องปิด/เปิดบริการใหม่)
    private fun applyScales() {
        points.forEach { pv ->
            resizeAround(pv.marker, pv.lp, scaleOf(ConfigStore.KEY_MARKER_SCALE))
            val e = pv.end
            val elp = pv.endLp
            if (e != null && elp != null) resizeAround(e, elp, endScale())
        }
        val p = panel
        val lp = panelLp
        if (p != null && lp != null) {
            p.setScale(scaleOf(ConfigStore.KEY_PANEL_SCALE))
            safeUpdate(p, lp)
        }
        updateArrows()
    }

    // หมุนจอ/เปลี่ยนขนาดจอ: ดึงปุ่มทั้งหมดกลับเข้าในจอ
    private fun clampAll() {
        points.forEach { pv ->
            clampLp(pv.lp, pv.lp.width, pv.lp.height)
            safeUpdate(pv.marker, pv.lp)
            val e = pv.end
            val elp = pv.endLp
            if (e != null && elp != null) {
                clampLp(elp, elp.width, elp.height)
                safeUpdate(e, elp)
            }
        }
        val p = panel
        val lp = panelLp
        if (p != null && lp != null) {
            clampLp(lp, p.width, p.height)
            safeUpdate(p, lp)
        }
        updateArrows()
    }

    private fun makeDraggable(
        v: View,
        lp: WindowManager.LayoutParams,
        onTap: ((Float) -> Unit)?,
        onDown: ((Float) -> Boolean)? = null,
        onDragEnd: (() -> Unit)? = null
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var consumed = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    consumed = onDown?.invoke(e.x) == true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved && !consumed) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        clampLp(lp, v.width, v.height)
                        safeUpdate(v, lp)
                        updateArrows()   // ลูกศรตามปุ่มแม่/ลูกที่กำลังลาก
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!consumed) {
                        if (moved) onDragEnd?.invoke() else onTap?.invoke(e.x)
                    }
                    true
                }
                // ถ้าระบบยกเลิกการแตะของผู้ใช้ที่ปุ่มระหว่างกำลังคลิก ให้ถือว่าผู้ใช้ต้องการหยุด
                MotionEvent.ACTION_CANCEL -> {
                    if (onDown != null && job != null) stopClicking(StopReason.MANUAL)
                    else if (moved && !consumed) onDragEnd?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- เริ่ม/หยุด ----------

    private fun toggle() {
        if (job != null) stopClicking(StopReason.MANUAL) else {
            stopSwipeRecord()
            startClicking()
        }
    }

    private fun screenCenter(v: View): Pair<Float, Float> {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return (loc[0] + v.width / 2f) to (loc[1] + v.height / 2f)
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        // ให้การแตะทะลุป้ายลงไป เพื่อไม่ให้ป้ายกลืนการแตะของตัวเอง
        fun apply(v: View, lp: WindowManager.LayoutParams) {
            lp.flags = if (touchable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            safeUpdate(v, lp)
        }
        points.forEach { pv ->
            apply(pv.marker, pv.lp)
            val e = pv.end
            val elp = pv.endLp
            if (e != null && elp != null) apply(e, elp)
        }
    }

    // อัปเดตสีจุดคลิกและปุ่มเริ่ม/หยุดให้ตรงกับสถานะ
    private fun setRunningUi(running: Boolean) {
        points.forEach { it.marker.setColor(if (running) OVERLAY_GREEN else OVERLAY_RED) }
        panel?.setRunning(running)
    }

    private fun startClicking() {
        if (job != null || points.isEmpty()) return
        val s = ConfigStore.readSettings(prefs)
        val delays = ConfigStore.readDelays(prefs)
        val holds = ConfigStore.readHolds(prefs)
        val targets = points.mapIndexed { i, pv ->
            val (x, y) = screenCenter(pv.marker)
            val (x2, y2) = pv.end?.let { screenCenter(it) } ?: (x to y)
            Target(pv.type, x, y, x2, y2, Timing.holdMs(pv.type, holds, i))
        }

        runCount = 0
        runFirst = 0L
        runLast = 0L
        runPkg = fgPkg
        setMarkersTouchable(false)
        setRunningUi(true)

        // กำหนดจังหวะแบบ fixed-rate จากนาฬิการะบบ: ไม่เอา "เวลาที่ใช้แตะ" มาบวกสะสมทุกรอบ
        // (แบบเดิม tap แล้ว delay(interval) ทำให้คาบจริง = interval + เวลา dispatch ซึ่งเพิ่มขึ้นเมื่อเครื่องหน่วง)
        job = scope.launch {
            if (s.startDelayMs > 0L) delay(s.startDelayMs)
            val policy = StopPolicy(s.maxCount, s.maxSeconds)
            val rnd = Random.Default
            val begin = SystemClock.uptimeMillis()
            var next = begin
            var i = 0
            while (isActive) {
                val t0 = SystemClock.uptimeMillis()
                if (runCount == 0) runFirst = t0
                runLast = t0
                if (targets[i].type == StepType.SWIPE) arrowView?.pulse(i, targets[i].holdMs)   // จุดสว่างวิ่งตามลูกศรทุกครั้งที่ปัด
                perform(targets[i], s.posJitterPx, rnd)
                runCount++
                if (policy.reached(runCount, SystemClock.uptimeMillis() - begin)) {
                    stopClicking(StopReason.LIMIT)
                    return@launch
                }
                next += Timing.jitterDelay(Timing.stepDelay(s, delays, i), s.jitterPercent, rnd)
                i = (i + 1) % targets.size
                val now = SystemClock.uptimeMillis()
                if (next <= now) next = now   // ตามไม่ทัน: เริ่มนับใหม่ ไม่แตะรัวชดเชย
                else delay(next - now)
            }
        }
    }

    // จุดเดียวที่ใช้หยุดทุกกรณี (ผู้ใช้กด, ครบกำหนด, จอดับ, สลับแอป, ถูกระบบขัดจังหวะ)
    private fun stopClicking(reason: StopReason) {
        val wasRunning = job != null
        job?.cancel()
        job = null
        if (!wasRunning) return
        runPkg = null
        setMarkersTouchable(true)
        setRunningUi(false)
        if (runCount > 0) ConfigStore.writeLastRun(prefs, runCount, runLast - runFirst, reason)
    }

    // รอจนท่าทางเสร็จ/ถูกยกเลิก เพื่อไม่ให้การแตะซ้อนกัน
    private suspend fun perform(t: Target, posJitter: Int, rnd: Random) {
        val (sw, sh) = screenSize()
        fun jx(v: Float) = Timing.jitterCoord(v, posJitter, rnd).coerceIn(0f, (sw - 1).toFloat())
        fun jy(v: Float) = Timing.jitterCoord(v, posJitter, rnd).coerceIn(0f, (sh - 1).toFloat())

        val path = Path().apply {
            moveTo(jx(t.x), jy(t.y))
            if (t.type == StepType.SWIPE && (t.x2 != t.x || t.y2 != t.y)) lineTo(jx(t.x2), jy(t.y2))
        }
        val duration = t.holdMs
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        // กัน callback ไม่ถูกเรียก (ระบบหน่วง/ถูกยกเลิกเงียบ ๆ) ไม่ให้ลูปค้าง
        withTimeoutOrNull(duration + 1000L) {
            suspendCancellableCoroutine<Unit> { c ->
                val accepted = dispatchGesture(
                    gesture,
                    object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            if (c.isActive) c.resume(Unit)
                        }

                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            if (c.isActive) c.resume(Unit)
                        }
                    },
                    null
                )
                if (!accepted && c.isActive) c.resume(Unit)
            }
        }
    }
}
