package com.example.autoclicker

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// กล่องตั้งค่าเวลารายจุด: "รอก่อนจุดถัดไป" และ "เวลากด/ปัด" — เปิดจากปุ่ม ⚙ บนแผงลอย หรือจากหน้าแอป
// ใช้ Activity (ไม่ใช่หน้าต่างลอยของบริการ) เพราะต้องพิมพ์ตัวเลขด้วยแป้นพิมพ์
class TimeSettingsActivity : Activity() {

    private val cardColor = Color.parseColor("#1C1C1E")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private lateinit var prefs: SharedPreferences
    private lateinit var timeUnit: TimeUnitOpt
    private val fields = mutableListOf<TimeField>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun labeled(caption: String, field: TimeField) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv(caption, 12f, grayText))
        addView(field.view, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(2) })
    }

    // เขียนค่าลงรายการตามลำดับจุด (เติม -1 ให้ครบก่อน; -1 = ใช้ค่าเริ่มต้น)
    private fun store(read: () -> List<Long>, write: (List<Long>) -> Unit, index: Int, value: Long) {
        val list = read().toMutableList()
        while (list.size <= index) list.add(-1L)
        list[index] = value
        write(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = ConfigStore.prefs(this)
        timeUnit = ConfigStore.readTimeUnit(prefs)

        val points = ConfigStore.readPoints(prefs)
        val delays = ConfigStore.readDelays(prefs)
        val holds = ConfigStore.readHolds(prefs)
        val interval = ConfigStore.readSettings(prefs).intervalMs

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (points.isEmpty()) {
            list.addView(tv(getString(R.string.perpoint_empty), 14f, grayText).apply { setPadding(0, dp(12), 0, 0) })
        }
        points.forEachIndexed { i, p ->
            val typeLabel = getString(
                when (p.type) {
                    StepType.TAP -> R.string.type_tap
                    StepType.LONG -> R.string.type_long
                    StepType.SWIPE -> R.string.type_swipe
                }
            )
            val wait = TimeField(
                this, { timeUnit }, delays.getOrNull(i) ?: -1L,
                Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS, true, { interval }
            ) { v -> store({ ConfigStore.readDelays(prefs) }, { ConfigStore.writeDelays(prefs, it) }, i, v) }
            val holdLabel = if (p.type == StepType.SWIPE) R.string.timeset_swipe else R.string.timeset_hold
            val hold = TimeField(
                this, { timeUnit }, holds.getOrNull(i) ?: -1L,
                Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS, true, { Timing.gestureDurationMs(p.type) }
            ) { v -> store({ ConfigStore.readHolds(prefs) }, { ConfigStore.writeHolds(prefs, it) }, i, v) }
            fields.add(wait)
            fields.add(hold)
            list.addView(tv(getString(R.string.perpoint_row, i + 1, typeLabel), 15f, Color.WHITE, true)
                .apply { setPadding(0, dp(16), 0, dp(6)) })
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(labeled(getString(R.string.timeset_wait), wait),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
                addView(labeled(getString(holdLabel), hold),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
            })
        }

        val done = Button(this).apply {
            text = getString(R.string.timeset_done)
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = rounded(accent, 14)
            stateListAnimator = null
            setOnClickListener { finish() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(tv(getString(R.string.timeset_title), 20f, Color.WHITE, true))
            addView(tv(getString(R.string.timeset_sub), 13f, grayText).apply { setPadding(0, dp(4), 0, 0) })
            addView(tv(getString(R.string.unit_title), 12f, grayText).apply { setPadding(0, dp(14), 0, dp(6)) })
            addView(UnitSlider(this@TimeSettingsActivity).apply {
                select(timeUnit, animate = false)
                onChange = { u ->
                    timeUnit = u
                    ConfigStore.writeTimeUnit(prefs, u)
                    fields.forEach { it.refresh() }
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            addView(ScrollView(this@TimeSettingsActivity).apply { addView(list) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(done, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(16) })
        }
        setContentView(root)

        window.setBackgroundDrawable(rounded(cardColor, 24))
        window.setLayout(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            minOf((resources.displayMetrics.heightPixels * 0.85f).toInt(), dp(270 + 100 * points.size.coerceAtLeast(1)))
        )
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
}
