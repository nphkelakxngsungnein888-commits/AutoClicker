package com.example.autoclicker

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

// กล่องตั้งค่าเวลา: ค่า "ทำงาน" และ "กดค้าง" แยกสำหรับปุ่มธรรมดา; โหมดตาใช้ความเร็วอ่านภาพของตัวเอง
// ใช้ Activity (ไม่ใช่หน้าต่างลอยของบริการ) เพราะต้องพิมพ์ตัวเลขด้วยแป้นพิมพ์
// ลากแถบหัวเพื่อย้ายหน้าต่าง, ลากมุมขวาล่างเพื่อปรับขนาด (จำขนาด/ตำแหน่งไว้ครั้งหน้า)
class TimeSettingsActivity : Activity() {

    companion object {
        // ให้ ClickService รู้ว่าหน้าตั้งค่าเปิดอยู่ไหม: ถ้าเปิดอยู่ การแตะปุ่มบนจอ = เลือกปุ่มเพื่อดูค่า (อยู่ใน process เดียวกัน)
        @Volatile
        var isOpen: Boolean = false
            private set
    }

    private val cardColor = Color.parseColor("#1C1C1E")
    private val itemColor = Color.parseColor("#262629")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val strokeColor = Color.parseColor("#3A3A3C")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private lateinit var prefs: SharedPreferences
    private lateinit var timeUnit: TimeUnitOpt
    private val fields = mutableListOf<TimeField>()

    private lateinit var listBox: LinearLayout

    // เปลี่ยนปุ่มที่เลือก หรือตำแหน่งปุ่มเปลี่ยน → วาดการ์ดค่าใหม่ (ไม่ฟังคีย์เวลา เพื่อไม่ให้ช่องที่กำลังพิมพ์ถูกสร้างใหม่)
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == ConfigStore.KEY_SELECTED || key == ConfigStore.KEY_POINTS) populate()
    }

    // ขนาดหน้าต่าง (px) และระยะเยื้องจากกึ่งกลางจอ (gravity = CENTER จึงไม่ต้องรู้ขนาดแถบสถานะ)
    private var winW = 0
    private var winH = 0
    private var offX = 0
    private var offY = 0

    // แถวสองช่อง (รอ + กด) ต่อจุด: หน้าต่างแคบจะเรียงเป็นแนวตั้งแทน
    private class PointRow(val box: LinearLayout, val first: View, val second: View)
    private val rows = mutableListOf<PointRow>()
    private var stacked = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun labeled(caption: String, field: TimeField) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv(caption, 10f, grayText))
        addView(field.view, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(1) })
    }

    // เขียนค่าลงรายการตามลำดับจุด (เติม -1 ให้ครบก่อน; -1 = ใช้ค่าเริ่มต้น)
    private fun store(read: () -> List<Long>, write: (List<Long>) -> Unit, index: Int, value: Long) {
        val list = read().toMutableList()
        while (list.size <= index) list.add(-1L)
        list[index] = value
        write(list)
    }

    // ---------- ย้าย/ปรับขนาดหน้าต่าง ----------

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun minW() = minOf(dp(200), maxW())
    private fun minH() = minOf(dp(220), maxH())   // ต่ำกว่านี้รายการจุดจะเหลือที่แสดงน้อยเกินไป
    private fun maxW() = (screenW() * 0.98f).toInt()
    private fun maxH() = (screenH() * 0.92f).toInt()

    private fun cellParams(stack: Boolean, isFirst: Boolean) =
        if (stack) {
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { if (isFirst) bottomMargin = dp(4) }
        } else {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { if (isFirst) marginEnd = dp(4) else marginStart = dp(4) }
        }

    private fun updateRows(stack: Boolean) {
        if (stack == stacked) return
        stacked = stack
        rows.forEach { r ->
            r.box.orientation = if (stack) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            r.first.layoutParams = cellParams(stack, true)
            r.second.layoutParams = cellParams(stack, false)
        }
    }

    // ใช้ขนาด/ตำแหน่งปัจจุบันกับหน้าต่าง โดยบีบให้อยู่ในจอเสมอ
    private fun applyGeometry(persist: Boolean = false) {
        winW = winW.coerceIn(minW(), maxW())
        winH = winH.coerceIn(minH(), maxH())
        val limX = ((screenW() - winW) / 2).coerceAtLeast(0)
        // เผื่อ dp(24) กันหน้าต่างล้ำใต้แถบสถานะ/แถบนำทาง (ไม่ทราบขนาดแถบจริง จึงเผื่อไว้)
        val limY = ((screenH() - winH) / 2 - dp(24)).coerceAtLeast(0)
        offX = offX.coerceIn(-limX, limX)
        offY = offY.coerceIn(-limY, limY)
        val lp = window.attributes
        lp.gravity = Gravity.CENTER
        lp.width = winW
        lp.height = winH
        lp.x = offX
        lp.y = offY
        window.attributes = lp
        updateRows(winW < dp(260))
        if (persist) ConfigStore.writeTimeWindow(prefs, winW, winH, offX, offY)
    }

    // ลากแถบหัว = ย้ายหน้าต่าง (ใช้พิกัดบนจอ rawX/rawY เพราะหน้าต่างเลื่อนตามนิ้ว)
    private fun moveListener() = object : View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = offX; startY = offY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    offX = startX + (e.rawX - downX).roundToInt()
                    offY = startY + (e.rawY - downY).roundToInt()
                    applyGeometry()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    v.performClick()
                    applyGeometry(persist = true)
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    applyGeometry(persist = true)
                    return true
                }
            }
            return false
        }
    }

    // ลากมุมขวาล่าง = ปรับขนาด โดยตรึงมุมซ้ายบนไว้กับที่ (ชดเชยระยะเยื้องครึ่งหนึ่งของส่วนที่ขยาย)
    private fun resizeListener() = object : View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var startW = 0
        var startH = 0
        var startX = 0
        var startY = 0

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startW = winW; startH = winH; startX = offX; startY = offY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val left = screenW() / 2f + startX - startW / 2f
                    val top = screenH() / 2f + startY - startH / 2f
                    val newW = (startW + (e.rawX - downX)).roundToInt()
                        .coerceIn(minW(), maxOf(minW(), minOf(maxW(), (screenW() - left).toInt())))
                    val newH = (startH + (e.rawY - downY)).roundToInt()
                        .coerceIn(minH(), maxOf(minH(), minOf(maxH(), (screenH() - top).toInt())))
                    winW = newW
                    winH = newH
                    offX = startX + ((newW - startW) / 2f).roundToInt()
                    offY = startY + ((newH - startH) / 2f).roundToInt()
                    applyGeometry()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    v.performClick()
                    applyGeometry(persist = true)
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    applyGeometry(persist = true)
                    return true
                }
            }
            return false
        }
    }

    // แสดงค่าของ "ปุ่มที่ถูกเลือก" ปุ่มเดียว: แตะปุ่มบนจอ หรือแตะเลขด้านบน เพื่อเปลี่ยนปุ่มที่ดู
    private fun populate() {
        fields.clear()
        rows.clear()
        stacked = false
        listBox.removeAllViews()

        val settings = ConfigStore.readSettings(prefs)
        val scanSpeed = TimeField(
            this, { timeUnit }, settings.eyeScanIntervalMs,
            Limits.MIN_EYE_SCAN_MS, Limits.MAX_EYE_SCAN_MS, false, { 500L }
        ) { value -> ConfigStore.writeEyeScanInterval(prefs, value) }
        scanSpeed.compact()
        fields.add(scanSpeed)
        listBox.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(itemColor, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(labeled(getString(R.string.eye_scan_speed), scanSpeed))
            addView(tv(getString(R.string.eye_scan_speed_hint), 10f, grayText).apply {
                setPadding(0, dp(4), 0, 0)
            })
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(8) })

        val points = ConfigStore.readPoints(prefs)
        if (points.isEmpty()) {
            listBox.addView(tv(getString(R.string.perpoint_empty), 12f, grayText).apply { setPadding(0, dp(8), 0, 0) })
            return
        }
        val delays = ConfigStore.readDelays(prefs)
        val holds = ConfigStore.readHolds(prefs)
        val interval = settings.intervalMs
        val i = ConfigStore.readSelected(prefs).coerceIn(0, points.lastIndex)
        val p = points[i]

        // แถวเลขปุ่ม (เลือกปุ่มจากในหน้าต่างนี้ได้ กรณีปุ่มบนจอถูกบัง)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        points.forEachIndexed { idx, _ ->
            val on = idx == i
            chips.addView(
                tv("${idx + 1}", 11f, if (on) Color.WHITE else grayText, true).apply {
                    gravity = Gravity.CENTER
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (on) accent else fieldColor)
                    }
                    setOnClickListener { ConfigStore.writeSelected(prefs, idx) }
                },
                LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(6) }
            )
        }
        listBox.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(chips)
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        listBox.addView(tv(getString(R.string.timeset_pick_hint), 10f, grayText).apply { setPadding(0, dp(6), 0, 0) })

        if (p.type == StepType.EYE) {
            listBox.addView(
                LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(itemColor, 12)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    addView(tv(getString(R.string.timeset_eye_note), 12f, grayText))
                },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(8) }
            )
            return
        }

        val typeLabel = getString(
            when (p.type) {
                StepType.TAP -> R.string.type_tap
                StepType.LONG -> R.string.type_long
                StepType.EYE -> R.string.type_eye
            }
        )
        val typeColor = when (p.type) {
            StepType.TAP -> accent
            StepType.LONG -> Color.parseColor("#FF9F0A")
            StepType.EYE -> Color.parseColor("#BF5AF2")
        }

        val hold = TimeField(
            this, { timeUnit }, holds.getOrNull(i) ?: -1L,
            Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS, true, { Timing.gestureDurationMs(p.type) }
        ) { v ->
            store({ ConfigStore.readHolds(prefs) }, { ConfigStore.writeHolds(prefs, it) }, i, v)
        }
        val wait = TimeField(
            this, { timeUnit }, delays.getOrNull(i) ?: -1L,
            Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS, true, { interval }
        ) { v -> store({ ConfigStore.readDelays(prefs) }, { ConfigStore.writeDelays(prefs, it) }, i, v) }
        hold.compact()
        wait.compact()
        fields.add(hold)
        fields.add(wait)

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(View(this@TimeSettingsActivity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(typeColor)
                }
            }, LinearLayout.LayoutParams(dp(8), dp(8)))
            addView(tv(getString(R.string.perpoint_row, i + 1, typeLabel), 12f, Color.WHITE, true),
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(6) })
        }
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val match = LinearLayout.LayoutParams.MATCH_PARENT
        listBox.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(itemColor, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(titleRow, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(6) })
            addView(
                labeled(getString(R.string.timeset_hold), hold),
                LinearLayout.LayoutParams(match, wrap)
            )
            addView(
                labeled(getString(R.string.timeset_wait), wait),
                LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) }
            )
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
    }

    override fun onDestroy() {
        isOpen = false
        prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isOpen = true
        // ต้องแตะปุ่มลอยบนจอได้โดยหน้าต่างนี้ไม่ปิดตัวเอง
        setFinishOnTouchOutside(false)
        prefs = ConfigStore.prefs(this)
        timeUnit = ConfigStore.readTimeUnit(prefs)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        populate()
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        val done = Button(this).apply {
            text = getString(R.string.timeset_done)
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = rounded(accent, 12)
            stateListAnimator = null
            setOnClickListener { finish() }
        }

        // แถบหัว: จับลากเพื่อย้ายหน้าต่าง (ขีดสั้นด้านบนบอกว่าลากได้) + ปุ่มปิด
        val close = tv("×", 18f, grayText).apply {
            gravity = Gravity.CENTER
            background = rounded(fieldColor, 12)
            contentDescription = getString(R.string.timeset_close)
            setOnClickListener { finish() }
        }
        val titleBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(getString(R.string.timeset_title), 15f, Color.WHITE, true))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(10), dp(4))
            contentDescription = getString(R.string.timeset_move)
            addView(View(this@TimeSettingsActivity).apply { background = rounded(Color.parseColor("#48484A"), 2) },
                LinearLayout.LayoutParams(dp(32), dp(3)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(6)
                })
            addView(LinearLayout(this@TimeSettingsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(titleBlock, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                addView(close, LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(6) })
            })
            setOnTouchListener(moveListener())
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(2), dp(12), 0)
            addView(tv(getString(R.string.unit_title), 10f, grayText).apply { setPadding(0, dp(2), 0, dp(4)) })
            addView(UnitSlider(this@TimeSettingsActivity).apply {
                compact = true
                select(timeUnit, animate = false)
                onChange = { u ->
                    timeUnit = u
                    ConfigStore.writeTimeUnit(prefs, u)
                    fields.forEach { it.refresh() }
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            addView(ScrollView(this@TimeSettingsActivity).apply { addView(listBox) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        // แถวล่าง: ปุ่มเสร็จสิ้น + มุมจับปรับขนาด
        val grip = ResizeGrip(this).apply {
            contentDescription = getString(R.string.timeset_resize)
            setOnTouchListener(resizeListener())
        }
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(6), dp(6))
            addView(done, LinearLayout.LayoutParams(0, dp(36), 1f))
            addView(grip, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(4) })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(header, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(footer, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        setContentView(root)

        window.setBackgroundDrawable(rounded(cardColor, 24).apply { setStroke(dp(1), strokeColor) })
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        // ไม่หรี่แสงพื้นหลังด้านหลังหน้าต่าง (ล้างแฟล็กหลัง setContentView เพราะธีมตั้งแฟล็กนี้ตอนสร้างหน้าต่าง)
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)

        // ขนาด/ตำแหน่งเริ่มต้น (ครั้งแรก) หรือค่าที่จำไว้ — applyGeometry จะบีบให้พอดีจอปัจจุบันเสมอ
        val saved = ConfigStore.readTimeWindow(prefs)
        winW = saved?.get(0) ?: (screenW() * 0.85f).toInt()
        winH = saved?.get(1) ?: minOf((screenH() * 0.85f).toInt(), dp(360))
        offX = saved?.get(2) ?: 0
        offY = saved?.get(3) ?: 0
        applyGeometry()
    }
}

// มุมจับปรับขนาด: ขีดเฉียง 3 เส้นชี้ไปมุมขวาล่าง
private class ResizeGrip(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8E8E93")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * d
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width - 12f * d
        val cy = height - 12f * d
        for (i in 1..3) {
            val o = i * 5f * d
            canvas.drawLine(cx - o, cy, cx, cy - o, paint)
        }
    }

    override fun performClick(): Boolean = super.performClick()
}
