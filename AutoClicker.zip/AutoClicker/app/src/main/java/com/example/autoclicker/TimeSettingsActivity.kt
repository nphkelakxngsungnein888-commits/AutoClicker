package com.example.autoclicker

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// กล่องตั้งค่าเวลารายจุด: "รอก่อนจุดถัดไป" และ "เวลากด/ปัด" — เปิดจากปุ่ม ⚙ บนแผงลอย หรือจากหน้าแอป
// ใช้ Activity (ไม่ใช่หน้าต่างลอยของบริการ) เพราะต้องพิมพ์ตัวเลขด้วยแป้นพิมพ์
class TimeSettingsActivity : Activity() {

    private val cardColor = Color.parseColor("#1C1C1E")
    private val fieldColor = Color.parseColor("#2C2C2E")
    private val accent = Color.parseColor("#FF3B30")
    private val grayText = Color.parseColor("#9A9AA0")

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun tv(content: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = content
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    // ช่องตัวเลข: เว้นว่าง = ใช้ค่าเริ่มต้น (-1) บันทึกอัตโนมัติทุกครั้งที่พิมพ์
    private fun numberField(initial: Long, hint: String, onValue: (Long) -> Unit) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        this.hint = hint
        setHintTextColor(grayText)
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        background = rounded(fieldColor, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setText(if (initial >= 0L) initial.toString() else "")
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onValue(s?.toString()?.toLongOrNull() ?: -1L)
            }
        })
    }

    private fun labeled(caption: String, field: EditText) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv(caption, 12f, grayText))
        addView(field, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })
    }

    // เขียนค่าลงรายการตามลำดับจุด (เติม -1 ให้ครบก่อน)
    private fun store(read: () -> List<Long>, write: (List<Long>) -> Unit, index: Int, value: Long, min: Long, max: Long) {
        val list = read().toMutableList()
        while (list.size <= index) list.add(-1L)
        list[index] = if (value < 0L) -1L else value.coerceIn(min, max)
        write(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = ConfigStore.prefs(this)

        val points = ConfigStore.readPoints(prefs)
        val delays = ConfigStore.readDelays(prefs)
        val holds = ConfigStore.readHolds(prefs)
        val interval = ConfigStore.readSettings(prefs).intervalMs

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (points.isEmpty()) {
            list.addView(tv(getString(R.string.perpoint_empty), 14f, grayText).apply { setPadding(0, dp(12), 0, 0) })
        }
        points.forEachIndexed { i, p ->
            val typeLabel = getString(
                when (p.type) {
                    StepType.TAP -> R.string.type_tap
                    StepType.LONG -> R.string.type_long
                    StepType.SWIPE -> R.string.type_swipe
                }
            )
            val wait = numberField(delays.getOrNull(i) ?: -1L, interval.toString()) { v ->
                store({ ConfigStore.readDelays(prefs) }, { ConfigStore.writeDelays(prefs, it) },
                    i, v, Limits.MIN_INTERVAL_MS, Limits.MAX_INTERVAL_MS)
            }
            val holdLabel = if (p.type == StepType.SWIPE) R.string.timeset_swipe else R.string.timeset_hold
            val hold = numberField(holds.getOrNull(i) ?: -1L, Timing.gestureDurationMs(p.type).toString()) { v ->
                store({ ConfigStore.readHolds(prefs) }, { ConfigStore.writeHolds(prefs, it) },
                    i, v, Limits.MIN_HOLD_MS, Limits.MAX_HOLD_MS)
            }
            list.addView(tv(getString(R.string.perpoint_row, i + 1, typeLabel), 15f, Color.WHITE, true)
                .apply { setPadding(0, dp(16), 0, dp(6)) })
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(labeled(getString(R.string.timeset_wait), wait),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
                addView(labeled(getString(holdLabel), hold),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
            })
        }

        val done = Button(this).apply {
            text = getString(R.string.timeset_done)
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = rounded(accent, 14)
            stateListAnimator = null
            setOnClickListener { finish() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(tv(getString(R.string.timeset_title), 20f, Color.WHITE, true))
            addView(tv(getString(R.string.timeset_sub), 13f, grayText).apply { setPadding(0, dp(4), 0, 0) })
            addView(ScrollView(this@TimeSettingsActivity).apply { addView(list) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(done, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(16) })
        }
        setContentView(root)

        window.setBackgroundDrawable(rounded(cardColor, 24))
        window.setLayout(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            minOf((resources.displayMetrics.heightPixels * 0.8f).toInt(), dp(210 + 100 * points.size.coerceAtLeast(1)))
        )
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
}
