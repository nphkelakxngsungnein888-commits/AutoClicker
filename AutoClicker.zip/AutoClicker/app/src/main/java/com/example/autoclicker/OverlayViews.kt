package com.example.autoclicker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

val OVERLAY_RED: Int = Color.parseColor("#FF3B30")
val OVERLAY_GREEN: Int = Color.parseColor("#34C759")
val OVERLAY_BLUE: Int = Color.parseColor("#0A84FF")
private val OVERLAY_GRAY: Int = Color.parseColor("#3A3A3C")

// จุดคลิกวงกลมสีแดง/เขียว พร้อมป้ายเลขลำดับ — ใช้ทั้งบนหน้าจอจริง (ClickService) และในตัวอย่างหน้าตั้งค่า
class MarkerView(context: Context) : FrameLayout(context) {
    private val density = resources.displayMetrics.density
    private val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dot = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dotView = View(context)
    private val labelView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
        gravity = Gravity.CENTER
        includeFontPadding = false
    }
    private var color = OVERLAY_RED
    var scale = 100
        private set

    init {
        background = ring
        dotView.background = dot
        addView(dotView, LayoutParams(1, 1, Gravity.CENTER))
        addView(labelView, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setScale(100)
    }

    fun sizePx(pct: Int): Int = (56 * density * pct / 100f).toInt().coerceAtLeast(8)

    fun setScale(pct: Int) {
        scale = pct
        val d = (10 * density * pct / 100f).toInt().coerceAtLeast(2)
        dotView.layoutParams = LayoutParams(d, d, Gravity.CENTER)
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, (11f * pct / 100f).coerceAtLeast(6f))
        applyColor()
    }

    fun setColor(c: Int) {
        color = c
        applyColor()
    }

    fun setLabel(text: String) {
        labelView.text = text
    }

    private fun applyColor() {
        ring.setColor((color and 0x00FFFFFF) or (40 shl 24))
        ring.setStroke((3 * density * scale / 100f).toInt().coerceAtLeast(1), color)
        dot.setColor(color)
    }
}

// ส่วนของแผงที่ถูกแตะ
enum class PanelAction { TOGGLE, ADD, REMOVE, SETTINGS, HIDE }

// แผงปุ่ม ▶ / ＋ / － / ⚙ / ✕ — ใช้ทั้งบนหน้าจอจริงและในตัวอย่างหน้าตั้งค่า
class PanelView(context: Context) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val bg = GradientDrawable().apply {
        setColor(Color.argb(225, 28, 28, 30))
        setStroke(density.toInt().coerceAtLeast(1), Color.argb(70, 255, 255, 255))
    }
    val toggle: TextView = circleText("▶", OVERLAY_GREEN)
    val add: TextView = circleText("+", OVERLAY_GRAY)
    val remove: TextView = circleText("−", OVERLAY_GRAY)
    val settings: TextView = circleText("\u2699\uFE0E", OVERLAY_GRAY)   // ⚙ ตั้งค่าเวลา
    val close: TextView = circleText("✕", OVERLAY_GRAY)
    var scale = 100
        private set

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        addView(toggle)
        addView(add)
        addView(remove)
        addView(settings)
        addView(close)
        setScale(100)
    }

    private fun circleText(label: String, color: Int) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    // แปลงพิกัด x (ในแผง) เป็นปุ่มที่ถูกแตะ — ใช้ตำแหน่งซ้ายของแต่ละปุ่มหลังจัดวางแล้ว
    fun actionAt(x: Float): PanelAction = when {
        x >= close.left -> PanelAction.HIDE
        x >= settings.left -> PanelAction.SETTINGS
        x >= remove.left -> PanelAction.REMOVE
        x >= add.left -> PanelAction.ADD
        else -> PanelAction.TOGGLE
    }

    fun setScale(pct: Int) {
        scale = pct
        fun px(v: Float) = (v * density * pct / 100f).toInt().coerceAtLeast(1)
        setPadding(px(6f), px(6f), px(6f), px(6f))
        bg.cornerRadius = px(32f).toFloat()
        toggle.layoutParams = LinearLayout.LayoutParams(px(48f), px(48f))
        toggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f * pct / 100f)
        for (v in listOf(add, remove, settings, close)) {
            v.layoutParams = LinearLayout.LayoutParams(px(40f), px(40f)).apply { marginStart = px(8f) }
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * pct / 100f)
        }
    }

    fun setRunning(running: Boolean) {
        toggle.text = if (running) "■" else "▶"
        (toggle.background as GradientDrawable).setColor(if (running) OVERLAY_RED else OVERLAY_GREEN)
        // ระหว่างคลิกยังเพิ่ม/ลดจุดไม่ได้ ทำให้จางเพื่อบอกผู้ใช้
        add.alpha = if (running) 0.35f else 1f
        remove.alpha = if (running) 0.35f else 1f
        settings.alpha = if (running) 0.35f else 1f
    }
}
