package com.example.autoclicker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

val OVERLAY_RED: Int = Color.parseColor("#FF3B30")
val OVERLAY_GREEN: Int = Color.parseColor("#34C759")

// จุดคลิกวงกลมสีแดง/เขียว — ใช้ทั้งบนหน้าจอจริง (ClickService) และในตัวอย่างหน้าตั้งค่า
class MarkerView(context: Context) : FrameLayout(context) {
    private val density = resources.displayMetrics.density
    private val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dot = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dotView = View(context)
    private var color = OVERLAY_RED
    var scale = 100
        private set

    init {
        background = ring
        dotView.background = dot
        addView(dotView, LayoutParams(1, 1, Gravity.CENTER))
        setScale(100)
    }

    fun sizePx(pct: Int): Int = (56 * density * pct / 100f).toInt().coerceAtLeast(8)

    fun setScale(pct: Int) {
        scale = pct
        val d = (10 * density * pct / 100f).toInt().coerceAtLeast(2)
        dotView.layoutParams = LayoutParams(d, d, Gravity.CENTER)
        applyColor()
    }

    fun setColor(c: Int) {
        color = c
        applyColor()
    }

    private fun applyColor() {
        ring.setColor((color and 0x00FFFFFF) or (40 shl 24))
        ring.setStroke((3 * density * scale / 100f).toInt().coerceAtLeast(1), color)
        dot.setColor(color)
    }
}

// แผงปุ่ม ▶ / ✕ — ใช้ทั้งบนหน้าจอจริงและในตัวอย่างหน้าตั้งค่า
class PanelView(context: Context) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val bg = GradientDrawable().apply {
        setColor(Color.argb(225, 28, 28, 30))
        setStroke(density.toInt().coerceAtLeast(1), Color.argb(70, 255, 255, 255))
    }
    val toggle: TextView = circleText("▶", OVERLAY_GREEN)
    val close: TextView = circleText("✕", Color.parseColor("#3A3A3C"))
    var scale = 100
        private set

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        addView(toggle)
        addView(close)
        setScale(100)
    }

    private fun circleText(label: String, color: Int) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    fun setScale(pct: Int) {
        scale = pct
        fun px(v: Float) = (v * density * pct / 100f).toInt().coerceAtLeast(1)
        setPadding(px(6f), px(6f), px(6f), px(6f))
        bg.cornerRadius = px(32f).toFloat()
        toggle.layoutParams = LinearLayout.LayoutParams(px(48f), px(48f))
        toggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f * pct / 100f)
        close.layoutParams = LinearLayout.LayoutParams(px(40f), px(40f)).apply { marginStart = px(8f) }
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * pct / 100f)
    }

    fun setRunning(running: Boolean) {
        toggle.text = if (running) "■" else "▶"
        (toggle.background as GradientDrawable).setColor(if (running) OVERLAY_RED else OVERLAY_GREEN)
    }
}
