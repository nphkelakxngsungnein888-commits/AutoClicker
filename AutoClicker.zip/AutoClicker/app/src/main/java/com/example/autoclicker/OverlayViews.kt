package com.example.autoclicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

val OVERLAY_RED: Int = Color.parseColor("#FF3B30")
val OVERLAY_GREEN: Int = Color.parseColor("#34C759")
val OVERLAY_BLUE: Int = Color.parseColor("#0A84FF")
val OVERLAY_SKIP: Int = Color.parseColor("#8E8E93")     // ปุ่มที่ไม่ได้อยู่ใน "เล่นเฉพาะ" ขณะรัน (ไม่แตะ)
val OVERLAY_ORANGE: Int = Color.parseColor("#FF9500")   // ท่าทางล่าสุดถูกยกเลิก (มักเพราะผู้ใช้แตะจอจริงชน)
private val OVERLAY_GRAY: Int = Color.parseColor("#3A3A3C")

// จุดคลิกวงกลมสีแดง/เขียว พร้อมป้ายเลขลำดับ — ใช้ทั้งบนหน้าจอจริง (ClickService) และในตัวอย่างหน้าตั้งค่า
class MarkerView(context: Context) : FrameLayout(context) {
    private val density = resources.displayMetrics.density
    private val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dot = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dotView = View(context)
    private val labelView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
        gravity = Gravity.CENTER
        includeFontPadding = false
    }
    private var color = OVERLAY_RED
    private var rect = false   // true = กล่องสี่เหลี่ยมใส (ตา) แทนวงกลม
    var scale = 100
        private set

    init {
        background = ring
        dotView.background = dot
        addView(dotView, LayoutParams(1, 1, Gravity.CENTER))
        addView(labelView, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setScale(100)
    }

    fun sizePx(pct: Int): Int = (56 * density * pct / 100f).toInt().coerceAtLeast(8)

    fun setScale(pct: Int) {
        scale = pct
        val d = (10 * density * pct / 100f).toInt().coerceAtLeast(2)
        dotView.layoutParams = LayoutParams(d, d, Gravity.CENTER)
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, (11f * pct / 100f).coerceAtLeast(6f))
        applyColor()
    }

    fun setColor(c: Int) {
        color = c
        applyColor()
    }

    fun setLabel(text: String) {
        labelView.text = text
    }

    // กล่องของ "ตา": สี่เหลี่ยมใส ขอบสี มีจุดกลาง
    fun setRect(on: Boolean) {
        rect = on
        ring.shape = if (on) GradientDrawable.RECTANGLE else GradientDrawable.OVAL
        ring.cornerRadius = if (on) 4 * density else 0f
        applyColor()
    }

    // ซ่อนจุดกลางตอนจับภาพ ไม่ให้ติดไปกับภาพที่ตาเห็น
    fun setDotVisible(visible: Boolean) {
        dotView.visibility = if (visible) VISIBLE else INVISIBLE
    }

    // โหมดจับภาพของกล่องตา: ซ่อนทั้งจุดกลางและป้ายเลข (เช่น "2E") ไม่ให้ติดไปกับภาพที่ตาเห็น
    // กรอบสียังอยู่ แต่ภาพที่ตัดมาเว้นขอบกล่อง 5dp จึงไม่รวมกรอบ — ภาพตอนล็อกกับตอนรันจึงเหมือนกันเป๊ะ
    fun setCaptureMode(on: Boolean) {
        val v = if (on) INVISIBLE else VISIBLE
        dotView.visibility = v
        labelView.visibility = v
    }

    private fun applyColor() {
        ring.setColor((color and 0x00FFFFFF) or ((if (rect) 0 else 40) shl 24))
        ring.setStroke((3 * density * scale / 100f).toInt().coerceAtLeast(1), color)
        dot.setColor(color)
    }
}

// ส่วนของแผงที่ถูกแตะ
enum class PanelAction { TOGGLE, FOLD, ADD, REMOVE, EYE, DRAG, SAVE, LOAD, SETTINGS, DEFAULTS, TOGGLE_POINTS, HIDE }

// แผงเครื่องมือ — ใช้ทั้งบนหน้าจอจริงและในตัวอย่างหน้าตั้งค่า
// ทุกปุ่มเป็นไอคอนที่วาดเอง; พับแผงแล้วเหลือแค่ปุ่มเริ่ม/หยุด + ปุ่มกางออก
class PanelView(context: Context) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val bg = GradientDrawable().apply {
        setColor(Color.argb(225, 28, 28, 30))
        setStroke(density.toInt().coerceAtLeast(1), Color.argb(70, 255, 255, 255))
    }
    val toggle = PanelIcon(context, PanelIconKind.PLAY).apply { setBgColor(OVERLAY_GREEN) }
    val fold = PanelIcon(context, PanelIconKind.CHEVRON_LEFT).apply { contentDescription = context.getString(R.string.panel_fold) }
    val add = PanelIcon(context, PanelIconKind.PLUS)
    val remove = PanelIcon(context, PanelIconKind.MINUS)
    val eye: View = PanelIcon(context, PanelIconKind.EYE).apply { contentDescription = context.getString(R.string.panel_eye) }
    val drag: View = PanelIcon(context, PanelIconKind.DRAG).apply { contentDescription = context.getString(R.string.panel_drag) }
    val save: View = PanelIcon(context, PanelIconKind.SAVE).apply { contentDescription = context.getString(R.string.panel_save) }
    val load: View = PanelIcon(context, PanelIconKind.LOAD).apply { contentDescription = context.getString(R.string.panel_load) }
    val settings = PanelIcon(context, PanelIconKind.GEAR)   // ⚙ ตั้งค่าเวลารายปุ่ม
    val defaults = PanelIcon(context, PanelIconKind.SLIDERS).apply { contentDescription = context.getString(R.string.panel_defaults) }
    val hidePoints = PanelIcon(context, PanelIconKind.POINTS_ON).apply {
        setBgColor(OVERLAY_BLUE)
        contentDescription = context.getString(R.string.panel_hide_points)
    }
    val close = PanelIcon(context, PanelIconKind.CLOSE)
    var scale = 100
        private set
    var collapsed = false
        private set

    // เรียงซ้าย→ขวา ตรงกับลำดับที่ addView; ใช้แปลงพิกัดแตะเป็นปุ่ม
    private val order: List<Pair<View, PanelAction>> = listOf(
        toggle to PanelAction.TOGGLE, fold to PanelAction.FOLD, add to PanelAction.ADD, remove to PanelAction.REMOVE,
        eye to PanelAction.EYE, drag to PanelAction.DRAG, save to PanelAction.SAVE, load to PanelAction.LOAD,
        settings to PanelAction.SETTINGS, defaults to PanelAction.DEFAULTS,
        hidePoints to PanelAction.TOGGLE_POINTS, close to PanelAction.HIDE
    )

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        for ((v, _) in order) addView(v)
        setScale(100)
    }

    // แปลงพิกัด x (ในแผง) เป็นปุ่มที่ถูกแตะ — ดูเฉพาะปุ่มที่มองเห็นอยู่ (ตอนพับแผง ปุ่มที่ซ่อนไม่นับ)
    fun actionAt(x: Float): PanelAction {
        for ((v, action) in order.asReversed()) {
            if (v.visibility == View.VISIBLE && x >= v.left) return action
        }
        return PanelAction.TOGGLE
    }

    // พับ = เหลือแค่ปุ่มเริ่ม/หยุดกับปุ่มกางออก
    fun setCollapsed(c: Boolean) {
        collapsed = c
        for ((v, action) in order) {
            if (action != PanelAction.TOGGLE && action != PanelAction.FOLD) {
                v.visibility = if (c) View.GONE else View.VISIBLE
            }
        }
        fold.kind = if (c) PanelIconKind.CHEVRON_RIGHT else PanelIconKind.CHEVRON_LEFT
        fold.contentDescription = context.getString(if (c) R.string.panel_unfold else R.string.panel_fold)
    }

    fun setScale(pct: Int) {
        scale = pct
        fun px(v: Float) = (v * density * pct / 100f).toInt().coerceAtLeast(1)
        setPadding(px(6f), px(6f), px(6f), px(6f))
        bg.cornerRadius = px(32f).toFloat()
        toggle.layoutParams = LinearLayout.LayoutParams(px(40f), px(40f))
        for ((v, action) in order) {
            if (action == PanelAction.TOGGLE) continue
            v.layoutParams = LinearLayout.LayoutParams(px(34f), px(34f)).apply { marginStart = px(2f) }
        }
    }

    fun setPointsHidden(hidden: Boolean) {
        hidePoints.kind = if (hidden) PanelIconKind.POINTS_OFF else PanelIconKind.POINTS_ON
        hidePoints.contentDescription = context.getString(
            if (hidden) R.string.panel_show_points else R.string.panel_hide_points
        )
        hidePoints.setBgColor(if (hidden) OVERLAY_GREEN else OVERLAY_BLUE)
    }

    fun setRunning(running: Boolean) {
        toggle.kind = if (running) PanelIconKind.STOP else PanelIconKind.PLAY
        toggle.setBgColor(if (running) OVERLAY_RED else OVERLAY_GREEN)
        // ระหว่างคลิกยังเพิ่ม/ลดจุดไม่ได้ ทำให้จางเพื่อบอกผู้ใช้
        val a = if (running) 0.35f else 1f
        for (v in listOf(add, remove, eye, drag, save, load, settings, defaults)) v.alpha = a
    }
}

enum class PanelIconKind {
    EYE, DRAG, SAVE, LOAD, PLAY, STOP, PLUS, MINUS, GEAR, SLIDERS, POINTS_ON, POINTS_OFF, CLOSE, CHEVRON_LEFT, CHEVRON_RIGHT
}

// ไอคอนบนแผงที่วาดด้วยเส้น (ไม่ใช้ข้อความ/ฟอนต์) ขนาดตามความกว้างของปุ่ม
class PanelIcon(context: Context, kind0: PanelIconKind) : View(context) {
    var kind: PanelIconKind = kind0
        set(value) {
            field = value
            invalidate()
        }
    private val bg = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(OVERLAY_GRAY)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        background = bg
    }

    fun setBgColor(color: Int) {
        bg.setColor(color)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        paint.strokeWidth = (w / 14f).coerceAtLeast(1.5f)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            canvas.drawLine(w * x1, h * y1, w * x2, h * y2, paint)
        fun dot(cx: Float, cy: Float, r: Float) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(w * cx, h * cy, w * r, paint)
            paint.style = Paint.Style.STROKE
        }
        when (kind) {
            PanelIconKind.EYE -> {
                canvas.drawOval(RectF(w * 0.20f, h * 0.34f, w * 0.80f, h * 0.66f), paint)
                dot(0.50f, 0.50f, 0.08f)
            }
            PanelIconKind.DRAG -> {
                // จุดเริ่มต้น → ลูกศรชี้ไปจุดปลาย (ลากจากจุดหนึ่งไปอีกจุด)
                dot(0.28f, 0.72f, 0.07f)
                line(0.28f, 0.72f, 0.72f, 0.28f)
                line(0.72f, 0.28f, 0.50f, 0.30f)
                line(0.72f, 0.28f, 0.70f, 0.50f)
            }
            PanelIconKind.SAVE -> {
                line(0.50f, 0.22f, 0.50f, 0.56f)
                line(0.50f, 0.60f, 0.36f, 0.46f)
                line(0.50f, 0.60f, 0.64f, 0.46f)
                line(0.26f, 0.66f, 0.26f, 0.76f)
                line(0.26f, 0.76f, 0.74f, 0.76f)
                line(0.74f, 0.76f, 0.74f, 0.66f)
            }
            PanelIconKind.LOAD -> {
                line(0.50f, 0.62f, 0.50f, 0.28f)
                line(0.50f, 0.24f, 0.36f, 0.38f)
                line(0.50f, 0.24f, 0.64f, 0.38f)
                line(0.26f, 0.66f, 0.26f, 0.76f)
                line(0.26f, 0.76f, 0.74f, 0.76f)
                line(0.74f, 0.76f, 0.74f, 0.66f)
            }
            PanelIconKind.PLAY -> {
                val path = android.graphics.Path().apply {
                    moveTo(w * 0.38f, h * 0.27f)
                    lineTo(w * 0.38f, h * 0.73f)
                    lineTo(w * 0.75f, h * 0.50f)
                    close()
                }
                paint.style = Paint.Style.FILL
                canvas.drawPath(path, paint)
                paint.style = Paint.Style.STROKE
            }
            PanelIconKind.STOP -> {
                paint.style = Paint.Style.FILL
                canvas.drawRoundRect(RectF(w * 0.30f, h * 0.30f, w * 0.70f, h * 0.70f), w * 0.06f, w * 0.06f, paint)
                paint.style = Paint.Style.STROKE
            }
            PanelIconKind.PLUS -> {
                line(0.28f, 0.50f, 0.72f, 0.50f)
                line(0.50f, 0.28f, 0.50f, 0.72f)
            }
            PanelIconKind.MINUS -> line(0.28f, 0.50f, 0.72f, 0.50f)
            PanelIconKind.GEAR -> {
                // วงกลมกลาง + ฟันเฟือง 8 ซี่
                canvas.drawCircle(w * 0.50f, h * 0.50f, w * 0.14f, paint)
                for (k in 0 until 8) {
                    val ang = Math.toRadians(k * 45.0)
                    val c = Math.cos(ang).toFloat()
                    val s = Math.sin(ang).toFloat()
                    line(0.50f + c * 0.24f, 0.50f + s * 0.24f, 0.50f + c * 0.34f, 0.50f + s * 0.34f)
                }
            }
            PanelIconKind.SLIDERS -> {
                // แถบเลื่อน 3 เส้น + ปุ่มเลื่อน (ตั้งค่ามาตรฐาน)
                line(0.24f, 0.30f, 0.76f, 0.30f)
                line(0.24f, 0.50f, 0.76f, 0.50f)
                line(0.24f, 0.70f, 0.76f, 0.70f)
                dot(0.40f, 0.30f, 0.07f)
                dot(0.62f, 0.50f, 0.07f)
                dot(0.46f, 0.70f, 0.07f)
            }
            PanelIconKind.POINTS_ON -> {
                canvas.drawCircle(w * 0.50f, h * 0.50f, w * 0.23f, paint)
                dot(0.50f, 0.50f, 0.09f)
            }
            PanelIconKind.POINTS_OFF -> canvas.drawCircle(w * 0.50f, h * 0.50f, w * 0.23f, paint)
            PanelIconKind.CLOSE -> {
                line(0.32f, 0.32f, 0.68f, 0.68f)
                line(0.68f, 0.32f, 0.32f, 0.68f)
            }
            PanelIconKind.CHEVRON_LEFT -> {
                line(0.58f, 0.28f, 0.40f, 0.50f)
                line(0.40f, 0.50f, 0.58f, 0.72f)
            }
            PanelIconKind.CHEVRON_RIGHT -> {
                line(0.42f, 0.28f, 0.60f, 0.50f)
                line(0.60f, 0.50f, 0.42f, 0.72f)
            }
        }
    }
}

// หน้าต่างตั้งค่าของตา (ลอยบนจอ): ภาพที่ตาเห็นแบบสด + ปุ่มล็อก/โหมด/ความเหมือน
class EyePanelView(
    context: Context,
    private val onLock: () -> Unit,
    private val onMode: () -> Unit,
    private val onThreshold: (Int) -> Unit,
    private val onClose: () -> Unit
) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val preview = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        setBackgroundColor(Color.argb(255, 44, 44, 46))
    }
    private val status = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        gravity = Gravity.CENTER
    }
    private val modeBtn = button("", OVERLAY_BLUE) { onMode() }
    private val lockBtn = button(context.getString(R.string.eye_lock), OVERLAY_GREEN) { onLock() }
    private val thrText = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        gravity = Gravity.CENTER
    }

    init {
        orientation = VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.argb(235, 20, 20, 22))
            cornerRadius = 10 * density
            setStroke(density.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        val pad = (8 * density).toInt()
        setPadding(pad, pad, pad, pad)
        addView(preview, LayoutParams((220 * density).toInt(), (110 * density).toInt()))
        addView(status, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad / 2 })
        val row1 = LinearLayout(context).apply { gravity = Gravity.CENTER }
        row1.addView(lockBtn)
        row1.addView(modeBtn)
        addView(row1, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
        val row2 = LinearLayout(context).apply { gravity = Gravity.CENTER }
        row2.addView(button("−", OVERLAY_GRAY) { onThreshold(-5) })
        row2.addView(thrText, LinearLayout.LayoutParams((96 * density).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT))
        row2.addView(button("+", OVERLAY_GRAY) { onThreshold(5) })
        row2.addView(button(context.getString(R.string.eye_close), OVERLAY_GRAY) { onClose() })
        addView(row2, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
    }

    fun setPreview(bmp: Bitmap?) {
        preview.setImageBitmap(bmp)
    }

    fun setStatus(text: String) {
        status.text = text
    }

    fun setModeLabel(text: String) {
        modeBtn.text = text
    }

    fun setThreshold(pct: Int) {
        thrText.text = context.getString(R.string.eye_similarity, pct)
    }

    private fun button(label: String, color: Int, action: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding((12 * density).toInt(), (7 * density).toInt(), (12 * density).toInt(), (7 * density).toInt())
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = 16 * density
        }
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            marginStart = (4 * density).toInt()
            marginEnd = (4 * density).toInt()
        }
    }
}

// เส้นตัวอย่างตอนลากสร้างปุ่มลาก: จุดเริ่ม → เส้น → จุดปลายตามนิ้ว
class DragPreviewView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = OVERLAY_BLUE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3f * density
    }
    private var active = false
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f

    fun begin(x: Float, y: Float) {
        active = true
        sx = x; sy = y; ex = x; ey = y
        invalidate()
    }

    fun moveTo(x: Float, y: Float) {
        ex = x; ey = y
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!active) return
        canvas.drawLine(sx, sy, ex, ey, paint)
        canvas.drawCircle(sx, sy, 8f * density, paint)
        canvas.drawCircle(ex, ey, 8f * density, paint)
    }
}

// เส้นจากจุดเริ่ม (ตัวแม่) ไปจุดปลาย (ตัวลูก) ของปุ่มลากทุกปุ่ม พร้อมหัวลูกศรกลางเส้นบอกทิศทาง
// (หัวลูกศรอยู่กลางเส้นเพราะปลายเส้นถูกป้ายจุดปลายบังอยู่)
class DragLinesView(context: Context) : View(context) {
    class Seg(val sx: Float, val sy: Float, val ex: Float, val ey: Float, val color: Int)

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3f * density
    }
    private var segs: List<Seg> = emptyList()

    fun setSegments(list: List<Seg>) {
        segs = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val size = 14f * density
        val c = 0.883f   // cos 28°
        val s = 0.469f   // sin 28°
        for (g in segs) {
            paint.color = g.color
            canvas.drawLine(g.sx, g.sy, g.ex, g.ey, paint)
            val dx = g.ex - g.sx
            val dy = g.ey - g.sy
            val len = kotlin.math.hypot(dx, dy)
            if (len < size * 2f) continue
            val ux = dx / len
            val uy = dy / len
            // ปลายหัวลูกศรอยู่กึ่งกลางเส้น ปีกสองข้างหมุน ±28° จากทิศย้อนกลับ
            val tx = (g.sx + g.ex) / 2f + ux * size * 0.5f
            val ty = (g.sy + g.ey) / 2f + uy * size * 0.5f
            val vx = -ux
            val vy = -uy
            canvas.drawLine(tx, ty, tx + size * (vx * c - vy * s), ty + size * (vx * s + vy * c), paint)
            canvas.drawLine(tx, ty, tx + size * (vx * c + vy * s), ty + size * (-vx * s + vy * c), paint)
        }
    }
}
