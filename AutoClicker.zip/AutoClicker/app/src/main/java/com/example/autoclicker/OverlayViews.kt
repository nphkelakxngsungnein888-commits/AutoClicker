package com.example.autoclicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

val OVERLAY_RED: Int = Color.parseColor("#FF3B30")
val OVERLAY_GREEN: Int = Color.parseColor("#34C759")
val OVERLAY_BLUE: Int = Color.parseColor("#0A84FF")
private val OVERLAY_GRAY: Int = Color.parseColor("#3A3A3C")

// จุดคลิกวงกลมสีแดง/เขียว พร้อมป้ายเลขลำดับ — ใช้ทั้งบนหน้าจอจริง (ClickService) และในตัวอย่างหน้าตั้งค่า
class MarkerView(context: Context) : FrameLayout(context) {
    private val density = resources.displayMetrics.density
    private val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dot = GradientDrawable().apply { shape = GradientDrawable.OVAL }
    private val dotView = View(context)
    private val labelView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
        gravity = Gravity.CENTER
        includeFontPadding = false
    }
    private var color = OVERLAY_RED
    private var rect = false   // true = กล่องสี่เหลี่ยมใส (ตา) แทนวงกลม
    var scale = 100
        private set

    init {
        background = ring
        dotView.background = dot
        addView(dotView, LayoutParams(1, 1, Gravity.CENTER))
        addView(labelView, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setScale(100)
    }

    fun sizePx(pct: Int): Int = (56 * density * pct / 100f).toInt().coerceAtLeast(8)

    fun setScale(pct: Int) {
        scale = pct
        val d = (10 * density * pct / 100f).toInt().coerceAtLeast(2)
        dotView.layoutParams = LayoutParams(d, d, Gravity.CENTER)
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, (11f * pct / 100f).coerceAtLeast(6f))
        applyColor()
    }

    fun setColor(c: Int) {
        color = c
        applyColor()
    }

    fun setLabel(text: String) {
        labelView.text = text
    }

    // กล่องของ "ตา": สี่เหลี่ยมใส ขอบสี มีจุดกลาง
    fun setRect(on: Boolean) {
        rect = on
        ring.shape = if (on) GradientDrawable.RECTANGLE else GradientDrawable.OVAL
        ring.cornerRadius = if (on) 4 * density else 0f
        applyColor()
    }

    // ซ่อนจุดกลางตอนจับภาพ ไม่ให้ติดไปกับภาพที่ตาเห็น
    fun setDotVisible(visible: Boolean) {
        dotView.visibility = if (visible) VISIBLE else INVISIBLE
    }

    private fun applyColor() {
        ring.setColor((color and 0x00FFFFFF) or ((if (rect) 0 else 40) shl 24))
        ring.setStroke((3 * density * scale / 100f).toInt().coerceAtLeast(1), color)
        dot.setColor(color)
    }
}

// ลูกศรจากปุ่มแม่ (จุดเริ่มปัด) ไปปุ่มลูก (จุดปลาย) ตามทิศที่ลาก — วาดบนหน้าต่างเต็มจอที่แตะทะลุได้
// พิกัดทั้งหมดเป็นพิกัดเดียวกับ WindowManager.LayoutParams ของป้าย (จุดกึ่งกลาง) และ r = รัศมีป้าย
class ArrowView(context: Context) : View(context) {
    class Arrow(val id: Int, val x1: Float, val y1: Float, val x2: Float, val y2: Float, val r1: Float, val r2: Float)

    private val density = resources.displayMetrics.density
    private var arrows: List<Arrow> = emptyList()
    private var unit = 1f
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = OVERLAY_BLUE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = OVERLAY_BLUE
        style = Paint.Style.FILL
    }
    private val headShade = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    // id ของลูกศร → [เวลาเริ่ม, ระยะเวลา] ของจุดสว่างที่วิ่งจากปุ่มแม่ไปปุ่มลูก
    private val pulses = HashMap<Int, LongArray>()

    fun pulse(id: Int, durationMs: Long) {
        pulses[id] = longArrayOf(SystemClock.uptimeMillis(), durationMs.coerceAtLeast(150L))
        invalidate()
    }

    fun setArrows(list: List<Arrow>, scalePct: Int) {
        arrows = list
        unit = scalePct / 100f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = (4f * density * unit).coerceAtLeast(2f)
        line.strokeWidth = w
        shade.strokeWidth = w + 2f * density
        headShade.strokeWidth = 2f * density
        val now = SystemClock.uptimeMillis()
        for (a in arrows) {
            val dx = a.x2 - a.x1
            val dy = a.y2 - a.y1
            val d = kotlin.math.hypot(dx, dy)
            val len = d - a.r1 - a.r2
            if (d <= 0f || len <= 2f) continue   // ปุ่มทับกัน/ชิดกันเกินไป ไม่มีที่ให้วาดลูกศร
            val ux = dx / d
            val uy = dy / d
            val sx = a.x1 + ux * a.r1
            val sy = a.y1 + uy * a.r1
            val ex = a.x2 - ux * a.r2
            val ey = a.y2 - uy * a.r2
            val hl = minOf((16f * density * unit).coerceAtLeast(8f), len * 0.8f)
            val hw = hl * 0.55f
            val bx = ex - ux * hl
            val by = ey - uy * hl
            canvas.drawLine(sx, sy, bx, by, shade)
            canvas.drawLine(sx, sy, bx, by, line)
            path.reset()
            path.moveTo(ex, ey)
            path.lineTo(bx - uy * hw, by + ux * hw)
            path.lineTo(bx + uy * hw, by - ux * hw)
            path.close()
            canvas.drawPath(path, headShade)
            canvas.drawPath(path, head)
            val p = pulses[a.id]
            if (p != null) {
                val f = (now - p[0]).toFloat() / p[1]
                if (f in 0f..1f) {
                    canvas.drawCircle(sx + (ex - sx) * f, sy + (ey - sy) * f, (7f * density * unit).coerceAtLeast(4f), dotPaint)
                }
            }
        }
        pulses.entries.removeAll { now - it.value[0] >= it.value[1] }
        if (pulses.isNotEmpty()) postInvalidateOnAnimation()
    }
}

// กล่องข้อความดีบักลอยบนจอ พร้อมปุ่มคัดลอกข้อความลงคลิปบอร์ดและปุ่มปิด — ใช้ตรวจเหตุการณ์ตอนบันทึกการปัด (ClickService.DEBUG_SWIPE)
class DebugBoxView(context: Context, onCopy: () -> Unit, onClose: () -> Unit) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val body = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        typeface = Typeface.MONOSPACE
        includeFontPadding = false
        maxWidth = (resources.displayMetrics.widthPixels - 24 * density).toInt()
    }

    init {
        orientation = VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.argb(225, 20, 20, 22))
            cornerRadius = 8 * density
            setStroke(density.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        val pad = (6 * density).toInt()
        setPadding(pad, pad, pad, pad)
        addView(body, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.END
        }
        row.addView(button(context.getString(R.string.debug_copy), OVERLAY_BLUE, onCopy))
        row.addView(button(context.getString(R.string.debug_close), OVERLAY_GRAY, onClose))
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
    }

    fun setText(t: String) {
        body.text = t
    }

    private fun button(label: String, color: Int, action: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding((14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt())
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = 16 * density
        }
        setOnClickListener { action() }
        layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = (8 * density).toInt() }
    }
}

// ส่วนของแผงที่ถูกแตะ
enum class PanelAction { TOGGLE, ADD, REMOVE, SWIPE, EYE, SAVE, LOAD, SETTINGS, HIDE }

// แผงปุ่ม ▶ / ＋ / － / ⚙ / ✕ — ใช้ทั้งบนหน้าจอจริงและในตัวอย่างหน้าตั้งค่า
class PanelView(context: Context) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val bg = GradientDrawable().apply {
        setColor(Color.argb(225, 28, 28, 30))
        setStroke(density.toInt().coerceAtLeast(1), Color.argb(70, 255, 255, 255))
    }
    val toggle: TextView = circleText("▶", OVERLAY_GREEN)
    val add: TextView = circleText("+", OVERLAY_GRAY)
    val remove: TextView = circleText("−", OVERLAY_GRAY)
    val swipe: View = PanelIcon(context, PanelIconKind.SWIPE).apply { contentDescription = context.getString(R.string.panel_swipe) }
    val eye: View = PanelIcon(context, PanelIconKind.EYE).apply { contentDescription = context.getString(R.string.panel_eye) }
    val save: View = PanelIcon(context, PanelIconKind.SAVE).apply { contentDescription = context.getString(R.string.panel_save) }
    val load: View = PanelIcon(context, PanelIconKind.LOAD).apply { contentDescription = context.getString(R.string.panel_load) }
    val settings: TextView = circleText("\u2699\uFE0E", OVERLAY_GRAY)   // ⚙ ตั้งค่าเวลา
    val close: TextView = circleText("✕", OVERLAY_GRAY)
    var scale = 100
        private set

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = bg
        addView(toggle)
        addView(add)
        addView(remove)
        addView(swipe)
        addView(eye)
        addView(save)
        addView(load)
        addView(settings)
        addView(close)
        setScale(100)
    }

    private fun circleText(label: String, color: Int) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    // แปลงพิกัด x (ในแผง) เป็นปุ่มที่ถูกแตะ — ใช้ตำแหน่งซ้ายของแต่ละปุ่มหลังจัดวางแล้ว
    fun actionAt(x: Float): PanelAction = when {
        x >= close.left -> PanelAction.HIDE
        x >= settings.left -> PanelAction.SETTINGS
        x >= load.left -> PanelAction.LOAD
        x >= save.left -> PanelAction.SAVE
        x >= eye.left -> PanelAction.EYE
        x >= swipe.left -> PanelAction.SWIPE
        x >= remove.left -> PanelAction.REMOVE
        x >= add.left -> PanelAction.ADD
        else -> PanelAction.TOGGLE
    }

    fun setScale(pct: Int) {
        scale = pct
        fun px(v: Float) = (v * density * pct / 100f).toInt().coerceAtLeast(1)
        setPadding(px(6f), px(6f), px(6f), px(6f))
        bg.cornerRadius = px(32f).toFloat()
        toggle.layoutParams = LinearLayout.LayoutParams(px(48f), px(48f))
        toggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f * pct / 100f)
        for (v in listOf(add, remove, settings, close)) {
            v.layoutParams = LinearLayout.LayoutParams(px(40f), px(40f)).apply { marginStart = px(8f) }
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * pct / 100f)
        }
        // ปุ่มปัด/เซฟ/โหลดเป็นไอคอนที่วาดเอง (ไม่มีข้อความ)
        for (v in listOf(swipe, eye, save, load)) {
            v.layoutParams = LinearLayout.LayoutParams(px(40f), px(40f)).apply { marginStart = px(8f) }
        }
    }

    fun setRunning(running: Boolean) {
        toggle.text = if (running) "■" else "▶"
        (toggle.background as GradientDrawable).setColor(if (running) OVERLAY_RED else OVERLAY_GREEN)
        // ระหว่างคลิกยังเพิ่ม/ลดจุดไม่ได้ ทำให้จางเพื่อบอกผู้ใช้
        add.alpha = if (running) 0.35f else 1f
        remove.alpha = if (running) 0.35f else 1f
        swipe.alpha = if (running) 0.35f else 1f
        eye.alpha = if (running) 0.35f else 1f
        save.alpha = if (running) 0.35f else 1f
        load.alpha = if (running) 0.35f else 1f
        settings.alpha = if (running) 0.35f else 1f
    }
}

enum class PanelIconKind { SWIPE, EYE, SAVE, LOAD }

// ไอคอนบนแผงที่วาดด้วยเส้น (ไม่ใช้ข้อความ/ฟอนต์): ปัด = จุดเริ่ม + ลูกศรเฉียง, เซฟ = ลูกศรลงถาด, โหลด = ลูกศรขึ้นจากถาด
class PanelIcon(context: Context, private val kind: PanelIconKind) : View(context) {
    private val bg = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(OVERLAY_GRAY)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    init {
        background = bg
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        paint.strokeWidth = (w / 14f).coerceAtLeast(1.5f)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            canvas.drawLine(w * x1, h * y1, w * x2, h * y2, paint)
        when (kind) {
            PanelIconKind.SWIPE -> {
                line(0.30f, 0.70f, 0.70f, 0.30f)
                line(0.72f, 0.28f, 0.52f, 0.30f)
                line(0.72f, 0.28f, 0.70f, 0.48f)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(w * 0.28f, h * 0.72f, w * 0.07f, paint)
                paint.style = Paint.Style.STROKE
            }
            PanelIconKind.EYE -> {
                canvas.drawOval(RectF(w * 0.20f, h * 0.34f, w * 0.80f, h * 0.66f), paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(w * 0.50f, h * 0.50f, w * 0.08f, paint)
                paint.style = Paint.Style.STROKE
            }
            PanelIconKind.SAVE -> {
                line(0.50f, 0.22f, 0.50f, 0.56f)
                line(0.50f, 0.60f, 0.36f, 0.46f)
                line(0.50f, 0.60f, 0.64f, 0.46f)
                line(0.26f, 0.66f, 0.26f, 0.76f)
                line(0.26f, 0.76f, 0.74f, 0.76f)
                line(0.74f, 0.76f, 0.74f, 0.66f)
            }
            PanelIconKind.LOAD -> {
                line(0.50f, 0.62f, 0.50f, 0.28f)
                line(0.50f, 0.24f, 0.36f, 0.38f)
                line(0.50f, 0.24f, 0.64f, 0.38f)
                line(0.26f, 0.66f, 0.26f, 0.76f)
                line(0.26f, 0.76f, 0.74f, 0.76f)
                line(0.74f, 0.76f, 0.74f, 0.66f)
            }
        }
    }
}

// หน้าต่างตั้งค่าของตา (ลอยบนจอ): ภาพที่ตาเห็นแบบสด + ปุ่มล็อก/โหมด/ความเหมือน
class EyePanelView(
    context: Context,
    private val onLock: () -> Unit,
    private val onMode: () -> Unit,
    private val onThreshold: (Int) -> Unit,
    private val onClose: () -> Unit
) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val preview = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        setBackgroundColor(Color.argb(255, 44, 44, 46))
    }
    private val status = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        gravity = Gravity.CENTER
    }
    private val modeBtn = button("", OVERLAY_BLUE) { onMode() }
    private val lockBtn = button(context.getString(R.string.eye_lock), OVERLAY_GREEN) { onLock() }
    private val thrText = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        gravity = Gravity.CENTER
    }

    init {
        orientation = VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.argb(235, 20, 20, 22))
            cornerRadius = 10 * density
            setStroke(density.toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        val pad = (8 * density).toInt()
        setPadding(pad, pad, pad, pad)
        addView(preview, LayoutParams((220 * density).toInt(), (110 * density).toInt()))
        addView(status, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad / 2 })
        val row1 = LinearLayout(context).apply { gravity = Gravity.CENTER }
        row1.addView(lockBtn)
        row1.addView(modeBtn)
        addView(row1, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
        val row2 = LinearLayout(context).apply { gravity = Gravity.CENTER }
        row2.addView(button("−", OVERLAY_GRAY) { onThreshold(-5) })
        row2.addView(thrText, LinearLayout.LayoutParams((96 * density).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT))
        row2.addView(button("+", OVERLAY_GRAY) { onThreshold(5) })
        row2.addView(button(context.getString(R.string.eye_close), OVERLAY_GRAY) { onClose() })
        addView(row2, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = pad })
    }

    fun setPreview(bmp: Bitmap?) {
        preview.setImageBitmap(bmp)
    }

    fun setStatus(text: String) {
        status.text = text
    }

    fun setModeLabel(text: String) {
        modeBtn.text = text
    }

    fun setThreshold(pct: Int) {
        thrText.text = context.getString(R.string.eye_similarity, pct)
    }

    private fun button(label: String, color: Int, action: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding((12 * density).toInt(), (7 * density).toInt(), (12 * density).toInt(), (7 * density).toInt())
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = 16 * density
        }
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            marginStart = (4 * density).toInt()
            marginEnd = (4 * density).toInt()
        }
    }
}
