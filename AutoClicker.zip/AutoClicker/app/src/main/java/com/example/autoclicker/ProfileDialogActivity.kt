package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast

// กล่องเซฟ/โหลดที่เปิดจากปุ่ม "เซฟ" / "โหลด" บนแผงลอย
// ใช้ Activity (ไม่ใช่หน้าต่างลอยของบริการ) เพราะต้องพิมพ์ชื่อด้วยแป้นพิมพ์ — ธีมโปร่งใส เห็นแค่กล่องโต้ตอบ
// เซฟ = บันทึกจุดทั้งหมด (ตำแหน่ง/ชนิด) + ค่าตั้งค่า + เวลารายจุด ลงโปรไฟล์ชื่อที่ตั้ง (ชื่อซ้ำ = เขียนทับ)
// โหลด = เลือกโปรไฟล์ แล้วปุ่มลอยจะถูกสร้างใหม่ตามนั้น (ClickService ฟังค่า KEY_REV)
class ProfileDialogActivity : Activity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_SAVE = "save"
        const val MODE_LOAD = "load"
    }

    private var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = ConfigStore.prefs(this)
        val d = if (intent.getStringExtra(EXTRA_MODE) == MODE_LOAD) buildLoad(prefs) else buildSave(prefs)
        if (d == null) {
            finish()
            return
        }
        d.setOnDismissListener { finish() }
        dialog = d
        d.show()
    }

    override fun onDestroy() {
        dialog?.setOnDismissListener(null)
        dialog?.dismiss()
        dialog = null
        super.onDestroy()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun buildSave(prefs: SharedPreferences): AlertDialog {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            hint = getString(R.string.profile_name_hint)
            setText(getString(R.string.profile_default_name, ConfigStore.listProfiles(prefs).size + 1))
            selectAll()
        }
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.profile_save)
            .setView(et)
            .setPositiveButton(R.string.ok) { _, _ ->
                val name = et.text.toString().trim().take(40)
                if (name.isEmpty()) {
                    toast(getString(R.string.profile_name_empty))
                } else if (ConfigStore.saveProfile(prefs, ConfigStore.currentProfile(prefs, name))) {
                    toast(getString(R.string.profile_saved, name))
                } else {
                    toast(getString(R.string.profile_full, ConfigStore.MAX_PROFILES))
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        return d
    }

    private fun buildLoad(prefs: SharedPreferences): AlertDialog? {
        val list = ConfigStore.listProfiles(prefs)
        if (list.isEmpty()) {
            toast(getString(R.string.profile_none))
            return null
        }
        return AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.profile_load)
            .setItems(list.map { it.name }.toTypedArray()) { _, which ->
                val p = list[which]
                ConfigStore.applyProfile(prefs, p)
                toast(getString(R.string.profile_loaded, p.name))
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
    }
}
