package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

// ตรวจ GitHub Release "latest" เทียบเลข Build แล้วถามผู้ใช้ก่อนอัปเดต
// ความปลอดภัย: ไฟล์ APK ต้องตรงกับ SHA-256 ที่ประกาศใน Release (ฟิลด์ digest หรือไฟล์ <apk>.sha256)
// และ Android จะตรวจลายเซ็นให้อีกชั้นตอนติดตั้ง (ต้องเซ็นด้วยคีย์เดียวกับแอปที่ติดตั้งอยู่)
object UpdateChecker {

    private const val SILENT_INTERVAL_MS = 6L * 60 * 60 * 1000   // ตรวจเงียบไม่ถี่กว่า 6 ชม. (กันชนลิมิต GitHub API)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class Release(val build: Int, val apkUrl: String, val sha256: String)

    fun check(activity: Activity, silent: Boolean) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) {
            if (!silent) toast(activity, R.string.upd_no_repo)
            return
        }
        val prefs = ConfigStore.prefs(activity)
        if (silent) {
            val last = prefs.getLong(ConfigStore.KEY_LAST_UPDATE_CHECK, 0L)
            if (System.currentTimeMillis() - last < SILENT_INTERVAL_MS) return
        }
        io.launch {
            try {
                val rel = fetchLatest(activity, repo)
                prefs.edit().putLong(ConfigStore.KEY_LAST_UPDATE_CHECK, System.currentTimeMillis()).apply()
                withContext(Dispatchers.Main) {
                    if (activity.isFinishing || activity.isDestroyed) return@withContext
                    if (rel.build > BuildConfig.BUILD_NUMBER) {
                        AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle(R.string.upd_title)
                            .setMessage(activity.getString(R.string.upd_message, BuildConfig.BUILD_NUMBER, rel.build))
                            .setPositiveButton(R.string.upd_yes) { _, _ -> download(activity, rel) }
                            .setNegativeButton(R.string.upd_later, null)
                            .show()
                    } else if (!silent) {
                        toast(activity, R.string.upd_latest)
                    }
                }
            } catch (e: Exception) {
                if (!silent) toast(activity, R.string.upd_check_failed, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun apiGet(repo: String, path: String): String? {
        val conn = URL("https://api.github.com/repos/$repo/$path").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "AutoClicker-Updater")
            return when (val code = conn.responseCode) {
                200 -> conn.inputStream.bufferedReader().use { it.readText() }
                404 -> null
                else -> error("HTTP $code")
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun getText(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", "AutoClicker-Updater")
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchLatest(activity: Activity, repo: String): Release {
        // ลอง tag "latest" ก่อน ถ้าไม่เจอ (404) ค่อยใช้ Release ล่าสุดของ repo
        val body = apiGet(repo, "releases/tags/latest") ?: apiGet(repo, "releases/latest")
            ?: error(activity.getString(R.string.upd_err_no_release))
        val json = JSONObject(body)

        val arr = json.getJSONArray("assets")
        val assets = (0 until arr.length()).map { arr.getJSONObject(it) }
        val apk = assets.firstOrNull { it.getString("name").endsWith(".apk") }
            ?: error(activity.getString(R.string.upd_err_no_apk))
        val apkName = apk.getString("name")

        val build = UpdateParse.buildNumber(json.optString("body"), apkName, json.optString("tag_name"))
            ?: error(activity.getString(R.string.upd_err_no_build))

        // ลำดับ: ฟิลด์ digest ของ GitHub → ไฟล์ <apk>.sha256 ใน Release (ถ้าไม่มีทั้งคู่ จะไม่ยอมติดตั้ง)
        val sha = UpdateParse.sha256(apk.optString("digest"))
            ?: assets.firstOrNull { it.getString("name") == "$apkName.sha256" }
                ?.let { UpdateParse.sha256(getText(it.getString("browser_download_url"))) }
            ?: error(activity.getString(R.string.upd_err_no_hash))

        return Release(build, apk.getString("browser_download_url"), sha)
    }

    private fun download(activity: Activity, rel: Release) {
        // Android 8+ ต้องอนุญาต "ติดตั้งแอปที่ไม่รู้จัก" ให้แอปนี้ก่อน
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            toast(activity, R.string.upd_need_install_perm)
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        toast(activity, R.string.upd_downloading)
        io.launch {
            val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
            val part = File(dir, "update.apk.part")
            val file = File(dir, "update.apk")
            try {
                file.delete()
                part.delete()
                val conn = URL(rel.apkUrl).openConnection() as HttpURLConnection
                val digest = MessageDigest.getInstance("SHA-256")
                try {
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 30_000
                    if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    var done = 0L
                    var lastShown = 0L
                    conn.inputStream.use { input ->
                        part.outputStream().use { out ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                digest.update(buf, 0, n)
                                out.write(buf, 0, n)
                                done += n
                                val now = System.currentTimeMillis()
                                if (now - lastShown > 800) {   // แสดงความคืบหน้า (ไม่ถี่เกินไป)
                                    lastShown = now
                                    if (total > 0) toast(activity, R.string.upd_progress, (done * 100 / total).toInt())
                                    else toast(activity, R.string.upd_progress_mb, done / 1048576.0)
                                }
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
                if (part.length() <= 0L) error(activity.getString(R.string.upd_err_empty))
                val actual = digest.digest().joinToString("") { "%02x".format(it) }
                if (!actual.equals(rel.sha256, ignoreCase = true)) error(activity.getString(R.string.upd_err_hash_mismatch))
                if (!part.renameTo(file)) error(activity.getString(R.string.upd_err_empty))

                // ไม่เปิดตัวติดตั้งเองทันที: Android 10+ บล็อกการเปิดหน้าจอจากเบื้องหลังแบบเงียบๆ (ไม่มี error)
                // จึงให้ผู้ใช้กดปุ่ม "ติดตั้งเลย" เอง (การกดของผู้ใช้ทำให้เปิดตัวติดตั้งได้แน่นอน)
                withContext(Dispatchers.Main) {
                    if (activity.isFinishing || activity.isDestroyed) {
                        pendingApk = file
                        return@withContext
                    }
                    val foreground = (activity as? MainActivity)?.resumedNow ?: activity.hasWindowFocus()
                    if (foreground) promptInstall(activity, file) else pendingApk = file
                }
            } catch (e: Exception) {
                part.delete()
                file.delete()
                toast(activity, R.string.upd_download_failed, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    @Volatile private var pendingApk: File? = null

    // เรียกจาก onResume ของหน้าหลัก: ถ้าดาวน์โหลดเสร็จตอนอยู่นอกแอป จะถามติดตั้งเมื่อกลับมา
    fun resumePending(activity: Activity) {
        val f = pendingApk ?: return
        pendingApk = null
        if (f.exists()) promptInstall(activity, f)
    }

    private fun promptInstall(activity: Activity, file: File) {
        AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.upd_ready_title)
            .setMessage(R.string.upd_ready_msg)
            .setPositiveButton(R.string.upd_install_now) { _, _ -> launchInstaller(activity, file) }
            .setNegativeButton(R.string.upd_later, null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun launchInstaller(activity: Activity, file: File) {
        try {
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
            try {
                activity.startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
                // เครื่องบางรุ่นไม่รับ ACTION_VIEW → ลองช่องทางติดตั้งแบบเดิมของระบบ
                activity.startActivity(
                    Intent(Intent.ACTION_INSTALL_PACKAGE)
                        .setData(uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        } catch (e: Exception) {
            toast(activity, R.string.upd_install_failed, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun toast(activity: Activity, resId: Int, vararg args: Any) {
        val msg = activity.getString(resId, *args)
        if (activity is MainActivity) activity.notice(msg)
        else activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
    }
}
