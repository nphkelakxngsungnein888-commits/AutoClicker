package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// ตรวจ GitHub Release "latest" เทียบเลข Build แล้วถามผู้ใช้ก่อนอัปเดต
object UpdateChecker {

    fun check(activity: Activity, silent: Boolean) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) {
            if (!silent) toast(activity, "แอปนี้ไม่ได้ build จาก GitHub จึงตรวจอัปเดตไม่ได้")
            return
        }
        Thread {
            try {
                // ลอง tag "latest" ก่อน ถ้าไม่เจอ (404) ค่อยใช้ Release ล่าสุดของ repo
                fun open(path: String) = (URL("https://api.github.com/repos/$repo/$path")
                    .openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("Accept", "application/vnd.github+json")
                    setRequestProperty("User-Agent", "AutoClicker-Updater")
                }
                var conn = open("releases/tags/latest")
                if (conn.responseCode == 404) conn = open("releases/latest")
                if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })

                val latest = Regex("Build #(\\d+)").find(json.optString("body"))
                    ?.groupValues?.get(1)?.toIntOrNull() ?: error("ไม่พบเลข Build ใน Release")

                val assets = json.getJSONArray("assets")
                val apkUrl: String = (0 until assets.length())
                    .map { assets.getJSONObject(it) }
                    .firstOrNull { it.getString("name").endsWith(".apk") }
                    ?.getString("browser_download_url") ?: error("ไม่พบไฟล์ .apk ใน Release")

                activity.runOnUiThread {
                    if (activity.isFinishing) return@runOnUiThread
                    if (latest > BuildConfig.BUILD_NUMBER) {
                        AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle("มีเวอร์ชันใหม่")
                            .setMessage("เวอร์ชันปัจจุบัน ${BuildConfig.BUILD_NUMBER} → ใหม่ $latest\nต้องการอัปเดตตอนนี้ไหม?")
                            .setPositiveButton("อัปเดต") { _, _ -> download(activity, apkUrl) }
                            .setNegativeButton("ไว้ก่อน", null)
                            .show()
                    } else if (!silent) {
                        toast(activity, "เป็นเวอร์ชันล่าสุดแล้ว")
                    }
                }
            } catch (e: Exception) {
                if (!silent) toast(activity, "ตรวจอัปเดตไม่สำเร็จ: ${e.message}")
            }
        }.start()
    }

    private fun download(activity: Activity, url: String) {
        // Android 8+ ต้องอนุญาต "ติดตั้งแอปที่ไม่รู้จัก" ให้แอปนี้ก่อน
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            toast(activity, "กรุณาเปิดอนุญาตติดตั้งแอปจากแหล่งนี้ แล้วกดอัปเดตอีกครั้ง")
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        toast(activity, "กำลังดาวน์โหลด...")
        Thread {
            try {
                val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
                val file = File(dir, "update.apk")
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
                conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
                if (file.length() <= 0L) error("ไฟล์ว่าง")

                activity.runOnUiThread {
                    val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
                    val intent = Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    activity.startActivity(intent)
                }
            } catch (e: Exception) {
                toast(activity, "ดาวน์โหลดไม่สำเร็จ: ${e.message}")
            }
        }.start()
    }

    private fun toast(activity: Activity, msg: String) {
        activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
    }
}
