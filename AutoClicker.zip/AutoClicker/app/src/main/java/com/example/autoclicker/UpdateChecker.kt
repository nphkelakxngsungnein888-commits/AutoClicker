package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.util.zip.GZIPInputStream

// ตรวจ GitHub Release "latest" เทียบเลข Build แล้วถามผู้ใช้ก่อนอัปเดต
// ความปลอดภัย: ไฟล์ APK ต้องตรงกับ SHA-256 ที่ประกาศใน Release (ฟิลด์ digest หรือไฟล์ <apk>.sha256)
// และ Android จะตรวจลายเซ็นให้อีกชั้นตอนติดตั้ง (ต้องเซ็นด้วยคีย์เดียวกับแอปที่ติดตั้งอยู่)
object UpdateChecker {

    private const val SILENT_INTERVAL_MS = 6L * 60 * 60 * 1000   // ตรวจเงียบไม่ถี่กว่า 6 ชม. (กันชนลิมิต GitHub API)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class Release(val build: Int, val apkUrl: String, val sha256: String, val patchUrl: String?)

    fun check(activity: Activity, silent: Boolean) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) {
            if (!silent) toast(activity, R.string.upd_no_repo)
            return
        }
        val prefs = ConfigStore.prefs(activity)
        if (silent) {
            val last = prefs.getLong(ConfigStore.KEY_LAST_UPDATE_CHECK, 0L)
            if (System.currentTimeMillis() - last < SILENT_INTERVAL_MS) return
        }
        io.launch {
            try {
                val rel = fetchLatest(activity, repo)
                prefs.edit().putLong(ConfigStore.KEY_LAST_UPDATE_CHECK, System.currentTimeMillis()).apply()
                withContext(Dispatchers.Main) {
                    if (activity.isFinishing || activity.isDestroyed) return@withContext
                    if (rel.build > BuildConfig.BUILD_NUMBER) {
                        AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle(R.string.upd_title)
                            .setMessage(activity.getString(R.string.upd_message, BuildConfig.BUILD_NUMBER, rel.build))
                            .setPositiveButton(R.string.upd_yes) { _, _ -> download(activity, rel) }
                            .setNegativeButton(R.string.upd_later, null)
                            .show()
                    } else if (!silent) {
                        toast(activity, R.string.upd_latest)
                    }
                }
            } catch (e: Exception) {
                if (!silent) toast(activity, R.string.upd_check_failed, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun apiGet(repo: String, path: String): String? {
        val conn = URL("https://api.github.com/repos/$repo/$path").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "AutoClicker-Updater")
            return when (val code = conn.responseCode) {
                200 -> conn.inputStream.bufferedReader().use { it.readText() }
                404 -> null
                else -> error("HTTP $code")
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun getText(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", "AutoClicker-Updater")
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchLatest(activity: Activity, repo: String): Release {
        // ลอง tag "latest" ก่อน ถ้าไม่เจอ (404) ค่อยใช้ Release ล่าสุดของ repo
        val body = apiGet(repo, "releases/tags/latest") ?: apiGet(repo, "releases/latest")
            ?: error(activity.getString(R.string.upd_err_no_release))
        val json = JSONObject(body)

        val arr = json.getJSONArray("assets")
        val assets = (0 until arr.length()).map { arr.getJSONObject(it) }
        val apk = assets.firstOrNull { it.getString("name").endsWith(".apk") }
            ?: error(activity.getString(R.string.upd_err_no_apk))
        val apkName = apk.getString("name")

        val build = UpdateParse.buildNumber(json.optString("body"), apkName, json.optString("tag_name"))
            ?: error(activity.getString(R.string.upd_err_no_build))

        // ลำดับ: ฟิลด์ digest ของ GitHub → ไฟล์ <apk>.sha256 ใน Release (ถ้าไม่มีทั้งคู่ จะไม่ยอมติดตั้ง)
        val sha = UpdateParse.sha256(apk.optString("digest"))
            ?: assets.firstOrNull { it.getString("name") == "$apkName.sha256" }
                ?.let { UpdateParse.sha256(getText(it.getString("browser_download_url"))) }
            ?: error(activity.getString(R.string.upd_err_no_hash))

        // patch ส่วนต่าง "เวอร์ชันที่ติดตั้งอยู่ → เวอร์ชันใหม่" (มีเฉพาะเมื่อ CI สร้างสำเร็จ; ไม่มีก็โหลดเต็มไฟล์)
        val patchName = "AutoClicker-${BuildConfig.BUILD_NUMBER}-to-$build.patch"
        val patchUrl = assets.firstOrNull { it.getString("name") == patchName }?.getString("browser_download_url")

        return Release(build, apk.getString("browser_download_url"), sha, patchUrl)
    }

    private fun download(activity: Activity, rel: Release) {
        // Android 8+ ต้องอนุญาต "ติดตั้งแอปที่ไม่รู้จัก" ให้แอปนี้ก่อน
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            toast(activity, R.string.upd_need_install_perm)
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        toast(activity, R.string.upd_downloading)
        io.launch {
            val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
            val part = File(dir, "update.apk.part")
            val file = File(dir, "update.apk")
            try {
                file.delete()
                part.delete()
                // ทางลัด: โหลดเฉพาะ patch แล้วปะกับ APK ที่ติดตั้งอยู่ — ใช้ต่อเมื่อ SHA-256 ของผลลัพธ์ตรงกับที่ Release ประกาศ
                // พลาดตรงไหน (ไม่มี patch / ฐานไม่ตรง / ปะไม่ผ่าน / SHA ไม่ตรง) ถอยไปโหลดเต็มไฟล์แบบเดิมด้านล่าง
                val patched: String? = tryPatch(activity, rel, dir, part)?.takeIf { it.equals(rel.sha256, ignoreCase = true) }
                if (patched == null) part.delete()
                val actual: String = patched ?: run {
                    val conn = URL(rel.apkUrl).openConnection() as HttpURLConnection
                    val digest = MessageDigest.getInstance("SHA-256")
                    try {
                        conn.connectTimeout = 15_000
                        conn.readTimeout = 30_000
                        if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
                        val total = conn.contentLengthLong
                        var done = 0L
                        var lastShown = 0L
                        // ใช้ buffer ขนาดใหญ่ขึ้น ลดจำนวนรอบ read/write โดยยังคำนวณ SHA-256
                        // จากข้อมูลทุก byte เหมือนเดิม (ไม่ได้ลดหรือข้ามการตรวจสอบความปลอดภัย)
                        BufferedInputStream(conn.inputStream, 256 * 1024).use { input ->
                            BufferedOutputStream(part.outputStream(), 256 * 1024).use { out ->
                                val buf = ByteArray(256 * 1024)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    digest.update(buf, 0, n)
                                    out.write(buf, 0, n)
                                    done += n
                                    val now = System.currentTimeMillis()
                                    if (now - lastShown > 800) {   // แสดงความคืบหน้า (ไม่ถี่เกินไป)
                                        lastShown = now
                                        if (total > 0) toast(activity, R.string.upd_progress, (done * 100 / total).toInt())
                                        else toast(activity, R.string.upd_progress_mb, done / 1048576.0)
                                    }
                                }
                                out.flush()
                            }
                        }
                    } finally {
                        conn.disconnect()
                    }
                    digest.digest().joinToString("") { "%02x".format(it) }
                }
                if (part.length() <= 0L) error(activity.getString(R.string.upd_err_empty))
                if (!actual.equals(rel.sha256, ignoreCase = true)) error(activity.getString(R.string.upd_err_hash_mismatch))
                if (!part.renameTo(file)) error(activity.getString(R.string.upd_err_empty))

                // ไม่เปิดตัวติดตั้งเองทันที: Android 10+ บล็อกการเปิดหน้าจอจากเบื้องหลังแบบเงียบๆ (ไม่มี error)
                // จึงให้ผู้ใช้กดปุ่ม "ติดตั้งเลย" เอง (การกดของผู้ใช้ทำให้เปิดตัวติดตั้งได้แน่นอน)
                withContext(Dispatchers.Main) {
                    if (activity.isFinishing || activity.isDestroyed) {
                        pendingApk = file
                        return@withContext
                    }
                    val foreground = (activity as? MainActivity)?.resumedNow ?: activity.hasWindowFocus()
                    if (foreground) promptInstall(activity, file) else pendingApk = file
                }
            } catch (e: Exception) {
                part.delete()
                file.delete()
                toast(activity, R.string.upd_download_failed, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    // โหลดไฟล์ patch (ขนาดเล็ก) ลงดิสก์ แล้วปะกับ APK ที่ติดตั้งอยู่ → เขียนผลลงไฟล์ out
    // คืนค่า SHA-256 (hex) ของไฟล์ที่ได้ หรือ null ถ้าไม่มี patch / พลาดทุกกรณี (ผู้เรียกจะถอยไปโหลดเต็มไฟล์)
    private fun tryPatch(activity: Activity, rel: Release, dir: File, out: File): String? {
        val url = rel.patchUrl ?: return null
        val patchFile = File(dir, "update.patch")
        return try {
            patchFile.delete()
            downloadFile(activity, url, patchFile)
            DeltaPatch.rebuild(File(activity.applicationInfo.sourceDir), patchFile, out)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        } finally {
            patchFile.delete()
        }
    }

    private fun downloadFile(activity: Activity, url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            var done = 0L
            var lastShown = 0L
            BufferedInputStream(conn.inputStream, 64 * 1024).use { input ->
                BufferedOutputStream(dest.outputStream(), 64 * 1024).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastShown > 800) {
                            lastShown = now
                            if (total > 0) toast(activity, R.string.upd_progress, (done * 100 / total).toInt())
                        }
                    }
                    out.flush()
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    @Volatile private var pendingApk: File? = null

    // เรียกจาก onResume ของหน้าหลัก: ถ้าดาวน์โหลดเสร็จตอนอยู่นอกแอป จะถามติดตั้งเมื่อกลับมา
    fun resumePending(activity: Activity) {
        val f = pendingApk ?: return
        pendingApk = null
        if (f.exists()) promptInstall(activity, f)
    }

    private fun promptInstall(activity: Activity, file: File) {
        AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.upd_ready_title)
            .setMessage(R.string.upd_ready_msg)
            .setPositiveButton(R.string.upd_install_now) { _, _ -> launchInstaller(activity, file) }
            .setNegativeButton(R.string.upd_later, null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun launchInstaller(activity: Activity, file: File) {
        try {
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
            try {
                activity.startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
                // เครื่องบางรุ่นไม่รับ ACTION_VIEW → ลองช่องทางติดตั้งแบบเดิมของระบบ
                activity.startActivity(
                    Intent(Intent.ACTION_INSTALL_PACKAGE)
                        .setData(uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        } catch (e: Exception) {
            toast(activity, R.string.upd_install_failed, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun toast(activity: Activity, resId: Int, vararg args: Any) {
        val msg = activity.getString(resId, *args)
        if (activity is MainActivity) activity.notice(msg)
        else activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
    }
}

// ปะไฟล์ APK ที่ติดตั้งอยู่ด้วยไฟล์ส่วนต่าง (.patch) ได้ APK ใหม่ — อัลกอริทึมเดียวกับ bspatch
// รูปแบบไฟล์ .patch (สร้างโดย .github/workflows/build.yml):
//   "ACDELTA1"(8) + SHA-256 ของ APK เก่า(32) + ขนาดไฟล์ใหม่(long) + ขนาดบล็อก control/diff/extra ที่บีบ gzip แล้ว(int x3)
//   ตามด้วยบล็อก gzip สามก้อนนั้น — control คือชุดละ 3 ค่า long: (จำนวนไบต์ที่ "บวก" กับไฟล์เก่า, จำนวนไบต์ที่คัดลอกจาก extra, ระยะที่เลื่อนในไฟล์เก่า)
// ถ้าไฟล์เก่าไม่ตรงฐานของ patch หรือ patch เสียหาย จะโยน Exception (ผู้เรียกถอยไปโหลดเต็มไฟล์)
object DeltaPatch {
    private const val MAGIC = "ACDELTA1"
    private const val HEADER = 8 + 32 + 8 + 4 + 4 + 4

    private fun gz(buf: ByteArray, off: Int, len: Int): DataInputStream =
        DataInputStream(BufferedInputStream(GZIPInputStream(ByteArrayInputStream(buf, off, len), 64 * 1024), 64 * 1024))

    // คืนค่า SHA-256 (hex) ของไฟล์ใหม่ที่เขียนลง outFile
    fun rebuild(oldFile: File, patchFile: File, outFile: File): String {
        val patch = patchFile.readBytes()
        if (patch.size < HEADER) error("patch สั้นผิดปกติ")
        val head = DataInputStream(ByteArrayInputStream(patch, 0, HEADER))
        val magic = ByteArray(8).also { head.readFully(it) }
        if (String(magic, Charsets.US_ASCII) != MAGIC) error("ไม่ใช่ไฟล์ patch")
        val oldSha = ByteArray(32).also { head.readFully(it) }
        val newSize = head.readLong()
        val ctrlLen = head.readInt()
        val diffLen = head.readInt()
        val extraLen = head.readInt()
        if (newSize <= 0L || ctrlLen < 0 || diffLen < 0 || extraLen < 0 ||
            HEADER.toLong() + ctrlLen + diffLen + extraLen != patch.size.toLong()
        ) error("หัวไฟล์ patch ผิดปกติ")

        val oldSize = oldFile.length()
        if (oldSize <= 0L || oldSize > Int.MAX_VALUE) error("ไฟล์เก่าขนาดผิดปกติ")

        // ตรวจว่า APK ที่ติดตั้งอยู่คือฐานเดียวกับที่ patch ถูกสร้างจากมัน
        val oldDigest = MessageDigest.getInstance("SHA-256")
        oldFile.inputStream().use { input ->
            val b = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(b)
                if (n < 0) break
                oldDigest.update(b, 0, n)
            }
        }
        if (!MessageDigest.isEqual(oldDigest.digest(), oldSha)) error("APK ที่ติดตั้งอยู่ไม่ตรงกับฐานของ patch")

        val digest = MessageDigest.getInstance("SHA-256")
        RandomAccessFile(oldFile, "r").use { raf ->
            val old = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0L, oldSize)
            gz(patch, HEADER, ctrlLen).use { ctrl ->
                gz(patch, HEADER + ctrlLen, diffLen).use { diff ->
                    gz(patch, HEADER + ctrlLen + diffLen, extraLen).use { extra ->
                        BufferedOutputStream(outFile.outputStream(), 256 * 1024).use { out ->
                            val buf = ByteArray(64 * 1024)
                            var newPos = 0L
                            var oldPos = 0L
                            while (newPos < newSize) {
                                val x = ctrl.readLong()   // บวกกับไฟล์เก่า
                                val y = ctrl.readLong()   // คัดลอกจาก extra
                                val z = ctrl.readLong()   // เลื่อนตำแหน่งในไฟล์เก่า
                                if (x < 0L || y < 0L || x > newSize - newPos || y > newSize - newPos - x) error("patch เสียหาย")
                                var left = x
                                while (left > 0L) {
                                    val n = minOf(left, buf.size.toLong()).toInt()
                                    diff.readFully(buf, 0, n)
                                    for (i in 0 until n) {
                                        val p = oldPos + i
                                        if (p >= 0L && p < oldSize) buf[i] = (buf[i] + old.get(p.toInt())).toByte()
                                    }
                                    out.write(buf, 0, n)
                                    digest.update(buf, 0, n)
                                    oldPos += n
                                    left -= n
                                }
                                left = y
                                while (left > 0L) {
                                    val n = minOf(left, buf.size.toLong()).toInt()
                                    extra.readFully(buf, 0, n)
                                    out.write(buf, 0, n)
                                    digest.update(buf, 0, n)
                                    left -= n
                                }
                                newPos += x + y
                                oldPos += z
                            }
                            out.flush()
                        }
                    }
                }
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
