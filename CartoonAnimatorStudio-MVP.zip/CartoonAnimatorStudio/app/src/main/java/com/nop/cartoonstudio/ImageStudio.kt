package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

object ImageStudioPrefs {
    private const val FILE = "image_studio_settings"
    private const val ENABLED = "enabled"
    private const val ASK = "ask_before_start"
    fun enabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, value).apply() }
    fun ask(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ASK, true)
    fun setAsk(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ASK, value).apply() }
}

private data class StudioKeyframe(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
)

private data class StudioImage(
    val id: Int, val file: File, val bitmap: Bitmap, val duration: Float = 3f,
    val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f,
    val rotation: Float = 0f, val opacity: Float = 1f, val visible: Boolean = true,
    val startTime: Float = 0f, val keyframes: List<StudioKeyframe> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
)

@Composable
fun ImageStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val projects = remember { mutableStateListOf<ImageStudioProject>() }
    var activeProjectId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("โปรเจกต์รูปภาพ") }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshProjects() {
        projects.clear()
        projects.addAll(ImageStudioProjectStore.list(context))
    }
    LaunchedEffect(Unit) { refreshProjects() }

    val activeId = activeProjectId
    if (activeId != null) {
        ImageStudioEditorScreen(projectId = activeId, onBack = { activeProjectId = null; refreshProjects() })
        return
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ กลับ") }
            Text("Image Studio", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        }
        Text("โปรเจกต์รูปภาพ", style = MaterialTheme.typography.headlineSmall)
        Text("เปิดงานล่าสุดหรือสร้างโปรเจกต์ใหม่เพื่อเริ่มตัดต่อภาพและวิดีโอ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { newName = "โปรเจกต์รูปภาพ"; showCreate = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ สร้างโปรเจกต์ใหม่") }
        if (projects.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ยังไม่มีโปรเจกต์\nกดสร้างโปรเจกต์ใหม่เพื่อเริ่มต้น", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Text("โปรเจกต์ล่าสุด", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(projects, key = { _, item -> item.id }) { _, project ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleMedium)
                                Text("${project.imageCount} ภาพ · แก้ไข ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { activeProjectId = project.id }) { Text("เปิด") }
                            TextButton(onClick = { ImageStudioProjectStore.delete(context, project.id); refreshProjects() }) { Text("ลบ") }
                        }
                    }
                }
            }
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("สร้างโปรเจกต์ใหม่") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("ชื่อโปรเจกต์") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                runCatching { ImageStudioProjectStore.create(context, newName) }
                    .onSuccess { project -> refreshProjects(); showCreate = false; activeProjectId = project.id }
                    .onFailure { message = "สร้างโปรเจกต์ไม่สำเร็จ: ${it.message}" }
            }) { Text("สร้าง") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun ImageStudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val images = remember { mutableStateListOf<StudioImage>() }
    var selected by remember { mutableIntStateOf(0) }
    val selectedIds = remember { mutableStateListOf<Int>() }
    val layerIds = remember { mutableStateListOf<Int>() }
    var activeLayerId by remember { mutableIntStateOf(1) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var animationMode by remember { mutableStateOf(false) }
    var motionPreset by remember { mutableStateOf("เลื่อนภาพ") }
    var busy by remember { mutableStateOf(false) }
    var previewPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var loadingProject by remember { mutableStateOf(true) }
    var showProperties by remember { mutableStateOf(true) }
    var renameLayerId by remember { mutableIntStateOf(-1) }
    var renameLayerText by remember { mutableStateOf("") }
    var timelineZoom by remember { mutableFloatStateOf(1f) }
    fun selectImage(id: Int, additive: Boolean = false) {
        val index = images.indexOfFirst { it.id == id }
        if (index < 0) return
        selected = index
        activeLayerId = images[index].layerId
        if (!additive) { selectedIds.clear(); selectedIds.add(id) }
        else if (id !in selectedIds) selectedIds.add(id)
    }
    val density = androidx.compose.ui.platform.LocalDensity.current
    var overlayText by remember { mutableStateOf("") }
    var overlaySticker by remember { mutableStateOf("") }
    var overlayStart by remember { mutableFloatStateOf(0f) }
    var overlayDuration by remember { mutableFloatStateOf(5f) }
    var showOverlayDialog by remember { mutableStateOf(false) }
    var audioFile by remember { mutableStateOf<File?>(null) }
    var audioStart by remember { mutableFloatStateOf(0f) }
    var audioVolume by remember { mutableFloatStateOf(1f) }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { AudioStore.importFrom(context, uri) { } } }
                .onSuccess { imported -> audioFile = File(AudioStore.dir(context), imported.file); status = "เพิ่มแทร็กเสียงแล้ว" }
                .onFailure { status = "เพิ่มเสียงไม่สำเร็จ: ${it.message}" }
        }
    }
    LaunchedEffect(projectId) {
        val prefs = context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE)
        overlayText = prefs.getString("overlayText", "") ?: ""
        overlaySticker = prefs.getString("overlaySticker", "") ?: ""
        overlayStart = prefs.getFloat("overlayStart", 0f)
        overlayDuration = prefs.getFloat("overlayDuration", 5f)
        audioStart = prefs.getFloat("audioStart", 0f)
        audioVolume = prefs.getFloat("audioVolume", 1f)
        audioFile = prefs.getString("audioPath", null)?.let(::File)?.takeIf { it.isFile }
    }
    LaunchedEffect(overlayText, overlaySticker, overlayStart, overlayDuration, audioFile, audioStart, audioVolume) {
        context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE).edit()
            .putString("overlayText", overlayText).putString("overlaySticker", overlaySticker)
            .putFloat("overlayStart", overlayStart).putFloat("overlayDuration", overlayDuration)
            .putString("audioPath", audioFile?.absolutePath).putFloat("audioStart", audioStart)
            .putFloat("audioVolume", audioVolume).apply()
    }
    var projectLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(projectId) {
        loadingProject = true
        runCatching { ImageStudioProjectStore.loadImages(context, projectId) }
            .onSuccess { loaded ->
                images.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                images.clear()
                loaded.forEach { (record, bitmap) -> images.add(StudioImage(record.id, File(context.filesDir, "image_studio/projects/$projectId/images/${record.fileName}"), bitmap, record.duration, record.x, record.y, record.scale, record.rotation, record.opacity, record.visible, record.startTime, record.keyframes.map { StudioKeyframe(it.time, it.x, it.y, it.scale, it.rotation, it.opacity) }, record.name, record.locked, record.layerId)) }
                selectedIds.clear(); images.firstOrNull()?.let { selectedIds.add(it.id); activeLayerId = it.layerId }
                layerIds.clear(); layerIds.addAll((ImageStudioProjectStore.loadLayerIds(context, projectId) + loaded.map { it.first.layerId } + 1).distinct().sorted())
                if (layerIds.isEmpty()) layerIds.add(1)
                val settings = ImageStudioProjectStore.loadSettings(context, projectId)
                animationMode = settings.first
                motionPreset = settings.second
                projectLoaded = true
            }
            .onFailure { status = "เปิดโปรเจกต์ไม่สำเร็จ: ${it.message}"; projectLoaded = false }
        loadingProject = false
    }
    LaunchedEffect(images.map { it.id }.joinToString(","), images.map { "${it.duration}:${it.x}:${it.y}:${it.scale}:${it.rotation}:${it.opacity}:${it.visible}:${it.startTime}:${it.keyframes}:${it.name}:${it.locked}:${it.layerId}" }.joinToString(","), layerIds.toList(), animationMode, motionPreset, loadingProject) {
        if (!loadingProject && projectLoaded) {
            delay(650)
            runCatching { ImageStudioProjectStore.save(context, projectId, images.map { ImageStudioImageRecord(it.id, it.file.name, it.duration, it.x, it.y, it.scale, it.rotation, it.opacity, it.visible, it.startTime, it.keyframes.map { k -> ImageStudioKeyframeRecord(k.time, k.x, k.y, k.scale, k.rotation, k.opacity) }, it.name, it.locked, it.layerId) }, animationMode, motionPreset, layerIds.toList()) }
                .onFailure { status = "บันทึกอัตโนมัติไม่สำเร็จ: ${it.message}" }
        }
    }
    LaunchedEffect(previewPlaying, images.map { "${it.startTime}:${it.duration}" }.joinToString(",")) {
        while (previewPlaying && images.isNotEmpty()) {
            val end = (images.maxOfOrNull { it.startTime + it.duration } ?: 1f).coerceAtLeast(1f)
            delay(100L)
            playhead += 0.1f
            if (playhead > end) playhead = 0f
            val active = images.indexOfLast { playhead >= it.startTime && playhead < it.startTime + it.duration }
            if (active >= 0) selectImage(images[active].id)
        }
    }
    val previewTransition = rememberInfiniteTransition(label = "image-preview")
    val previewMotion by previewTransition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "preview-motion",
    )
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return@forEach }
            runCatching {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
                val file = ImageStudioProjectStore.importImage(context, projectId, nextId, uri.lastPathSegment ?: "image.png", input)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("ไฟล์ภาพไม่ถูกต้อง")
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                if (activeLayerId !in layerIds) layerIds.add(activeLayerId)
                images.add(StudioImage(nextId, file, bmp, startTime = images.filter { it.layerId == activeLayerId }.maxOfOrNull { it.startTime + it.duration } ?: 0f, name = "ภาพ $nextId", layerId = activeLayerId)); selectImage(nextId)
            }.onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    // Shared by the timeline controls and the audio/overlay track controls below.
    // Keep this in the editor composable scope so it is visible to every section.
    val timelineEnd = (images.maxOfOrNull { it.startTime + it.duration } ?: 1f).coerceAtLeast(1f)

    Column(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF101318)).systemBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Compact studio header: navigation, project workspace identity, and render status.
        Row(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFF1B2028), RoundedCornerShape(14.dp)).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack, enabled = !busy) { Text("‹ โปรเจกต์", color = androidx.compose.ui.graphics.Color(0xFFE4EAF3)) }
            Column(Modifier.weight(1f)) {
                Text("IMAGE STUDIO", style = MaterialTheme.typography.titleSmall, color = androidx.compose.ui.graphics.Color(0xFFF2F5FA))
                Text("EDITOR WORKSPACE", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color(0xFF91A0B5))
            }
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("●", color = androidx.compose.ui.graphics.Color(0xFF5AD6A0), modifier = Modifier.padding(horizontal = 10.dp))
        }
        if (loadingProject) { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !animationMode, onClick = { animationMode = false }, label = { Text("วิดีโอจากภาพ") })
            FilterChip(selected = animationMode, onClick = { animationMode = true }, label = { Text("ภาพเคลื่อนไหว") })
        }
        if (animationMode) {
            Text("โหมดภาพเคลื่อนไหว: สร้างการเคลื่อนภาพแบบ Keyframe อัตโนมัติจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("เลื่อนภาพ", "หมุนเบาๆ", "เลื่อนและหมุน").forEach { preset ->
                    FilterChip(selected = motionPreset == preset, onClick = { motionPreset = preset }, label = { Text(preset) })
                }
            }
        } else Text("รวมภาพหลายภาพ เรียงลำดับ และกำหนดเวลาของแต่ละภาพ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy && !loadingProject) { Text("＋ เพิ่มสื่อ") }
            OutlinedButton(onClick = { previewPlaying = !previewPlaying }, enabled = images.isNotEmpty() && !busy) { Text(if (previewPlaying) "Ⅱ หยุด" else "▶ เล่น") }
            OutlinedButton(onClick = { previewPlaying = false; images.forEach { it.bitmap.recycle() }; images.clear(); selectedIds.clear(); layerIds.clear(); layerIds.add(1); activeLayerId = 1; selected = 0 }, enabled = images.isNotEmpty() && !busy) { Text("ล้างทั้งหมด") }
            OutlinedButton(onClick = { showOverlayDialog = true }, enabled = !busy) { Text("＋ ข้อความ/สติกเกอร์") }
            OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, enabled = !busy) { Text("＋ เสียง") }
        }
        if (images.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ยังไม่มีรูปภาพ\nกด ‘เพิ่มรูปภาพ’ เพื่อเริ่มต้น", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val current = images.getOrNull(selected.coerceIn(0, images.lastIndex))
            current?.let { currentImage ->
                val animatedPose = studioPoseAt(currentImage, playhead)
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Box(
                            Modifier.fillMaxWidth().weight(1f).background(Color(0xFF202733), RoundedCornerShape(18.dp)).padding(8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Box(
                                Modifier.fillMaxSize().background(Color(0xFF11161D), RoundedCornerShape(12.dp)).padding(8.dp)
                                    .pointerInput(selectedIds.toList(), images.map { it.id to it.locked }) {
                                        detectTransformGestures { _, pan, zoom, rotation ->
                                            val ids = selectedIds.toSet().ifEmpty { setOf(currentImage.id) }
                                            ids.forEach { id ->
                                                val index = images.indexOfFirst { it.id == id }
                                                if (index >= 0 && !images[index].locked) {
                                                    val item = images[index]
                                                    images[index] = item.copy(
                                                        x = (item.x + pan.x).coerceIn(-2000f, 2000f),
                                                        y = (item.y + pan.y).coerceIn(-2000f, 2000f),
                                                        scale = (item.scale * zoom).coerceIn(0.1f, 8f),
                                                        rotation = item.rotation + rotation * 57.29578f,
                                                    )
                                                }
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                images.sortedBy { it.layerId }.forEach { layer ->
                                    if (layer.visible && playhead >= layer.startTime && playhead < layer.startTime + layer.duration) {
                                        val pose = studioPoseAt(layer, playhead)
                                        Image(
                                            layer.bitmap.asImageBitmap(), null,
                                            Modifier.fillMaxSize()
                                                .graphicsLayer(
                                                    translationX = pose.x,
                                                    translationY = pose.y,
                                                    scaleX = pose.scale, scaleY = pose.scale,
                                                    rotationZ = pose.rotation,
                                                    alpha = pose.opacity,
                                                )
                                                .clickable {
                                                    selectImage(layer.id)
                                                },
                                            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                        )
                                    }
                                }
                                // Transform frame and rotation handle for the active selection.
                                if (!currentImage.locked && currentImage.visible) {
                                    Box(Modifier.fillMaxSize().border(1.dp, Color(0xFF63C7FF), RoundedCornerShape(8.dp)))
                                    Box(Modifier.align(Alignment.TopCenter).offset(y = 2.dp).size(34.dp)
                                        .background(Color(0xFF294D72), RoundedCornerShape(50))
                                        .pointerInput(currentImage.id) {
                                            detectDragGestures { change, drag ->
                                                change.consume()
                                                val i = images.indexOfFirst { it.id == currentImage.id }
                                                if (i >= 0 && !images[i].locked) images[i] = images[i].copy(rotation = images[i].rotation + drag.x * 0.8f)
                                            }
                                        }, contentAlignment = Alignment.Center) { Text("↻", color = Color.White) }
                                }
                                if ((overlayText.isNotBlank() || overlaySticker.isNotBlank()) && playhead >= overlayStart && playhead < overlayStart + overlayDuration) {
                                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                        if (overlaySticker.isNotBlank()) Text(overlaySticker, fontSize = 42.sp)
                                        if (overlayText.isNotBlank()) Text(overlayText, color = Color.White, fontSize = 24.sp)
                                    }
                                }
                            }
                        }
                        Text("CANVAS · ${selectedIds.size} ภาพที่เลือก · ลากเพื่อย้าย / บีบ-กางเพื่อปรับขนาด / จุด ↻ เพื่อหมุน", style = MaterialTheme.typography.bodySmall, color = Color(0xFFB8C4D4))
                    }
                }
                Text("CANVAS  ·  ภาพที่ ${selected + 1} / ${images.size} · ${currentImage.bitmap.width} × ${currentImage.bitmap.height} px", style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color(0xFFB8C4D4))
        if (images.isNotEmpty()) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2028))) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ลำดับภาพ", style = MaterialTheme.typography.titleSmall, color = Color(0xFFF2F5FA), modifier = Modifier.weight(1f))
                        Text("${images.size} ภาพ", style = MaterialTheme.typography.bodySmall, color = Color(0xFF91A0B5))
                        TextButton(onClick = { timelineZoom = (timelineZoom / 1.25f).coerceAtLeast(0.5f) }) { Text("−") }
                        Text("${"%.1f".format(timelineZoom)}×", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB8C4D4))
                        TextButton(onClick = { timelineZoom = (timelineZoom * 1.25f).coerceAtMost(4f) }) { Text("＋") }
                    }
                    Slider(value = playhead.coerceIn(0f, timelineEnd), onValueChange = { value ->
                        playhead = value
                        val active = images.indexOfLast { value >= it.startTime && value < it.startTime + it.duration }
                        if (active >= 0) selectImage(images[active].id)
                    }, valueRange = 0f..timelineEnd.coerceAtLeast(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("แทร็กภาพ · แตะเพื่อเลือก / กดค้างแล้วลากเพื่อย้าย", style = MaterialTheme.typography.labelMedium, color = Color(0xFFB8C4D4), modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            val id = (layerIds.maxOrNull() ?: 0) + 1
                            layerIds.add(id); activeLayerId = id
                            selectedIds.toList().forEach { imageId ->
                                val i = images.indexOfFirst { it.id == imageId }
                                if (i >= 0) images[i] = images[i].copy(layerId = id)
                            }
                            status = "เพิ่มแทร็กใหม่แล้ว"
                        }) { Text("＋ แทร็ก") }
                    }
                    val pxPerSecond = with(density) { 48.dp.toPx() } * timelineZoom
                    Column(Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        layerIds.toList().asReversed().forEachIndexed { visualIndex, laneId ->
                            Row(Modifier.fillMaxWidth().height(86.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.width(54.dp).fillMaxHeight().background(Color(0xFF252D38), RoundedCornerShape(7.dp)).padding(4.dp), verticalArrangement = Arrangement.Center) {
                                    Text("V${layerIds.size - visualIndex}", color = Color(0xFF9CCBFF), style = MaterialTheme.typography.labelMedium)
                                    Text("${images.count { it.layerId == laneId }} คลิป", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                }
                                Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState()).background(Color(0xFF171D25), RoundedCornerShape(7.dp)), verticalAlignment = Alignment.CenterVertically) {
                                    images.withIndex().filter { it.value.layerId == laneId }.sortedBy { it.value.startTime }.forEach { indexed ->
                                        val index = indexed.index
                                        val clip = indexed.value
                                        Spacer(Modifier.width((clip.startTime * 48f * timelineZoom).coerceIn(0f, 12000f).dp))
                                        val clipWidth = (clip.duration * 48f * timelineZoom).coerceIn(72f, 900f)
                                        Card(
                                            modifier = Modifier.width(clipWidth.dp).fillMaxHeight().padding(vertical = 5.dp)
                                                .pointerInput(clip.id, timelineZoom, laneId) {
                                                    var dx = 0f; var dy = 0f
                                                    var startAt = clip.startTime
                                                    detectDragGesturesAfterLongPress(
                                                        onDragStart = {
                                                            selectImage(clip.id)
                                                            startAt = images.firstOrNull { it.id == clip.id }?.startTime ?: clip.startTime
                                                            dx = 0f; dy = 0f
                                                        },
                                                        onDrag = { change, amount ->
                                                            change.consume(); dx += amount.x; dy += amount.y
                                                            val i = images.indexOfFirst { it.id == clip.id }
                                                            if (i >= 0) {
                                                                val seconds = dx / pxPerSecond.coerceAtLeast(1f)
                                                                val laneShift = (dy / with(density) { 92.dp.toPx() }).toInt()
                                                                val targetVisual = (visualIndex + laneShift).coerceIn(0, layerIds.lastIndex)
                                                                val targetLane = layerIds.asReversed().getOrNull(targetVisual) ?: clip.layerId
                                                                images[i] = images[i].copy(startTime = (startAt + seconds).coerceIn(0f, 600f), layerId = targetLane)
                                                                activeLayerId = targetLane
                                                            }
                                                        },
                                                    )
                                                },
                                            colors = CardDefaults.cardColors(containerColor = if (selected == index) Color(0xFF294D72) else Color(0xFF344252)),
                                            onClick = { selectImage(clip.id); playhead = clip.startTime },
                                        ) {
                                            Row(Modifier.fillMaxSize().padding(3.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Image(clip.bitmap.asImageBitmap(), "คลิปภาพ ${index + 1}", Modifier.fillMaxWidth().weight(1f), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                                    Text("${index + 1} · ${"%.1f".format(clip.duration)} วิ", style = MaterialTheme.typography.labelSmall, color = Color.White, maxLines = 1)
                                                }
                                                Box(Modifier.width(13.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(3.dp))
                                                    .pointerInput(clip.id, timelineZoom) {
                                                        var initialDuration = clip.duration
                                                        var dragX = 0f
                                                        detectDragGestures(onDragStart = { initialDuration = images.firstOrNull { it.id == clip.id }?.duration ?: clip.duration; dragX = 0f }, onDrag = { change, amount ->
                                                            change.consume(); dragX += amount.x
                                                            val i = images.indexOfFirst { it.id == clip.id }
                                                            if (i >= 0) images[i] = images[i].copy(duration = (initialDuration + dragX / pxPerSecond.coerceAtLeast(1f)).coerceIn(0.5f, 60f))
                                                        })
                                                    }, contentAlignment = Alignment.Center) { Text("⋮", color = Color.White, style = MaterialTheme.typography.labelSmall) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text("กดค้างที่คลิปแล้วลากซ้าย/ขวาเพื่อเปลี่ยนเวลา หรือขึ้น/ลงเพื่อย้ายแทร็ก · คลิปที่เวลาทับกันจะแสดงซ้อนกัน", style = MaterialTheme.typography.bodySmall, color = Color(0xFFB8C4D4))
                }
            }
        }
            if (audioFile != null || overlayText.isNotBlank() || overlaySticker.isNotBlank()) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF202733))) {
                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (audioFile != null) {
                            Text("♫ AUDIO · ${audioFile?.name}", style = MaterialTheme.typography.labelMedium)
                            Text("เริ่ม ${"%.1f".format(audioStart)} วิ · ระดับเสียง ${(audioVolume * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                            Slider(value = audioStart.coerceIn(0f, timelineEnd.coerceAtLeast(1f)), onValueChange = { audioStart = it }, valueRange = 0f..timelineEnd.coerceAtLeast(1f))
                            Slider(value = audioVolume, onValueChange = { audioVolume = it }, valueRange = 0f..1f)
                            TextButton(onClick = { audioFile = null }) { Text("ลบแทร็กเสียง") }
                        }
                        if (overlayText.isNotBlank() || overlaySticker.isNotBlank()) {
                            Text("T / STICKER · ${overlaySticker} ${overlayText}", style = MaterialTheme.typography.bodySmall)
                            Text("เริ่ม ${"%.1f".format(overlayStart)} วิ · ยาว ${"%.1f".format(overlayDuration)} วิ", style = MaterialTheme.typography.bodySmall)
                            Slider(value = overlayStart.coerceIn(0f, timelineEnd), onValueChange = { overlayStart = it }, valueRange = 0f..timelineEnd.coerceAtLeast(1f))
                            Slider(value = overlayDuration.coerceIn(0.5f, 30f), onValueChange = { overlayDuration = it }, valueRange = 0.5f..30f)
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { showProperties = !showProperties }) { Text(if (showProperties) "▾ คุณสมบัติเลเยอร์" else "▸ คุณสมบัติเลเยอร์") }
                        Text("ภาพ ${selected + 1}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { images[selected] = currentImage.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f, opacity = 1f) }, enabled = !currentImage.locked) { Text("รีเซ็ต") }
                        TextButton(onClick = { images[selected] = currentImage.copy(visible = !currentImage.visible) }) { Text(if (currentImage.visible) "ซ่อน" else "แสดง") }
                    }
                    if (showProperties) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ความทึบ ${(currentImage.opacity * 100).toInt()}%", modifier = Modifier.weight(1f), color = Color.White)
                        IconButton(onClick = { images[selected] = currentImage.copy(opacity = (currentImage.opacity - 0.1f).coerceAtLeast(0f)) }) { Text("−", color = Color.White) }
                        IconButton(onClick = { images[selected] = currentImage.copy(opacity = (currentImage.opacity + 0.1f).coerceAtMost(1f)) }) { Text("＋", color = Color.White) }
                    }
                    Slider(value = currentImage.opacity, onValueChange = { images[selected] = currentImage.copy(opacity = it) }, valueRange = 0f..1f)
                    Divider()
                    Text("Keyframe · เวลา ${"%.1f".format((playhead - currentImage.startTime).coerceAtLeast(0f))} วิ", style = MaterialTheme.typography.titleSmall)
                    Text("บันทึกตำแหน่ง ขนาด มุมหมุน และความโปร่งใส ณ เวลาปัจจุบัน", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val t = (playhead - currentImage.startTime).coerceIn(0f, currentImage.duration)
                            val key = StudioKeyframe(t, currentImage.x, currentImage.y, currentImage.scale, currentImage.rotation, currentImage.opacity)
                            images[selected] = currentImage.copy(keyframes = (currentImage.keyframes.filterNot { kotlin.math.abs(it.time - t) < 0.05f } + key).sortedBy { it.time })
                            status = "บันทึก Keyframe ที่ ${"%.1f".format(t)} วินาทีแล้ว"
                        }) { Text("＋ เพิ่ม/อัปเดต") }
                        OutlinedButton(onClick = {
                            val t = (playhead - currentImage.startTime).coerceAtLeast(0f)
                            val nearest = currentImage.keyframes.minByOrNull { kotlin.math.abs(it.time - t) }
                            if (nearest != null && kotlin.math.abs(nearest.time - t) <= 0.25f) {
                                images[selected] = currentImage.copy(keyframes = currentImage.keyframes - nearest)
                                status = "ลบ Keyframe แล้ว"
                            } else status = "ไม่มี Keyframe ใกล้ตำแหน่งเวลานี้"
                        }, enabled = currentImage.keyframes.isNotEmpty()) { Text("ลบจุดนี้") }
                    }
                    Text("${currentImage.keyframes.size} จุด · ${currentImage.keyframes.joinToString { "%.1fs".format(it.time) }}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            }
        }
        if (images.isNotEmpty()) {
            OutlinedButton(onClick = { previewPlaying = !previewPlaying }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (previewPlaying) "หยุดตัวอย่าง" else "▶ เล่นตัวอย่าง")
            }
        }
        status?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Button(onClick = {
            if (images.isEmpty() || busy) return@Button
            busy = true; status = "กำลังเตรียมวิดีโอ..."
            val snapshot = images.toList()
            val exportOverlayText = overlayText
            val exportOverlaySticker = overlaySticker
            val exportOverlayStart = overlayStart
            val exportOverlayDuration = overlayDuration
            val exportAudio = audioFile
            val exportAudioStart = audioStart
            val exportAudioVolume = audioVolume
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val durationSec = (snapshot.maxOfOrNull { it.startTime + it.duration } ?: 1f).coerceAtLeast(0.5f)
                        val frameCount = (durationSec * 30f).toInt().coerceAtLeast(1)
                        if (frameCount > 3000) throw IllegalArgumentException("Timeline ยาวเกิน 100 วินาทีสำหรับการส่งออก MP4")
                        // Each image appears only during its own timeline interval.
                        val parts = snapshot.sortedBy { it.layerId }.mapIndexed { index, item ->
                            Part(item.id, "ภาพ ${index + 1}", item.bitmap).apply {
                                pivotX = bitmap.width / 2f; pivotY = bitmap.height / 2f
                                visible = item.visible
                                scale = 1f
                                characterId = item.id
                                characterName = "ภาพ ${index + 1}"
                                charAlpha = 1f
                                appearFrom = (item.startTime * 30f).toInt().coerceIn(0, frameCount - 1)
                                appearTo = (((item.startTime + item.duration) * 30f).toInt() - 1).coerceIn(appearFrom, frameCount - 1)
                            }
                        }.toMutableList()
                        val overlayBitmap = if (exportOverlayText.isNotBlank() || exportOverlaySticker.isNotBlank()) Bitmap.createBitmap(720, 720, Bitmap.Config.ARGB_8888).also { bitmap ->
                            val canvas = Canvas(bitmap); val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 46f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER; setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK) }
                            if (exportOverlaySticker.isNotBlank()) canvas.drawText(exportOverlaySticker, 360f, 330f, paint)
                            if (exportOverlayText.isNotBlank()) canvas.drawText(exportOverlayText, 360f, 400f, paint)
                        } else null
                        if (overlayBitmap != null) parts.add(Part(900001, "ข้อความ/สติกเกอร์", overlayBitmap).apply {
                            appearFrom = (exportOverlayStart * 30f).toInt().coerceIn(0, frameCount - 1)
                            appearTo = (((exportOverlayStart + exportOverlayDuration) * 30f).toInt() - 1).coerceIn(appearFrom, frameCount - 1)
                        })
                        val frames = (0 until frameCount).map { frame ->
                            val t = frame / 30f
                            snapshot.mapNotNull { item ->
                                if (!item.visible || t < item.startTime || t >= item.startTime + item.duration) null
                                else {
                                    val pose = studioPoseAt(item, t)
                                    item.id to Pose(rotation = pose.rotation, dx = pose.x, dy = pose.y, scale = pose.scale, alpha = pose.opacity)
                                }
                            }.toMap() + if (overlayBitmap != null && t >= exportOverlayStart && t < exportOverlayStart + exportOverlayDuration) mapOf(900001 to Pose()) else emptyMap()
                        }
                        val fpsTable = FloatArray(frameCount) { 30f }
                        val err = Exporter.validateVideo(720, 720, 1, frameCount)
                        if (err != null) throw IllegalArgumentException(err)
                        val tmp = File(context.cacheDir, "image_studio_${System.currentTimeMillis()}.mp4")
                        Exporter.encodeVideo(parts, frames, Exporter.videoSize(720), Exporter.videoSize(720), 30f, 1, android.graphics.Color.BLACK, tmp,
                            fpsAt = { 30f }, loopN = frameCount, onProgress = { _, _ -> })
                        var outputVideo = tmp
                        val sound = exportAudio
                        if (sound != null && sound.isFile && exportAudioVolume > 0f) {
                            val aac = AudioExport.encodeAac(listOf(AudioPlaySpec(sound, exportAudioStart, 0f, (durationSec - exportAudioStart).coerceAtLeast(0f), exportAudioVolume)), durationSec.toDouble(), 1) { }
                            val muxed = File(context.cacheDir, "image_studio_mux_${System.currentTimeMillis()}.mp4")
                            AudioExport.muxVideoAudio(tmp, aac, muxed)
                            outputVideo = muxed
                        }
                        val saved = Exporter.saveVideo(context, outputVideo, "image_video_${System.currentTimeMillis()}")
                        tmp.delete(); if (outputVideo != tmp) outputVideo.delete(); overlayBitmap?.recycle()
                        saved
                    }
                }
                busy = false
                status = result.fold({ "บันทึกวิดีโอสำเร็จ: $it" }, { "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" })
            }
        }, enabled = images.isNotEmpty() && !busy && !loadingProject, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "กำลังสร้าง..." else "▶ สร้างและบันทึก MP4") }
    }
    if (showOverlayDialog) {
        AlertDialog(onDismissRequest = { showOverlayDialog = false }, title = { Text("ข้อความและสติกเกอร์") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = overlayText, onValueChange = { overlayText = it }, label = { Text("ข้อความบนภาพ") }, singleLine = true)
                Text("เลือกสติกเกอร์")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("⭐", "❤️", "✨", "🔥", "🌟").forEach { sticker -> TextButton(onClick = { overlaySticker = sticker }) { Text(sticker) } } }
                TextButton(onClick = { overlaySticker = ""; overlayText = "" }) { Text("ล้างข้อความ/สติกเกอร์") }
            } }, confirmButton = { TextButton(onClick = { showOverlayDialog = false }) { Text("เสร็จสิ้น") } })
    }

}


private fun studioPoseAt(image: StudioImage, absoluteTime: Float): StudioKeyframe {
    val local = (absoluteTime - image.startTime).coerceIn(0f, image.duration)
    val points = image.keyframes.sortedBy { it.time }
    if (points.isEmpty()) return StudioKeyframe(local, image.x, image.y, image.scale, image.rotation, image.opacity)
    if (local <= points.first().time) return points.first()
    if (local >= points.last().time) return points.last()
    val rightIndex = points.indexOfFirst { it.time >= local }
    val a = points[rightIndex - 1]; val b = points[rightIndex]
    val span = (b.time - a.time).coerceAtLeast(0.0001f)
    val f = ((local - a.time) / span).coerceIn(0f, 1f)
    fun mix(x: Float, y: Float) = x + (y - x) * f
    return StudioKeyframe(local, mix(a.x,b.x), mix(a.y,b.y), mix(a.scale,b.scale), mix(a.rotation,b.rotation), mix(a.opacity,b.opacity))
}

@Composable
fun ImageStudioSettings(onOpen: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ImageStudioPrefs.enabled(context)) }
    var ask by remember { mutableStateOf(ImageStudioPrefs.ask(context)) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("โหมดรูปภาพ", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("เปิดใช้งานโหมดรูปภาพ")
                Text("สร้างวิดีโอและแอนิเมชันจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it; ImageStudioPrefs.setEnabled(context, it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ถามก่อนเริ่มทำ")
                Text("แสดงหน้าต่างยืนยันก่อนเข้าโหมด", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = ask, onCheckedChange = { ask = it; ImageStudioPrefs.setAsk(context, it) }, enabled = enabled)
        }
        OutlinedButton(onClick = onOpen, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("เปิดโหมดรูปภาพ") }
    }
}
